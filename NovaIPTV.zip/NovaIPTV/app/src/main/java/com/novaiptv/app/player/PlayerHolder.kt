package com.novaiptv.app.player

import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.flow.MutableSharedFlow

/**
 * Holds the single shared ExoPlayer instance so audio can keep playing
 * after [PlayerActivity] finishes (background playback via [PlayerService]).
 * The player is created once by the activity and released only when
 * playback is explicitly stopped (notification Stop, sleep timer) or when
 * the player activity finishes while paused.
 */
object PlayerHolder {
    @Volatile var player: ExoPlayer? = null

    /** URL of the item currently loaded in the player (for re-attach checks). */
    @Volatile var currentUrl: String = ""

    /** Item currently loaded (used to save resume position on external stop). */
    @Volatile var currentItem: QueueItem? = null

    /** Epoch-ms when the sleep timer fires, or 0 when no timer is set. */
    @Volatile var sleepEndsAtMs: Long = 0L

    fun release() {
        runCatching { player?.release() }
        player = null
        currentUrl = ""
        currentItem = null
        sleepEndsAtMs = 0L
    }
}

/** One-shot events from the player service to the player UI. */
object PlayerControl {
    /** Emitted when background playback is stopped from outside the player UI. */
    val stopEvents = MutableSharedFlow<Unit>(replay = 0, extraBufferCapacity = 1)
}
