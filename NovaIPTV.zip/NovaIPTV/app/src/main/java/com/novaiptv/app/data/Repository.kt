package com.novaiptv.app.data

import android.content.Context
import kotlinx.coroutines.flow.Flow

class IptvRepository(context: Context) {
    private val db = AppDatabase.get(context)
    val serverDao = db.serverDao()
    val favoriteDao = db.favoriteDao()
    val historyDao = db.historyDao()
    val downloadDao = db.downloadDao()

    fun observeServers(): Flow<List<ServerEntity>> = serverDao.observeAll()
    fun observeDownloads(): Flow<List<DownloadEntity>> = downloadDao.observeAll()
    fun observeHistory(): Flow<List<HistoryEntity>> = historyDao.observeRecent()
    fun observeFavorites(serverId: Long): Flow<List<FavoriteEntity>> = favoriteDao.observeByServer(serverId)

    suspend fun getActiveServer(): ServerEntity? {
        return serverDao.getActive() ?: serverDao.getFirst()?.also { serverDao.setActive(it.id) }
    }

    suspend fun addServer(server: ServerEntity): Long {
        serverDao.clearActive()
        return serverDao.insert(server.copy(isActive = true))
    }

    suspend fun activateServer(id: Long) {
        serverDao.clearActive()
        serverDao.setActive(id)
    }

    suspend fun deleteServer(id: Long) {
        serverDao.delete(id)
    }

    suspend fun toggleFavorite(serverId: Long, item: MediaItem, isCurrentlyFav: Boolean) {
        val key = "${serverId}_${item.kind.name}_${item.id}"
        if (isCurrentlyFav) {
            favoriteDao.delete(key)
        } else {
            favoriteDao.insert(
                FavoriteEntity(
                    key = key,
                    serverId = serverId,
                    itemId = item.id,
                    kind = item.kind.name,
                    name = item.name,
                    logo = item.logo,
                    categoryId = item.categoryId,
                    categoryName = item.categoryName,
                    streamUrl = item.streamUrl,
                    extension = item.extension
                )
            )
        }
    }

    suspend fun saveHistory(
        serverId: Long,
        itemId: String,
        kind: ContentKind,
        name: String,
        logo: String,
        streamUrl: String,
        positionMs: Long,
        durationMs: Long
    ) {
        val key = "${serverId}_${kind.name}_${itemId}"
        historyDao.upsert(
            HistoryEntity(
                key = key,
                serverId = serverId,
                itemId = itemId,
                kind = kind.name,
                name = name,
                logo = logo,
                streamUrl = streamUrl,
                positionMs = positionMs,
                durationMs = durationMs,
                updatedAt = System.currentTimeMillis()
            )
        )
    }
}
