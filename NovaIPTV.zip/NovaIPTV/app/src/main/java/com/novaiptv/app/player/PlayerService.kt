package com.novaiptv.app.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.common.Player
import com.novaiptv.app.MainActivity
import com.novaiptv.app.data.ContentKind
import com.novaiptv.app.data.IptvRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Foreground service that keeps playback audio alive when the screen locks
 * or the user leaves the app, with a notification offering Play/Pause and
 * Stop. It also owns the sleep timer: when the timer fires it saves the
 * resume position, releases the player and asks any open player UI to close.
 *
 * Independent from [com.novaiptv.app.download.DownloadService] (its own
 * channel, notification id and foreground type).
 */
class PlayerService : Service() {

    companion object {
        const val ACTION_START = "com.novaiptv.app.player.START"
        const val ACTION_TOGGLE = "com.novaiptv.app.player.TOGGLE"
        const val ACTION_STOP = "com.novaiptv.app.player.STOP"
        const val ACTION_SET_SLEEP = "com.novaiptv.app.player.SET_SLEEP"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SLEEP_MINUTES = "sleep_minutes"

        private const val CHANNEL_ID = "novaiptv_player"
        private const val NOTIF_ID = 4042

        fun start(context: Context, title: String) {
            val i = Intent(context, PlayerService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_TITLE, title)
            }
            startSvc(context, i)
        }

        fun setSleepTimer(context: Context, minutes: Int) {
            val i = Intent(context, PlayerService::class.java).apply {
                action = ACTION_SET_SLEEP
                putExtra(EXTRA_SLEEP_MINUTES, minutes)
            }
            startSvc(context, i)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, PlayerService::class.java))
        }

        private fun startSvc(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var sleepJob: Job? = null
    private var title: String = "NovaIPTV"
    private var listenedPlayer: Player? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            updateNotification(playing)
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) updateNotification(false)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                title = intent.getStringExtra(EXTRA_TITLE) ?: title
                val player = PlayerHolder.player
                if (player == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                attachListener(player)
                startAsForeground(buildNotification(player.isPlaying))
            }
            ACTION_TOGGLE -> {
                val player = PlayerHolder.player
                if (player == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                player.playWhenReady = !player.isPlaying
                updateNotification(player.isPlaying)
            }
            ACTION_SET_SLEEP -> {
                val minutes = intent.getIntExtra(EXTRA_SLEEP_MINUTES, 0)
                sleepJob?.cancel()
                if (minutes > 0) {
                    PlayerHolder.sleepEndsAtMs = System.currentTimeMillis() + minutes * 60_000L
                    sleepJob = serviceScope.launch {
                        delay(minutes * 60_000L)
                        stopPlayback()
                    }
                } else {
                    PlayerHolder.sleepEndsAtMs = 0L
                }
            }
            ACTION_STOP -> {
                stopPlayback()
            }
        }
        return START_NOT_STICKY
    }

    private fun attachListener(player: Player) {
        if (listenedPlayer === player) return
        listenedPlayer?.let { runCatching { it.removeListener(playerListener) } }
        listenedPlayer = player
        player.addListener(playerListener)
    }

    /**
     * Saves the resume position (VOD/Series only) on a detached scope so the
     * write is not cancelled by the service teardown, then releases the
     * player, tells any open player UI to close, and stops the service.
     */
    private fun stopPlayback() {
        sleepJob?.cancel()
        val item = PlayerHolder.currentItem
        val p = PlayerHolder.player
        if (item != null && p != null && item.kind != ContentKind.LIVE) {
            val pos = runCatching { p.currentPosition }.getOrDefault(0L)
            val dur = runCatching { p.duration }.getOrDefault(0L).coerceAtLeast(0L)
            if (pos > 5_000L) {
                CoroutineScope(Dispatchers.IO).launch {
                    runCatching {
                        IptvRepository(applicationContext).saveHistory(
                            serverId = item.serverId,
                            itemId = item.id,
                            kind = item.kind,
                            name = item.title,
                            logo = item.logo,
                            streamUrl = item.url,
                            positionMs = pos,
                            durationMs = dur
                        )
                    }
                }
            }
        }
        PlayerHolder.release()
        PlayerControl.stopEvents.tryEmit(Unit)
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        stopSelf()
    }

    private fun startAsForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun updateNotification(isPlaying: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(isPlaying))
    }

    private fun buildNotification(isPlaying: Boolean): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, PlayerActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleIntent = PendingIntent.getService(
            this, 1,
            Intent(this, PlayerService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, PlayerService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(if (isPlaying) "يتم التشغيل في الخلفية" else "متوقف مؤقتاً — اضغط للتشغيل")
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .addAction(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (isPlaying) "إيقاف مؤقت" else "تشغيل",
                toggleIntent
            )
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف نهائي", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "المشغّل",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "تشغيل الصوت في الخلفية أثناء مشاهدة القنوات والأفلام"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        listenedPlayer?.let { runCatching { it.removeListener(playerListener) } }
        listenedPlayer = null
        sleepJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }
}
