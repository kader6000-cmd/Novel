package com.novaiptv.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "servers")
data class ServerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,               // اسم ServerType
    val url: String,
    val username: String = "",
    val password: String = "",
    val mac: String = "",
    val userAgent: String = "",
    val liveExt: String = "m3u8"
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val contentKey: String,
    val serverId: Long,
    val json: String,
    val addedAt: Long
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey val contentKey: String,
    val serverId: Long,
    val json: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val contentKey: String,
    val serverId: Long,
    val json: String,
    val title: String,
    val filePath: String,
    val status: String,             // QUEUED / RUNNING / DONE / FAILED
    val downloaded: Long,
    val total: Long,
    val updatedAt: Long,
    val error: String = ""
)

@Dao
interface ServerDao {
    @Query("SELECT * FROM servers ORDER BY id") fun all(): Flow<List<ServerEntity>>
    @Query("SELECT * FROM servers WHERE id = :id") suspend fun get(id: Long): ServerEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(s: ServerEntity): Long
    @Query("DELETE FROM servers WHERE id = :id") suspend fun delete(id: Long)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites WHERE serverId = :sid ORDER BY addedAt DESC") fun all(sid: Long): Flow<List<FavoriteEntity>>
    @Query("SELECT contentKey FROM favorites WHERE serverId = :sid") fun keys(sid: Long): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun add(f: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE contentKey = :k") suspend fun remove(k: String)
    @Query("DELETE FROM favorites WHERE serverId = :sid") suspend fun clearServer(sid: Long)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history WHERE serverId = :sid ORDER BY updatedAt DESC LIMIT 60") fun recent(sid: Long): Flow<List<HistoryEntity>>
    @Query("SELECT * FROM history WHERE contentKey = :k") suspend fun get(k: String): HistoryEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(h: HistoryEntity)
    @Query("DELETE FROM history WHERE contentKey = :k") suspend fun remove(k: String)
    @Query("DELETE FROM history WHERE serverId = :sid") suspend fun clearServer(sid: Long)
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY updatedAt DESC") fun all(): Flow<List<DownloadEntity>>
    @Query("SELECT * FROM downloads WHERE contentKey = :k") suspend fun get(k: String): DownloadEntity?
    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED','RUNNING') ORDER BY updatedAt ASC LIMIT 1") suspend fun nextPending(): DownloadEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(d: DownloadEntity)
    @Query("UPDATE downloads SET downloaded = :d, total = :t, status = :s, updatedAt = :u WHERE contentKey = :k")
    suspend fun progress(k: String, d: Long, t: Long, s: String, u: Long)
    @Query("DELETE FROM downloads WHERE contentKey = :k") suspend fun remove(k: String)
}

@Database(
    entities = [ServerEntity::class, FavoriteEntity::class, HistoryEntity::class, DownloadEntity::class],
    version = 1, exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun servers(): ServerDao
    abstract fun favorites(): FavoriteDao
    abstract fun history(): HistoryDao
    abstract fun downloads(): DownloadDao
}
