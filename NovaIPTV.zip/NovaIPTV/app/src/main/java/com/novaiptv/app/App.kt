package com.novaiptv.app

import android.app.Application
import android.content.Context
import androidx.room.Room
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.novaiptv.app.data.AppDb
import com.novaiptv.app.data.DEFAULT_UA
import com.novaiptv.app.data.Http
import com.novaiptv.app.data.Repository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class App : Application(), ImageLoaderFactory {
    lateinit var db: AppDb
        private set
    lateinit var http: Http
        private set
    lateinit var repo: Repository
        private set
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, AppDb::class.java, "nova.db").build()
        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
        http = Http(client)
        repo = Repository(this, db, http)
    }

    /** محمّل صور بمتصفح UA وكاش — يحل مشكلة عدم ظهور شعارات القنوات */
    override fun newImageLoader(): ImageLoader {
        val imgClient = http.client.newBuilder()
            .addInterceptor { chain ->
                chain.proceed(chain.request().newBuilder().header("User-Agent", DEFAULT_UA).build())
            }
            .build()
        return ImageLoader.Builder(this)
            .okHttpClient(imgClient)
            .crossfade(true)
            .respectCacheHeaders(false)
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
            .diskCache { DiskCache.Builder().directory(cacheDir.resolve("img")).maxSizePercent(0.03).build() }
            .build()
    }
}

val Context.app: App get() = applicationContext as App
