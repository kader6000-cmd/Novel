package com.novaiptv.app

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.novaiptv.app.data.AppDb
import com.novaiptv.app.data.Http
import com.novaiptv.app.data.Repository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class App : Application() {
    lateinit var db: AppDb
        private set
    lateinit var http: Http
        private set
    lateinit var repo: Repository
        private set
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, AppDb::class.java, "nova.db").build()
        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
        http = Http(client)
        repo = Repository(this, db, http)
    }
}

val Context.app: App get() = applicationContext as App
