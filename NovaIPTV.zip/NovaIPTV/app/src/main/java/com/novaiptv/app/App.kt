package com.novaiptv.app

import android.app.Application
import com.novaiptv.app.data.Prefs
import com.novaiptv.app.download.DownloadManager
import com.novaiptv.app.download.DownloadService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class App : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        Prefs.init(applicationContext)
        appScope.launch {
            DownloadManager.cleanupOrphanedFiles(
                applicationContext,
                DownloadService.activeDownloadIds
            )
        }
    }
}
