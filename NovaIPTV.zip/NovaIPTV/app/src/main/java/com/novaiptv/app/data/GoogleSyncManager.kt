package com.novaiptv.app.data

import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

data class GoogleUserInfo(
    val email: String,
    val displayName: String,
    val photoUrl: String = ""
)

@Suppress("DEPRECATION")
object GoogleSyncManager {
    private const val DRIVE_APPDATA_SCOPE = "https://www.googleapis.com/auth/drive.appdata"
    private const val BACKUP_FILE_NAME = "novaiptv_cloud_backup.json"

    private val _currentUser = MutableStateFlow<GoogleUserInfo?>(null)
    val currentUser: StateFlow<GoogleUserInfo?> = _currentUser.asStateFlow()

    fun getClient(context: Context): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DRIVE_APPDATA_SCOPE))
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun refreshSignedInAccount(context: Context) {
        val acct = GoogleSignIn.getLastSignedInAccount(context)
        _currentUser.value = acct?.toUserInfo()
    }

    fun handleSignInResult(data: Intent?): Result<GoogleUserInfo> {
        return try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val acct = task.result
            val info = acct.toUserInfo()
            _currentUser.value = info
            Result.success(info)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun signOut(context: Context, onComplete: () -> Unit = {}) {
        getClient(context).signOut().addOnCompleteListener {
            _currentUser.value = null
            onComplete()
        }
    }

    private fun GoogleSignInAccount.toUserInfo(): GoogleUserInfo = GoogleUserInfo(
        email = email ?: "",
        displayName = displayName ?: email ?: "Google User",
        photoUrl = photoUrl?.toString() ?: ""
    )

    private suspend fun getAccessToken(context: Context): String = withContext(Dispatchers.IO) {
        val acct = GoogleSignIn.getLastSignedInAccount(context)?.account
            ?: throw IOException("يرجى تسجيل الدخول بحساب جوجل أولاً")
        GoogleAuthUtil.getToken(context, acct, "oauth2:$DRIVE_APPDATA_SCOPE")
    }

    private suspend fun findBackupFileId(token: String): String? = withContext(Dispatchers.IO) {
        val url = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name='$BACKUP_FILE_NAME'&fields=files(id,name,modifiedTime)"
        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .get()
            .build()
        HttpClient.client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Drive API HTTP ${resp.code}")
            val raw = resp.body?.string() ?: return@withContext null
            val files = JsonParser.parseString(raw).asJsonObject.getAsJsonArray("files")
            if (files != null && files.size() > 0) {
                files[0].asJsonObject.get("id")?.asString
            } else null
        }
    }

    suspend fun uploadBackupToGoogleDrive(context: Context): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val token = getAccessToken(context)
            val json = BackupManager.exportJson(context)
            val existingId = findBackupFileId(token)

            if (existingId != null) {
                // Update existing backup file in appDataFolder
                val req = Request.Builder()
                    .url("https://www.googleapis.com/upload/drive/v3/files/$existingId?uploadType=media")
                    .header("Authorization", "Bearer $token")
                    .patch(json.toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()
                HttpClient.client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("Upload failed: HTTP ${resp.code}")
                }
            } else {
                // Create new backup file inside hidden appDataFolder
                val metadata = """{"name":"$BACKUP_FILE_NAME","parents":["appDataFolder"]}"""
                val body = MultipartBody.Builder()
                    .setType("multipart/related".toMediaType())
                    .addPart(metadata.toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .addPart(json.toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()
                val req = Request.Builder()
                    .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
                    .header("Authorization", "Bearer $token")
                    .post(body)
                    .build()
                HttpClient.client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("Create failed: HTTP ${resp.code}")
                }
            }
        }
    }

    suspend fun restoreBackupFromGoogleDrive(context: Context): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val token = getAccessToken(context)
            val fileId = findBackupFileId(token)
                ?: throw IOException("لا توجد نسخة احتياطية محفوظة على حساب جوجل")
            val req = Request.Builder()
                .url("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
                .header("Authorization", "Bearer $token")
                .get()
                .build()
            HttpClient.client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("Download failed: HTTP ${resp.code}")
                val json = resp.body?.string() ?: throw IOException("Empty backup")
                BackupManager.importJson(context, json)
            }
        }
    }
}
