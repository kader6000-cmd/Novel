package com.novaiptv.app.download

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import com.novaiptv.app.data.AppDatabase
import com.novaiptv.app.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

object DownloadManager {

    /**
     * Local temp directory where active .part downloads are written (supports fast auto-resume).
     * Once 100% completed, the file is moved to Downloads/NovaIPTV (default) or the user's chosen folder.
     */
    fun getTempDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "NovaIPTV_Temp")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getPublicDownloadsDir(): File {
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NovaIPTV")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun sanitizeFileName(name: String, extension: String): String {
        val clean = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(80)
        val ext = extension.trim().trimStart('.').ifBlank { "mp4" }
        return "${clean.ifBlank { "video_${System.currentTimeMillis()}" }}.$ext"
    }

    private fun guessMimeType(fileName: String): String {
        val lower = fileName.lowercase()
        return when {
            lower.endsWith(".mkv") -> "video/x-matroska"
            lower.endsWith(".ts") -> "video/mp2t"
            lower.endsWith(".avi") -> "video/x-msvideo"
            lower.endsWith(".webm") -> "video/webm"
            else -> "video/mp4"
        }
    }

    /**
     * Finalizes a 100% completed temp .part file into either:
     * 1) User-selected SAF folder (if configured in Settings), OR
     * 2) Public Downloads/NovaIPTV (via MediaStore.Downloads on Android 10+ or direct File on Android 7-9).
     * Returns the playable URI string (content://... or absolute file path).
     */
    fun finalizePartsToDestination(context: Context, partFiles: List<File>, fileName: String): String {
        val mime = guessMimeType(fileName)
        val customTreeUriStr = Prefs.downloadTreeUri.value
        val copyBuf = ByteArray(512 * 1024)

        fun streamPartsTo(out: java.io.OutputStream) {
            for (part in partFiles) {
                FileInputStream(part).use { input ->
                    var read: Int
                    while (input.read(copyBuf).also { read = it } != -1) {
                        out.write(copyBuf, 0, read)
                    }
                }
                part.delete()
            }
            out.flush()
        }

        if (customTreeUriStr.isNotBlank()) {
            try {
                val treeUri = Uri.parse(customTreeUriStr)
                val docId = DocumentsContract.getTreeDocumentId(treeUri)
                val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                val createdUri = DocumentsContract.createDocument(
                    context.contentResolver,
                    parentDocUri,
                    mime,
                    fileName
                ) ?: throw IOException("Failed to create document in custom folder")

                context.contentResolver.openOutputStream(createdUri)?.use { out ->
                    streamPartsTo(out)
                } ?: throw IOException("Cannot open output stream for custom folder")
                return createdUri.toString()
            } catch (_: Exception) {
                // Fallback to Public Downloads
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/NovaIPTV")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Failed to create MediaStore download entry")
            try {
                resolver.openOutputStream(uri)?.use { out ->
                    streamPartsTo(out)
                } ?: throw IOException("Failed to open MediaStore output stream")

                val doneValues = ContentValues().apply {
                    put(MediaStore.Downloads.IS_PENDING, 0)
                }
                resolver.update(uri, doneValues, null, null)
                return uri.toString()
            } catch (e: Exception) {
                runCatching { resolver.delete(uri, null, null) }
                throw e
            }
        } else {
            val dir = getPublicDownloadsDir()
            val destFile = File(dir, fileName)
            if (destFile.exists()) destFile.delete()
            FileOutputStream(destFile).use { out ->
                streamPartsTo(out)
            }
            return destFile.absolutePath
        }
    }

    fun finalizeToDestination(context: Context, tempFile: File, fileName: String): String {
        val mime = guessMimeType(fileName)
        val customTreeUriStr = Prefs.downloadTreeUri.value

        // Option A: Custom folder chosen by user via Settings (Storage Access Framework)
        if (customTreeUriStr.isNotBlank()) {
            try {
                val treeUri = Uri.parse(customTreeUriStr)
                val docId = DocumentsContract.getTreeDocumentId(treeUri)
                val parentDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                val createdUri = DocumentsContract.createDocument(
                    context.contentResolver,
                    parentDocUri,
                    mime,
                    fileName
                ) ?: throw IOException("Failed to create document in custom folder")

                context.contentResolver.openOutputStream(createdUri)?.use { out ->
                    FileInputStream(tempFile).use { input ->
                        input.copyTo(out, 256 * 1024)
                    }
                    out.flush()
                } ?: throw IOException("Cannot open output stream for custom folder")

                tempFile.delete()
                return createdUri.toString()
            } catch (_: Exception) {
                // Fallback to Public Downloads if custom folder permission was revoked
            }
        }

        // Option B (Default): Public Downloads/NovaIPTV
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/NovaIPTV")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Failed to create MediaStore download entry")
            try {
                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(tempFile).use { input ->
                        input.copyTo(out, 256 * 1024)
                    }
                    out.flush()
                } ?: throw IOException("Failed to open MediaStore output stream")

                val doneValues = ContentValues().apply {
                    put(MediaStore.Downloads.IS_PENDING, 0)
                }
                resolver.update(uri, doneValues, null, null)
                tempFile.delete()
                return uri.toString()
            } catch (e: Exception) {
                runCatching { resolver.delete(uri, null, null) }
                throw e
            }
        } else {
            val dir = getPublicDownloadsDir()
            val destFile = File(dir, fileName)
            if (destFile.exists()) destFile.delete()
            if (!tempFile.renameTo(destFile)) {
                FileInputStream(tempFile).use { input ->
                    FileOutputStream(destFile).use { out ->
                        input.copyTo(out, 256 * 1024)
                    }
                }
                tempFile.delete()
            }
            return destFile.absolutePath
        }
    }

    fun startDownload(
        context: Context,
        id: String,
        title: String,
        url: String,
        logo: String,
        extension: String
    ) {
        val intent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_ID, id)
            putExtra(DownloadService.EXTRA_TITLE, title)
            putExtra(DownloadService.EXTRA_URL, url)
            putExtra(DownloadService.EXTRA_LOGO, logo)
            putExtra(DownloadService.EXTRA_EXT, extension)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun pauseDownload(context: Context, id: String) {
        val intent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_PAUSE
            putExtra(DownloadService.EXTRA_ID, id)
        }
        context.startService(intent)
    }

    fun cancelDownload(context: Context, id: String) {
        val intent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_CANCEL
            putExtra(DownloadService.EXTRA_ID, id)
        }
        context.startService(intent)
    }

    fun deleteCompletedDownload(context: Context, id: String, filePath: String) {
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                if (filePath.startsWith("content://")) {
                    val uri = Uri.parse(filePath)
                    val deleted = runCatching { DocumentsContract.deleteDocument(context.contentResolver, uri) }.getOrDefault(false)
                    if (!deleted) {
                        context.contentResolver.delete(uri, null, null)
                    }
                } else {
                    val f = File(filePath)
                    if (f.exists()) f.delete()
                    deleteTempPartsFor(f)
                }
            }
            AppDatabase.get(context).downloadDao().deleteById(id)
        }
    }

    fun deleteTempPartsFor(targetFile: File) {
        val parent = targetFile.parentFile ?: return
        val baseName = targetFile.name
        parent.listFiles()?.forEach { file ->
            if (file.name == "$baseName.part" || file.name.startsWith("$baseName.part.")) {
                runCatching { file.delete() }
            }
        }
    }

    suspend fun cleanupOrphanedFiles(context: Context, activeIds: Set<String> = emptySet()): Long {
        var freedBytes = 0L
        val tempDir = getTempDir(context)
        val dao = AppDatabase.get(context).downloadDao()
        val allEntries = dao.getAll()

        for (entry in allEntries) {
            if (entry.state != "COMPLETED" && entry.state != "PAUSED" && entry.id !in activeIds) {
                if (!entry.filePath.startsWith("content://")) {
                    val f = File(entry.filePath)
                    if (f.exists()) {
                        freedBytes += f.length()
                        f.delete()
                    }
                    deleteTempPartsFor(f)
                }
                dao.deleteById(entry.id)
            }
        }

        if (activeIds.isEmpty()) {
            tempDir.listFiles()?.forEach { file ->
                freedBytes += file.length()
                runCatching { file.delete() }
            }
        }
        return freedBytes
    }

    fun calculateUsedStorageBytes(context: Context): Long {
        val tempSize = getTempDir(context).listFiles()?.sumOf { it.length() } ?: 0L
        val pubSize = runCatching {
            val d = getPublicDownloadsDir()
            d.listFiles()?.sumOf { it.length() } ?: 0L
        }.getOrDefault(0L)
        return tempSize + pubSize
    }
}
