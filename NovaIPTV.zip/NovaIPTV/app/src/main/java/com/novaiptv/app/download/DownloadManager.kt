package com.novaiptv.app.download

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import com.novaiptv.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

object DownloadManager {

    fun getDownloadDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "NovaIPTV")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun sanitizeFileName(name: String, extension: String): String {
        val clean = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(80)
        val ext = extension.trim().trimStart('.').ifBlank { "mp4" }
        return "${clean.ifBlank { "video_${System.currentTimeMillis()}" }}.$ext"
    }

    fun startDownload(
        context: Context,
        id: String,
        title: String,
        url: String,
        logo: String,
        extension: String
    ) {
        val intent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_START
            putExtra(DownloadService.EXTRA_ID, id)
            putExtra(DownloadService.EXTRA_TITLE, title)
            putExtra(DownloadService.EXTRA_URL, url)
            putExtra(DownloadService.EXTRA_LOGO, logo)
            putExtra(DownloadService.EXTRA_EXT, extension)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun cancelDownload(context: Context, id: String) {
        val intent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_CANCEL
            putExtra(DownloadService.EXTRA_ID, id)
        }
        context.startService(intent)
    }

    fun deleteCompletedDownload(context: Context, id: String, filePath: String) {
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                val f = File(filePath)
                if (f.exists()) f.delete()
                deleteTempPartsFor(f)
            }
            AppDatabase.get(context).downloadDao().deleteById(id)
        }
    }

    fun deleteTempPartsFor(targetFile: File) {
        val parent = targetFile.parentFile ?: return
        val baseName = targetFile.name
        parent.listFiles()?.forEach { file ->
            if (file.name == "$baseName.part" || file.name.startsWith("$baseName.part.")) {
                runCatching { file.delete() }
            }
        }
    }

    suspend fun cleanupOrphanedFiles(context: Context, activeIds: Set<String> = emptySet()): Long {
        var freedBytes = 0L
        val dir = getDownloadDir(context)
        val dao = AppDatabase.get(context).downloadDao()
        val allEntries = dao.getAll()

        for (entry in allEntries) {
            if (entry.state != "COMPLETED" && entry.id !in activeIds) {
                val f = File(entry.filePath)
                if (f.exists()) {
                    freedBytes += f.length()
                    f.delete()
                }
                deleteTempPartsFor(f)
                dao.deleteById(entry.id)
            } else if (entry.state == "COMPLETED") {
                val f = File(entry.filePath)
                if (!f.exists()) {
                    dao.deleteById(entry.id)
                }
            }
        }

        if (activeIds.isEmpty()) {
            dir.listFiles()?.forEach { file ->
                if (file.name.contains(".part")) {
                    freedBytes += file.length()
                    runCatching { file.delete() }
                }
            }
        }
        return freedBytes
    }

    fun calculateUsedStorageBytes(context: Context): Long {
        val dir = getDownloadDir(context)
        return dir.listFiles()?.sumOf { it.length() } ?: 0L
    }
}
