package com.novaiptv.app.data

import android.content.Context
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

data class BackupPayload(
    val version: Int = 1,
    val servers: List<ServerEntity> = emptyList(),
    val favorites: List<FavoriteEntity> = emptyList()
)

object BackupManager {
    private val gson = Gson()

    suspend fun exportJson(context: Context): String = withContext(Dispatchers.IO) {
        val db = AppDatabase.get(context)
        val servers = db.serverDao().observeAll().first()
        val favs = mutableListOf<FavoriteEntity>()
        for (s in servers) {
            favs.addAll(db.favoriteDao().observeByServer(s.id).first())
        }
        gson.toJson(BackupPayload(version = 1, servers = servers, favorites = favs))
    }

    suspend fun importJson(context: Context, json: String): Int = withContext(Dispatchers.IO) {
        val payload = gson.fromJson(json, BackupPayload::class.java) ?: return@withContext 0
        val db = AppDatabase.get(context)
        var importedServers = 0
        for (srv in payload.servers) {
            db.serverDao().insert(srv.copy(id = 0, isActive = false))
            importedServers++
        }
        importedServers
    }
}
