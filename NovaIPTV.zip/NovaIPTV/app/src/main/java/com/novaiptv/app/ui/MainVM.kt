package com.novaiptv.app.ui

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.novaiptv.app.App
import com.novaiptv.app.data.*
import com.novaiptv.app.download.Downloads
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ListState(val loading: Boolean = false, val items: List<Content> = emptyList(), val error: String? = null)
data class HistoryItem(val content: Content, val pos: Long, val dur: Long)

@OptIn(ExperimentalCoroutinesApi::class)
class MainVM(application: Application) : AndroidViewModel(application) {
    private val app = application as App
    private val prefs = application.getSharedPreferences("nova", Context.MODE_PRIVATE)

    val servers: StateFlow<List<ServerEntity>?> =
        app.db.servers().all().map<List<ServerEntity>, List<ServerEntity>?> { it }
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val selectedId = MutableStateFlow(prefs.getLong("sid", -1L))

    val current: StateFlow<ServerEntity?> =
        combine(servers, selectedId) { l, id -> l?.firstOrNull { it.id == id } ?: l?.firstOrNull() }
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _lists = MutableStateFlow<Map<Kind, ListState>>(emptyMap())
    val lists: StateFlow<Map<Kind, ListState>> = _lists

    val favKeys: StateFlow<Set<String>> = current
        .flatMapLatest { s -> if (s == null) flowOf(emptyList<String>()) else app.db.favorites().keys(s.id) }
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val favorites: StateFlow<List<Content>> = current
        .flatMapLatest { s -> if (s == null) flowOf(emptyList<FavoriteEntity>()) else app.db.favorites().all(s.id) }
        .map { l -> l.map { contentFromJson(it.json) } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recent: StateFlow<List<HistoryItem>> = current
        .flatMapLatest { s -> if (s == null) flowOf(emptyList<HistoryEntity>()) else app.db.history().recent(s.id) }
        .map { l -> l.map { HistoryItem(contentFromJson(it.json), it.positionMs, it.durationMs) } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val downloads: StateFlow<List<DownloadEntity>> = app.db.downloads().all()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ───── تفاصيل مسلسل/فيلم
    var detail by mutableStateOf<Content?>(null)
    var pendingPlay: String? = null
    private val _eps = MutableStateFlow(ListState())
    val episodes: StateFlow<ListState> = _eps

    fun openDetail(c: Content) {
        detail = c
        _eps.value = ListState()
        if (c.kind == Kind.SERIES) loadEpisodes(c)
    }

    fun loadEpisodes(c: Content) {
        val s = current.value ?: return
        _eps.value = ListState(loading = true)
        viewModelScope.launch {
            try {
                val l = app.repo.episodes(s, c).sortedWith(compareBy({ it.season }, { it.episode }))
                if (detail?.key == c.key) _eps.value = ListState(items = l)
            } catch (e: Exception) {
                _eps.value = ListState(error = e.message ?: "خطأ في تحميل الحلقات")
            }
        }
    }

    // ───── تحميل القوائم
    fun ensure(kind: Kind, force: Boolean = false) {
        val s = current.value ?: return
        val st = _lists.value[kind]
        if (!force && st != null && st.error == null) return
        _lists.update { it + (kind to ListState(loading = true)) }
        viewModelScope.launch {
            try {
                val items = app.repo.load(s, kind, force)
                if (current.value?.id == s.id) _lists.update { it + (kind to ListState(items = items)) }
            } catch (e: Exception) {
                if (current.value?.id == s.id) _lists.update { it + (kind to ListState(error = e.message ?: e.toString())) }
            }
        }
    }

    // ───── المفضلة والسجل
    fun toggleFav(c: Content) {
        viewModelScope.launch {
            if (c.key in favKeys.value) app.db.favorites().remove(c.key)
            else app.db.favorites().add(FavoriteEntity(c.key, c.serverId, c.toJson(), System.currentTimeMillis()))
        }
    }

    fun removeHistory(key: String) { viewModelScope.launch { app.db.history().remove(key) } }
    fun clearHistory() { val id = current.value?.id ?: return; viewModelScope.launch { app.db.history().clearServer(id) } }

    // ───── التحميلات
    var dlConn by mutableIntStateOf(prefs.getInt("dl_conn", 4))
    fun setDlConn(n: Int) { dlConn = n; prefs.edit().putInt("dl_conn", n).apply() }

    fun download(items: List<Content>) { viewModelScope.launch { Downloads.enqueue(app, items) } }
    fun removeDownload(d: DownloadEntity) { viewModelScope.launch { Downloads.remove(app, d) } }
    fun pauseDownload(d: DownloadEntity) { viewModelScope.launch { Downloads.pause(app, d) } }
    fun resumeDownload(d: DownloadEntity) { viewModelScope.launch { Downloads.resume(app, d) } }
    fun pauseAllDownloads() { viewModelScope.launch { Downloads.pauseAll(app) } }
    fun resumeAllDownloads() { viewModelScope.launch { Downloads.resumeAll(app) } }
    fun clearDownloads() { viewModelScope.launch { Downloads.clearAll(app) } }
    /** إلغاء تحميلات (غير المكتملة) لمجموعة عناصر */
    fun cancelDownloads(keys: Set<String>) {
        viewModelScope.launch {
            downloads.value.filter { it.contentKey in keys && it.status != "DONE" }.forEach { Downloads.remove(app, it) }
        }
    }

    // ───── السيرفرات
    fun select(id: Long) {
        prefs.edit().putLong("sid", id).apply()
        selectedId.value = id
        _lists.value = emptyMap()
    }

    fun saveServer(s: ServerEntity) {
        viewModelScope.launch {
            val id = app.db.servers().upsert(s)
            app.repo.invalidate(id)
            select(id)
        }
    }

    fun deleteServer(s: ServerEntity) {
        viewModelScope.launch {
            app.db.servers().delete(s.id)
            app.db.favorites().clearServer(s.id)
            app.db.history().clearServer(s.id)
            app.repo.invalidate(s.id)
            if (selectedId.value == s.id) select(-1L)
        }
    }

    /** يرجع null عند النجاح أو رسالة الخطأ */
    fun test(s: ServerEntity, cb: (String?) -> Unit) {
        viewModelScope.launch {
            val r = try { app.repo.testServer(s); null } catch (e: Exception) { e.message ?: e.toString() }
            cb(r)
        }
    }
}
