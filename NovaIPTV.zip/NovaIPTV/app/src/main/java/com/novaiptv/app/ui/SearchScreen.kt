package com.novaiptv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.data.ContentKind
import com.novaiptv.app.data.MediaItem
import com.novaiptv.app.player.PlayerActivity
import com.novaiptv.app.player.QueueItem
import kotlinx.coroutines.delay

/**
 * Global search across Live TV, Movies and Series at once.
 * Searches the already-loaded catalog (Home loads all three sections),
 * with a 500ms debounce while typing.
 */
@Composable
fun SearchScreen(
    vm: MainViewModel,
    onOpenSeries: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val activeServer by vm.activeServer.collectAsState()
    val liveState by vm.liveState.collectAsState()
    val movieState by vm.movieState.collectAsState()
    val seriesState by vm.seriesState.collectAsState()

    var query by remember { mutableStateOf("") }
    var debounced by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(query) {
        delay(500)
        debounced = query
    }

    LaunchedEffect(activeServer?.id) {
        if (activeServer != null) {
            vm.loadSection(ContentKind.LIVE)
            vm.loadSection(ContentKind.MOVIE)
            vm.loadSection(ContentKind.SERIES)
        }
    }

    LaunchedEffect(Unit) {
        runCatching { focusRequester.requestFocus() }
    }

    val q = debounced.trim()
    val isLoading = liveState.isLoading || movieState.isLoading || seriesState.isLoading
    val liveResults = remember(liveState.items, q) {
        if (q.isBlank()) emptyList()
        else liveState.items.filter { it.name.contains(q, ignoreCase = true) }.take(30)
    }
    val movieResults = remember(movieState.items, q) {
        if (q.isBlank()) emptyList()
        else movieState.items.filter { it.name.contains(q, ignoreCase = true) }.take(30)
    }
    val seriesResults = remember(seriesState.items, q) {
        if (q.isBlank()) emptyList()
        else seriesState.items.filter { it.name.contains(q, ignoreCase = true) }.take(30)
    }
    val totalCount = liveResults.size + movieResults.size + seriesResults.size

    Column(modifier = Modifier.fillMaxSize().background(BgDark)) {
        // Search bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = TextPrimary)
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("ابحث عن قناة أو فيلم أو مسلسل...", color = TextSecondary, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح", tint = TextSecondary)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardDark,
                    unfocusedContainerColor = CardDark,
                    focusedBorderColor = AccentCyan,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focusRequester)
            )
        }
        HorizontalDivider(color = BorderSubtle)

        if (activeServer == null) {
            EmptyOrErrorBox("أضف سيرفر أولاً عشان تقدر تبحث في محتواه.")
            return@Column
        }

        if (q.isBlank()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(28.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(12.dp))
                Text(
                    "اكتب اسم قناة أو فيلم أو مسلسل للبحث في كل الأقسام معاً",
                    color = TextSecondary,
                    fontSize = 14.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
            return@Column
        }

        if (isLoading && totalCount == 0) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentCyan)
            }
            return@Column
        }

        if (totalCount == 0) {
            EmptyOrErrorBox("لا توجد نتائج مطابقة لـ \"$q\"\nجرّب كلمة تانية أو تأكد من الإملاء.")
            return@Column
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (liveResults.isNotEmpty()) {
                item {
                    SearchGroupHeader(
                        title = "قنوات مباشرة",
                        count = liveResults.size,
                        icon = Icons.Default.LiveTv
                    )
                }
                itemsIndexed(liveResults, key = { _, it -> "live_${it.id}" }) { index, item ->
                    SearchResultRow(item = item, kindLabel = "مباشر") {
                        val queue = liveResults.map {
                            QueueItem(it.id, it.name, "نتائج البحث", it.streamUrl, it.logo, ContentKind.LIVE, activeServer!!.id)
                        }
                        PlayerActivity.launch(context, queue, index, "نتائج البحث")
                    }
                }
            }
            if (movieResults.isNotEmpty()) {
                item {
                    SearchGroupHeader(
                        title = "أفلام",
                        count = movieResults.size,
                        icon = Icons.Default.Movie
                    )
                }
                itemsIndexed(movieResults, key = { _, it -> "movie_${it.id}" }) { index, item ->
                    SearchResultRow(item = item, kindLabel = "فيلم") {
                        val queue = movieResults.map {
                            QueueItem(it.id, it.name, "نتائج البحث", it.streamUrl, it.logo, ContentKind.MOVIE, activeServer!!.id)
                        }
                        PlayerActivity.launch(context, queue, index, "نتائج البحث")
                    }
                }
            }
            if (seriesResults.isNotEmpty()) {
                item {
                    SearchGroupHeader(
                        title = "مسلسلات",
                        count = seriesResults.size,
                        icon = Icons.Default.Tv
                    )
                }
                itemsIndexed(seriesResults, key = { _, it -> "series_${it.id}" }) { _, item ->
                    SearchResultRow(item = item, kindLabel = "مسلسل") {
                        vm.openSeriesDetail(item)
                        onOpenSeries()
                    }
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun SearchGroupHeader(
    title: String,
    count: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.width(6.dp))
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = AccentCyan.copy(alpha = 0.15f)
        ) {
            Text(
                "$count",
                color = AccentCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
private fun SearchResultRow(
    item: MediaItem,
    kindLabel: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF0E131D)),
            contentAlignment = Alignment.Center
        ) {
            if (item.logo.isNotBlank()) {
                AsyncImage(
                    model = item.logo,
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    if (item.kind == ContentKind.LIVE) Icons.Default.LiveTv else Icons.Default.Movie,
                    contentDescription = null,
                    tint = AccentCyan
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.name,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(kindLabel, color = TextSecondary, fontSize = 11.sp)
        }
        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = AccentCyan)
    }
}
