package com.novaiptv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.data.ContentKind
import com.novaiptv.app.data.MediaItem
import com.novaiptv.app.i18n.LocalStrings
import com.novaiptv.app.player.PlayerActivity
import com.novaiptv.app.player.QueueItem

@Composable
fun HomeScreen(
    vm: MainViewModel,
    onGoToLive: () -> Unit,
    onGoToMovies: () -> Unit,
    onGoToSeries: () -> Unit,
    onGoToServers: () -> Unit
) {
    val context = LocalContext.current
    val s = LocalStrings.current
    val activeServer by vm.activeServer.collectAsState()
    val liveState by vm.liveState.collectAsState()
    val movieState by vm.movieState.collectAsState()
    val seriesState by vm.seriesState.collectAsState()
    val history by vm.history.collectAsState()

    LaunchedEffect(activeServer?.id) {
        if (activeServer != null) {
            vm.loadSection(ContentKind.LIVE)
            vm.loadSection(ContentKind.MOVIE)
            vm.loadSection(ContentKind.SERIES)
        }
    }

    if (activeServer == null) {
        EmptyOrErrorBox(s.noServerAdded, s.addServer, onGoToServers)
        return
    }

    val latestLive = remember(liveState.items) { liveState.items.take(15) }
    val latestMovies = remember(movieState.items) { movieState.items.takeLast(15).reversed() }
    val latestSeries = remember(seriesState.items) { seriesState.items.takeLast(15).reversed() }
    val continueList = remember(history) { history.filter { it.positionMs > 5_000L }.take(10) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Continue Watching (if any)
        if (continueList.isNotEmpty()) {
            SectionHeader(title = s.continueWatching, actionText = null, onAction = {})
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(continueList) { idx, h ->
                    val pct = if (h.durationMs > 0) (h.positionMs.toFloat() / h.durationMs.toFloat()).coerceIn(0f, 1f) else 0f
                    Column(
                        modifier = Modifier
                            .width(156.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(CardDark)
                            .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                            .clickable {
                                val queue = continueList.map {
                                    QueueItem(
                                        it.itemId,
                                        it.name,
                                        s.continueWatching,
                                        it.streamUrl,
                                        it.logo,
                                        runCatching { ContentKind.valueOf(it.kind) }.getOrDefault(ContentKind.MOVIE),
                                        it.serverId
                                    )
                                }
                                PlayerActivity.launch(context, queue, idx, s.continueWatching)
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(92.dp)
                                .background(Color(0xFF0E131D)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (h.logo.isNotBlank()) {
                                AsyncImage(
                                    model = h.logo,
                                    contentDescription = h.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(36.dp))
                            }
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xAA000000)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(22.dp))
                            }
                        }
                        LinearProgressIndicator(
                            progress = { pct },
                            color = AccentCyan,
                            trackColor = Color(0xFF232C3F),
                            modifier = Modifier.fillMaxWidth().height(3.dp)
                        )
                        Text(
                            text = h.name,
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }

        // 2. Featured Live Channels
        SectionHeader(title = s.latestLive, actionText = s.seeAll, onAction = onGoToLive)
        if (liveState.isLoading && latestLive.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(110.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentCyan, modifier = Modifier.size(28.dp))
            }
        } else if (latestLive.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(latestLive) { idx, item ->
                    HomeLiveCard(item = item, liveLabel = s.liveBadge) {
                        val queue = latestLive.map {
                            QueueItem(it.id, it.name, s.latestLive, it.streamUrl, it.logo, ContentKind.LIVE, activeServer!!.id)
                        }
                        PlayerActivity.launch(context, queue, idx, s.latestLive)
                    }
                }
            }
        }

        // 3. Latest Movies
        SectionHeader(title = s.latestMovies, actionText = s.seeAll, onAction = onGoToMovies)
        if (movieState.isLoading && latestMovies.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentCyan, modifier = Modifier.size(28.dp))
            }
        } else if (latestMovies.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(latestMovies) { idx, item ->
                    HomePosterCard(item = item) {
                        val queue = latestMovies.map {
                            QueueItem(it.id, it.name, s.latestMovies, it.streamUrl, it.logo, ContentKind.MOVIE, activeServer!!.id)
                        }
                        PlayerActivity.launch(context, queue, idx, s.latestMovies)
                    }
                }
            }
        }

        // 4. Latest Series
        SectionHeader(title = s.latestSeries, actionText = s.seeAll, onAction = onGoToSeries)
        if (seriesState.isLoading && latestSeries.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentCyan, modifier = Modifier.size(28.dp))
            }
        } else if (latestSeries.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(latestSeries) { _, item ->
                    HomePosterCard(item = item) {
                        vm.openSeriesDetail(item)
                        onGoToSeries()
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, actionText: String?, onAction: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (actionText != null) {
            Text(
                text = actionText,
                color = AccentCyan,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                modifier = Modifier.clickable(onClick = onAction).padding(4.dp)
            )
        }
    }
}

@Composable
private fun HomeLiveCard(item: MediaItem, liveLabel: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(120.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF0E131D)),
            contentAlignment = Alignment.Center
        ) {
            if (item.logo.isNotBlank()) {
                AsyncImage(
                    model = item.logo,
                    contentDescription = item.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(6.dp)
                )
            } else {
                Icon(Icons.Default.LiveTv, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(30.dp))
            }
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(4.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(LiveRed)
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(liveLabel, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = item.name,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun HomePosterCard(item: MediaItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(116.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(156.dp)
                .background(Color(0xFF0E131D)),
            contentAlignment = Alignment.Center
        ) {
            if (item.logo.isNotBlank()) {
                AsyncImage(
                    model = item.logo,
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Default.Movie, contentDescription = null, tint = AccentViolet, modifier = Modifier.size(34.dp))
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC0A0D14))))
            )
            if (item.rating.isNotBlank() && item.rating != "0") {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(5.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xCC000000))
                        .padding(horizontal = 5.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(10.dp))
                    Spacer(Modifier.width(2.dp))
                    Text(item.rating.take(4), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Text(
            text = item.name,
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            minLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(7.dp)
        )
    }
}
