package com.novaiptv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.novaiptv.app.data.Prefs
import com.novaiptv.app.i18n.LocalStrings
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.data.Category
import com.novaiptv.app.data.MediaItem

@Composable
fun SearchAndControlsBar(
    query: String,
    onQueryChange: (String) -> Unit,
    placeholder: String,
    isGrid: Boolean? = null,
    onToggleGrid: (() -> Unit)? = null,
    onRefresh: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text(placeholder, color = TextSecondary, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQueryChange("") }) {
                        Icon(Icons.Default.Close, contentDescription = "مسح", tint = TextSecondary)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CardDark,
                unfocusedContainerColor = CardDark,
                focusedBorderColor = AccentCyan,
                unfocusedBorderColor = BorderSubtle,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.weight(1f)
        )

        if (isGrid != null && onToggleGrid != null) {
            IconButton(
                onClick = onToggleGrid,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(CardDark)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
            ) {
                Icon(
                    if (isGrid) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
                    contentDescription = "تبديل العرض",
                    tint = AccentCyan
                )
            }
        }

        IconButton(
            onClick = onRefresh,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CardDark)
                .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
        ) {
            Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = TextPrimary)
        }
    }
}

@Composable
fun CategoryTabsRow(
    categories: List<Category>,
    selectedId: String,
    onSelect: (String) -> Unit
) {
    val s = LocalStrings.current
    val pin by Prefs.parentalPin.collectAsState()
    var pendingLockedCat by remember { mutableStateOf<Category?>(null) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    val allList = listOf(Category("ALL", s.allCategory)) + categories
    LazyRow(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(allList, key = { it.id }) { cat ->
            val selected = cat.id == selectedId
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (selected) Brush.horizontalGradient(listOf(AccentCyan, AccentViolet))
                        else Brush.horizontalGradient(listOf(CardDark, CardDark))
                    )
                    .border(
                        width = 1.dp,
                        color = if (selected) Color.Transparent else BorderSubtle,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .clickable {
                        if (cat.id != "ALL" && Prefs.isCategoryLocked(cat.name)) {
                            pendingLockedCat = cat
                            pinInput = ""
                            pinError = false
                        } else {
                            onSelect(cat.id)
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            ) {
                Text(
                    text = cat.name,
                    color = if (selected) Color.Black else TextPrimary,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 13.sp,
                    maxLines = 1
                )
            }
        }
    }

    pendingLockedCat?.let { lockedCat ->
        AlertDialog(
            onDismissRequest = { pendingLockedCat = null },
            containerColor = CardDark,
            title = { Text(s.enterPinPrompt, color = AccentCyan, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) { pinInput = it; pinError = false } },
                        singleLine = true,
                        isError = pinError,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pinError) {
                        Spacer(Modifier.height(6.dp))
                        Text(s.wrongPin, color = LiveRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinInput == pin) {
                            onSelect(lockedCat.id)
                            pendingLockedCat = null
                        } else {
                            pinError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
                ) {
                    Text(s.confirm, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingLockedCat = null }) { Text(s.cancel, color = TextSecondary) }
            }
        )
    }
}

@Composable
fun LiveChannelGridCard(
    item: MediaItem,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFav: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(86.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0E131D)),
            contentAlignment = Alignment.Center
        ) {
            if (item.logo.isNotBlank()) {
                AsyncImage(
                    model = item.logo,
                    contentDescription = item.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(8.dp)
                )
            } else {
                Icon(
                    Icons.Default.LiveTv,
                    contentDescription = null,
                    tint = AccentCyan.copy(alpha = 0.7f),
                    modifier = Modifier.size(36.dp)
                )
            }

            // LIVE badge
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(LiveRed.copy(alpha = 0.9f))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(5.dp).clip(CircleShape).background(Color.White))
                Spacer(Modifier.width(3.dp))
                Text("مباشر", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }

            // Favorite heart
            IconButton(
                onClick = onToggleFav,
                modifier = Modifier.align(Alignment.TopEnd).size(30.dp)
            ) {
                Icon(
                    if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "مفضلة",
                    tint = if (isFavorite) LiveRed else Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Text(
            text = item.name,
            color = TextPrimary,
            fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp,
            maxLines = 2,
            minLines = 2,
            textAlign = TextAlign.Center,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun LiveChannelListRow(
    item: MediaItem,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFav: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0E131D)),
            contentAlignment = Alignment.Center
        ) {
            if (item.logo.isNotBlank()) {
                AsyncImage(
                    model = item.logo,
                    contentDescription = item.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().padding(6.dp)
                )
            } else {
                Icon(Icons.Default.LiveTv, contentDescription = null, tint = AccentCyan)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.name,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(LiveRed))
                Spacer(Modifier.width(5.dp))
                Text("بث مباشر", color = TextSecondary, fontSize = 11.sp)
            }
        }
        IconButton(onClick = onToggleFav) {
            Icon(
                if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "مفضلة",
                tint = if (isFavorite) LiveRed else TextSecondary
            )
        }
    }
}

@Composable
fun PosterMediaCard(
    item: MediaItem,
    isFavorite: Boolean,
    showDownloadButton: Boolean,
    onClick: () -> Unit,
    onToggleFav: () -> Unit,
    onDownload: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.68f)
                .background(Color(0xFF0E131D)),
            contentAlignment = Alignment.Center
        ) {
            if (item.logo.isNotBlank()) {
                AsyncImage(
                    model = item.logo,
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Default.Movie, contentDescription = null, tint = AccentViolet, modifier = Modifier.size(40.dp))
            }

            // Bottom gradient
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC0A0D14))))
            )

            // Rating badge
            if (item.rating.isNotBlank() && item.rating != "0") {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xCC000000))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(2.dp))
                    Text(item.rating.take(4), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Fav button
            IconButton(
                onClick = onToggleFav,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color(0x88000000))
            ) {
                Icon(
                    if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "مفضلة",
                    tint = if (isFavorite) LiveRed else Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Download button for movies
            if (showDownloadButton && onDownload != null) {
                IconButton(
                    onClick = onDownload,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(AccentCyan)
                ) {
                    Icon(Icons.Default.Download, contentDescription = "تحميل", tint = Color.Black, modifier = Modifier.size(18.dp))
                }
            }
        }

        Text(
            text = item.name,
            color = TextPrimary,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            maxLines = 2,
            minLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(8.dp)
        )
    }
}

@Composable
fun EmptyOrErrorBox(message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.TvOff, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(message, color = TextSecondary, textAlign = TextAlign.Center, fontSize = 14.sp)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
            ) {
                Text(actionLabel, fontWeight = FontWeight.Bold)
            }
        }
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format("%.1f MB", mb)
    return String.format("%.2f GB", mb / 1024.0)
}
