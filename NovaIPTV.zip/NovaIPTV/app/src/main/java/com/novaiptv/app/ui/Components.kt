package com.novaiptv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.data.Content

@Composable
fun Poster(url: String?, title: String, modifier: Modifier = Modifier, fit: Boolean = false) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(Surface2, Surface1)))
            .border(0.8.dp, BorderSubtle, RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(title.take(1).uppercase(), color = TextDim.copy(alpha = 0.6f), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        if (!url.isNullOrBlank()) {
            AsyncImage(
                model = url, contentDescription = null,
                contentScale = if (fit) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier.fillMaxSize().padding(if (fit) 6.dp else 0.dp)
            )
        }
    }
}

@Composable
fun PosterCard(
    c: Content, modifier: Modifier = Modifier, progress: Float? = null, fav: Boolean = false, onClick: () -> Unit
) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.68f)) {
            Poster(c.poster, c.title, Modifier.fillMaxSize())
            // تدرج سفلي خفيف لإبراز البوستر
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000))))
            )
            if (fav) {
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Favorite, null, tint = Heart, modifier = Modifier.size(14.dp))
                }
            }
            if (c.rating.isNotBlank() && c.rating != "0" && c.rating != "0.0") {
                Row(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xBF000000))
                        .padding(horizontal = 5.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Star, null, tint = Gold, modifier = Modifier.size(11.dp))
                    Spacer(Modifier.width(2.dp))
                    Text(c.rating.take(3), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (progress != null) LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp),
                color = Accent2, trackColor = Color.Black.copy(alpha = 0.6f)
            )
        }
        Text(
            c.display,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            lineHeight = 16.sp,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp)
        )
    }
}

@Composable
fun HeroBanner(c: Content, isFav: Boolean, onPlay: () -> Unit, onDetail: () -> Unit, onToggleFav: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(290.dp)
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Surface2)
            .border(1.dp, BorderSubtle, RoundedCornerShape(22.dp))
            .clickable { onDetail() }
    ) {
        if (!c.poster.isNullOrBlank()) {
            AsyncImage(
                model = c.poster,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x22070A12), Color(0x99070A12), Color(0xF2070A12))
                    )
                )
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(color = Accent.copy(alpha = 0.85f), shape = RoundedCornerShape(6.dp)) {
                    Text(
                        "مُختار لك",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                if (c.group.isNotBlank()) {
                    Surface(color = Color(0x88000000), shape = RoundedCornerShape(6.dp)) {
                        Text(
                            c.group,
                            fontSize = 10.sp,
                            color = TextDim,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
                if (c.rating.isNotBlank() && c.rating != "0") {
                    Text("★ ${c.rating.take(3)}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(c.title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onPlay,
                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Rounded.PlayArrow, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("مشاهدة الآن", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                FilledTonalButton(
                    onClick = onDetail,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Rounded.Info, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("التفاصيل", fontSize = 13.sp)
                }
                IconButton(
                    onClick = onToggleFav,
                    modifier = Modifier.size(38.dp).clip(CircleShape).background(Color(0x66000000))
                ) {
                    Icon(
                        if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        null,
                        tint = if (isFav) Heart else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String, count: Int? = null, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 18.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(AccentBrush))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (count != null && count > 0) {
            Text("$count", fontSize = 12.sp, color = TextDim, modifier = Modifier.padding(end = 6.dp))
        }
        if (onMore != null) {
            TextButton(onClick = onMore, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                Text("عرض الكل", fontSize = 12.sp, color = Accent2)
            }
        }
    }
}

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String?,
    count: Int? = null,
    onRefresh: (() -> Unit)?,
    onServers: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                if (count != null && count > 0) {
                    Surface(color = Surface2, shape = RoundedCornerShape(8.dp)) {
                        Text(
                            "$count",
                            fontSize = 11.sp,
                            color = Accent2,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            if (!subtitle.isNullOrBlank()) Text(subtitle, fontSize = 12.sp, color = TextDim, maxLines = 1)
        }
        if (onRefresh != null) IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, null) }
        IconButton(onClick = onServers) { Icon(Icons.Rounded.Dns, null, tint = Accent2) }
    }
}

@Composable
fun SearchField(
    value: String,
    placeholder: String = "ابحث عن قناة، فيلم، أو مسلسل…",
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(placeholder, color = TextDim, fontSize = 13.sp) },
        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Accent2) },
        trailingIcon = { if (value.isNotEmpty()) IconButton(onClick = { onChange("") }) { Icon(Icons.Rounded.Close, null) } },
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = BorderSubtle, focusedBorderColor = Accent,
            unfocusedContainerColor = Surface1, focusedContainerColor = Surface1
        ),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

@Composable
fun GroupChips(
    groups: List<Pair<String, Int>>,
    selected: String?,
    onSelect: (String?) -> Unit,
    onOpenAllDialog: () -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (groups.size > 5) {
            item {
                AssistChip(
                    onClick = onOpenAllDialog,
                    label = { Text("الأقسام (${groups.size})", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Rounded.Category, null, tint = Accent2, modifier = Modifier.size(16.dp)) },
                    shape = RoundedCornerShape(12.dp),
                    colors = AssistChipDefaults.assistChipColors(containerColor = Surface2)
                )
            }
        }
        item {
            FilterChip(
                selected = selected == null,
                onClick = { onSelect(null) },
                label = { Text("الكل") },
                shape = RoundedCornerShape(12.dp)
            )
        }
        items(groups) { (g, cnt) ->
            FilterChip(
                selected = selected == g,
                onClick = { onSelect(g) },
                label = { Text("$g ($cnt)", maxLines = 1) },
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@Composable
fun StatBadge(icon: ImageVector, label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.border(0.8.dp, BorderSubtle, RoundedCornerShape(14.dp)),
        color = Surface1,
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(Accent.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = Accent2, modifier = Modifier.size(18.dp))
            }
            Column {
                Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = Color.White)
                Text(label, fontSize = 11.sp, color = TextDim, maxLines = 1)
            }
        }
    }
}

@Composable
fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
}

@Composable
fun ErrorBox(msg: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.ErrorOutline, null, tint = Heart, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(10.dp))
        Text(msg, textAlign = TextAlign.Center, color = TextDim, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        Button(onClick = onRetry, colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(12.dp)) {
            Icon(Icons.Rounded.Refresh, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("إعادة المحاولة")
        }
    }
}

@Composable
fun EmptyBox(text: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Inbox, null, tint = TextDim.copy(alpha = 0.4f), modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(8.dp))
            Text(text, color = TextDim, textAlign = TextAlign.Center, fontSize = 14.sp)
        }
    }
}
