package com.novaiptv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.data.Content

@Composable
fun Poster(url: String?, title: String, modifier: Modifier = Modifier, fit: Boolean = false) {
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Surface2, Surface1))),
        contentAlignment = Alignment.Center
    ) {
        Text(title.take(1), color = TextDim, fontSize = 26.sp)
        if (!url.isNullOrBlank()) {
            AsyncImage(
                model = url, contentDescription = null,
                contentScale = if (fit) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier.fillMaxSize().padding(if (fit) 4.dp else 0.dp)
            )
        }
    }
}

@Composable
fun PosterCard(
    c: Content, modifier: Modifier = Modifier, progress: Float? = null, fav: Boolean = false, onClick: () -> Unit
) {
    Column(modifier.clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.68f)) {
            Poster(c.poster, c.title, Modifier.fillMaxSize())
            if (fav) Icon(
                Icons.Rounded.Favorite, null, tint = Heart,
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp).size(18.dp)
            )
            if (progress != null) LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                color = Accent2, trackColor = Color.Black.copy(alpha = 0.5f)
            )
        }
        Text(c.display, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 8.dp))
}

@Composable
fun ScreenHeader(title: String, subtitle: String?, onRefresh: (() -> Unit)?, onServers: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (!subtitle.isNullOrBlank()) Text(subtitle, fontSize = 12.sp, color = TextDim, maxLines = 1)
        }
        if (onRefresh != null) IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, null) }
        IconButton(onClick = onServers) { Icon(Icons.Rounded.Dns, null) }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text("بحث…", color = TextDim) },
        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = TextDim) },
        trailingIcon = { if (value.isNotEmpty()) IconButton(onClick = { onChange("") }) { Icon(Icons.Rounded.Close, null) } },
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = Color.Transparent, focusedBorderColor = Accent,
            unfocusedContainerColor = Surface1, focusedContainerColor = Surface1
        ),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

@Composable
fun GroupChips(groups: List<String>, selected: String?, onSelect: (String?) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item { FilterChip(selected = selected == null, onClick = { onSelect(null) }, label = { Text("الكل") }) }
        items(groups) { g -> FilterChip(selected = selected == g, onClick = { onSelect(g) }, label = { Text(g, maxLines = 1) }) }
    }
}

@Composable
fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
}

@Composable
fun ErrorBox(msg: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.ErrorOutline, null, tint = Heart, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(8.dp))
        Text(msg, textAlign = TextAlign.Center, color = TextDim, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onRetry, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
    }
}

@Composable
fun EmptyBox(text: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = TextDim, textAlign = TextAlign.Center)
    }
}
