package com.novaiptv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.data.Content
import com.novaiptv.app.data.Kind
import java.util.Locale
import kotlin.math.abs

const val G_ALL = "__all__"
const val G_FAV = "__fav__"
const val G_HOME = "__home__"

private val palettes = listOf(
    listOf(Color(0xFF3A2C8F), Color(0xFF1B1346)),
    listOf(Color(0xFF0E6E8C), Color(0xFF0A2E45)),
    listOf(Color(0xFF8F2C5B), Color(0xFF3F1030)),
    listOf(Color(0xFF2C8F6A), Color(0xFF0F3A2E)),
    listOf(Color(0xFF8F6A2C), Color(0xFF3A2A0F)),
    listOf(Color(0xFF2C4F8F), Color(0xFF0F1D3A))
)

fun fmtBytes(b: Long): String = when {
    b >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    b >= 1L shl 20 -> String.format(Locale.US, "%.0f MB", b / 1048576.0)
    else -> String.format(Locale.US, "%d KB", b / 1024)
}

/** صورة مع خلفية ملوّنة وحرف أول كبديل عند غياب الصورة */
@Composable
fun Poster(url: String?, title: String, modifier: Modifier = Modifier, fit: Boolean = false, radius: Int = 12) {
    val pal = palettes[abs(title.hashCode()) % palettes.size]
    Box(
        modifier.clip(RoundedCornerShape(radius.dp)).background(Brush.linearGradient(pal)),
        contentAlignment = Alignment.Center
    ) {
        Text(title.trim().take(2).uppercase(), color = Color.White.copy(alpha = 0.55f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (!url.isNullOrBlank()) {
            AsyncImage(
                model = url, contentDescription = null,
                contentScale = if (fit) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier.fillMaxSize().padding(if (fit) 6.dp else 0.dp)
            )
        }
    }
}

@Composable
fun RatingBadge(rating: String, modifier: Modifier = Modifier) {
    val r = rating.toDoubleOrNull() ?: return
    if (r <= 0.0) return
    Row(
        modifier.clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = 0.65f)).padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Star, null, tint = Color(0xFFFFC107), modifier = Modifier.size(11.dp))
        Spacer(Modifier.width(2.dp))
        Text(String.format(Locale.US, "%.1f", r), fontSize = 10.sp, color = Color.White)
    }
}

@Composable
fun PosterCard(
    c: Content, modifier: Modifier = Modifier, progress: Float? = null, fav: Boolean = false, onClick: () -> Unit
) {
    Column(modifier.clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.68f)) {
            Poster(c.poster, c.title, Modifier.fillMaxSize().border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp)), radius = 14)
            RatingBadge(c.rating, Modifier.align(Alignment.TopEnd).padding(6.dp))
            if (fav) Icon(
                Icons.Rounded.Favorite, null, tint = Heart,
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp).size(18.dp)
            )
            if (progress != null) LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp),
                color = Accent2, trackColor = Color.Black.copy(alpha = 0.5f)
            )
        }
        Text(c.display, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp))
    }
}

/** بلاطة قناة: شعار كبير + اسم + قلب المفضلة */
@Composable
fun ChannelTile(c: Content, fav: Boolean, modifier: Modifier = Modifier, onFav: () -> Unit, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Surface1)
            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.35f)) {
            Poster(c.poster, c.title, Modifier.fillMaxSize(), fit = true, radius = 12)
            Box(Modifier.align(Alignment.TopStart).padding(6.dp).size(7.dp).clip(CircleShape).background(Color(0xFFFF3B30)))
            Box(
                Modifier.align(Alignment.TopEnd).size(30.dp).clip(CircleShape).clickable(onClick = onFav),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (fav) Heart else Color.White.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
            }
        }
        Text(
            c.title, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
            textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
fun SectionTitle(text: String, onMore: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(AccentBrush))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (onMore != null) Text("عرض الكل", color = Accent2, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onMore).padding(4.dp))
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String?, onRefresh: (() -> Unit)?, onServers: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            if (!subtitle.isNullOrBlank()) Text(subtitle, fontSize = 12.sp, color = TextDim, maxLines = 1)
        }
        if (onRefresh != null) IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, null) }
        IconButton(onClick = onServers) { Icon(Icons.Rounded.Dns, null) }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text("بحث…", color = TextDim) },
        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = TextDim) },
        trailingIcon = { if (value.isNotEmpty()) IconButton(onClick = { onChange("") }) { Icon(Icons.Rounded.Close, null) } },
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = Color.Transparent, focusedBorderColor = Accent,
            unfocusedContainerColor = Surface1, focusedContainerColor = Surface1
        ),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
    )
}

/** كبسولة تبويب */
@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .then(if (selected) Modifier.background(AccentBrush) else Modifier.background(Surface2))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 13.sp, maxLines = 1, color = if (selected) Color.White else Color(0xFFC8CEDE), fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

/** صف تبويبات أفقي: كل عنصر (المفتاح، العنوان) */
@Composable
fun Pills(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { (k, label) -> Pill(label, selected == k) { onSelect(k) } }
    }
}

@Composable
fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
}

@Composable
fun ErrorBox(msg: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.ErrorOutline, null, tint = Heart, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(8.dp))
        Text(msg, textAlign = TextAlign.Center, color = TextDim, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onRetry, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
    }
}

@Composable
fun EmptyBox(text: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = TextDim, textAlign = TextAlign.Center)
    }
}

fun kindLabel(k: Kind) = when (k) {
    Kind.LIVE -> "مباشر"; Kind.MOVIE -> "فيلم"; Kind.SERIES -> "مسلسل"; Kind.EPISODE -> "حلقة"
}
