package com.novaiptv.app.data

enum class ServerType { XTREAM, M3U, STALKER }

enum class ContentKind { LIVE, MOVIE, SERIES }

data class Category(
    val id: String,
    val name: String
)

data class MediaItem(
    val id: String,
    val name: String,
    val logo: String = "",
    val categoryId: String = "",
    val categoryName: String = "",
    val streamUrl: String = "",
    val kind: ContentKind = ContentKind.LIVE,
    val extension: String = "mp4",
    val rating: String = "",
    val plot: String = "",
    val year: String = ""
)

data class EpisodeItem(
    val id: String,
    val season: Int,
    val episodeNum: Int,
    val title: String,
    val streamUrl: String,
    val logo: String = "",
    val extension: String = "mp4",
    val duration: String = ""
)

data class SeriesDetail(
    val info: MediaItem,
    val seasons: Map<Int, List<EpisodeItem>>
)
