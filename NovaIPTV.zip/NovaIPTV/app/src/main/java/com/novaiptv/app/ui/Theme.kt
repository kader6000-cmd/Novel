package com.novaiptv.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B0E17)
val Surface1 = Color(0xFF141927)
val Surface2 = Color(0xFF1C2336)
val Accent = Color(0xFF7C5CFF)
val Accent2 = Color(0xFF00D1FF)
val TextDim = Color(0xFF9AA3B8)
val Heart = Color(0xFFFF4D6D)
val AccentBrush = Brush.linearGradient(listOf(Accent, Accent2))

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, secondary = Accent2, background = Bg, surface = Surface1,
            surfaceVariant = Surface2, surfaceContainer = Surface1, surfaceContainerHigh = Surface2,
            onBackground = Color.White, onSurface = Color.White, onSurfaceVariant = TextDim,
            primaryContainer = Surface2, onPrimaryContainer = Color.White,
            secondaryContainer = Accent.copy(alpha = 0.3f), onSecondaryContainer = Color.White
        ),
        content = content
    )
}
