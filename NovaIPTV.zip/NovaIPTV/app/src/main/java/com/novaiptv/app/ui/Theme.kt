package com.novaiptv.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0A0D14)
val CardDark = Color(0xFF151A24)
val CardElevated = Color(0xFF1C2331)
val AccentCyan = Color(0xFF00E5FF)
val AccentViolet = Color(0xFF7C4DFF)
val LiveRed = Color(0xFFFF3D57)
val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFF94A3B8)
val BorderSubtle = Color(0xFF252E42)

private val NovaDarkColors = darkColorScheme(
    primary = AccentCyan,
    onPrimary = Color.Black,
    secondary = AccentViolet,
    onSecondary = Color.White,
    background = BgDark,
    onBackground = TextPrimary,
    surface = CardDark,
    onSurface = TextPrimary,
    surfaceVariant = CardElevated,
    onSurfaceVariant = TextSecondary,
    error = LiveRed,
    outline = BorderSubtle
)

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NovaDarkColors,
        content = content
    )
}
