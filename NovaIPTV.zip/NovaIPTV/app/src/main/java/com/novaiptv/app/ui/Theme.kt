package com.novaiptv.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import com.novaiptv.app.data.Prefs

val BgDark = Color(0xFF0A0D14)
val CardDark = Color(0xFF151A24)
val CardElevated = Color(0xFF1C2331)
val AccentViolet = Color(0xFF7C4DFF)
val LiveRed = Color(0xFFFF3D57)
val TextPrimary = Color(0xFFF3F6FC)
val TextSecondary = Color(0xFF94A3B8)
val BorderSubtle = Color(0xFF252E42)

/** Available accent themes. The first entry is the default. */
data class NovaAccent(val id: String, val nameAr: String, val color: Color)

val ThemeAccents = listOf(
    NovaAccent("cyan", "سماوي", Color(0xFF00E5FF)),
    NovaAccent("violet", "بنفسجي", Color(0xFF7C4DFF)),
    NovaAccent("green", "أخضر", Color(0xFF00E676)),
    NovaAccent("amber", "ذهبي", Color(0xFFFFB300)),
    NovaAccent("red", "أحمر", Color(0xFFFF5252))
)

/** Holds the currently active accent color; read by [AccentCyan]. */
object NovaThemeState {
    val accent = mutableStateOf(ThemeAccents.first().color)

    fun apply(themeId: String) {
        accent.value = ThemeAccents.find { it.id == themeId }?.color
            ?: ThemeAccents.first().color
    }
}

/**
 * Dynamic accent color: resolves to the theme selected in [Prefs.theme].
 * Reading it inside a composable subscribes to changes, so the whole UI
 * re-tints live when the user picks another theme. Outside composition it
 * simply returns the current value.
 */
val AccentCyan: Color get() = NovaThemeState.accent.value

@Composable
fun NovaTheme(content: @Composable () -> Unit) {
    val themeId by Prefs.theme.collectAsState()
    LaunchedEffect(themeId) { NovaThemeState.apply(themeId) }
    val colors = darkColorScheme(
        primary = AccentCyan,
        onPrimary = Color.Black,
        secondary = AccentViolet,
        onSecondary = Color.White,
        background = BgDark,
        onBackground = TextPrimary,
        surface = CardDark,
        onSurface = TextPrimary,
        surfaceVariant = CardElevated,
        onSurfaceVariant = TextSecondary,
        error = LiveRed,
        outline = BorderSubtle
    )
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
