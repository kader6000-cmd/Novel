package com.novaiptv.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

const val DEFAULT_UA =
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

class Http(val client: OkHttpClient) {

    suspend fun get(url: String, ua: String = DEFAULT_UA, headers: Map<String, String> = emptyMap()): String =
        withContext(Dispatchers.IO) {
            client.newCall(request(url, ua, headers)).execute().use { r ->
                if (!r.isSuccessful) throw IOException("خطأ من السيرفر: HTTP ${r.code}")
                r.body?.string().orEmpty()
            }
        }

    /** قراءة سطرية لملفات M3U الكبيرة (blocking — استدعِها من IO) */
    fun reader(url: String, ua: String = DEFAULT_UA): BufferedReader {
        val r = client.newCall(request(url, ua, emptyMap())).execute()
        if (!r.isSuccessful) {
            val code = r.code
            r.close()
            throw IOException("خطأ من السيرفر: HTTP $code")
        }
        val body = r.body
        if (body == null) {
            r.close()
            throw IOException("رد فارغ من السيرفر")
        }
        return BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 64 * 1024)
    }

    private fun request(url: String, ua: String, headers: Map<String, String>): Request =
        Request.Builder().url(url).header("User-Agent", ua).apply {
            headers.forEach { (k, v) -> header(k, v) }
        }.build()
}
