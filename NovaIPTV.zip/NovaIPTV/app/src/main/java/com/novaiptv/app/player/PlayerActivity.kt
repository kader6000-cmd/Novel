package com.novaiptv.app.player

import android.content.Context
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.util.Rational
import android.os.Bundle
import android.app.Activity
import android.graphics.Typeface
import android.media.AudioManager
import android.util.TypedValue
import android.view.WindowManager
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.media3.ui.CaptionStyleCompat
import com.novaiptv.app.data.EpgEntry
import com.novaiptv.app.data.ProviderFactory
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.PlaylistPlay
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.novaiptv.app.data.ContentKind
import com.novaiptv.app.data.HttpClient
import com.novaiptv.app.data.IptvRepository
import com.novaiptv.app.data.Prefs
import com.novaiptv.app.i18n.AppLanguage
import com.novaiptv.app.i18n.LocalStrings
import com.novaiptv.app.i18n.stringsFor
import com.novaiptv.app.ui.AccentCyan
import com.novaiptv.app.ui.AccentViolet
import com.novaiptv.app.ui.NovaTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class PlayerActivity : ComponentActivity() {

    companion object {
        fun launch(context: Context, queue: List<QueueItem>, startIndex: Int, sectionTitle: String) {
            PlayQueue.setQueue(queue, startIndex, sectionTitle)
            context.startActivity(Intent(context, PlayerActivity::class.java))
        }
    }

    private var player: ExoPlayer? = null
    private lateinit var repo: IptvRepository
    private val inPipState = mutableStateOf(false)

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()

        repo = IptvRepository(applicationContext)

        val okHttpFactory = OkHttpDataSource.Factory(HttpClient.client)
            .setUserAgent(HttpClient.USER_AGENT)
        val dataSourceFactory = DefaultDataSource.Factory(applicationContext, okHttpFactory)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 60_000, 1_500, 3_000)
            .build()

        // Shared player: kept in PlayerHolder so audio survives the activity
        // (background playback via PlayerService). Reuse it when the user
        // re-opens the player while the same item is still playing.
        val resumeExisting = PlayerHolder.player?.isPlaying == true &&
            PlayQueue.current()?.url?.isNotBlank() == true &&
            PlayQueue.current()?.url == PlayerHolder.currentUrl
        val exo = PlayerHolder.player ?: ExoPlayer.Builder(applicationContext)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .setLoadControl(loadControl)
            .build().also { PlayerHolder.player = it }
        player = exo

        setContent {
            val langCode by Prefs.language.collectAsState()
            val appLang = remember(langCode) { AppLanguage.fromCode(langCode) }
            val strings = remember(appLang) { stringsFor(appLang) }
            val layoutDir = if (appLang.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
            val isInPip by inPipState

            NovaTheme {
                CompositionLocalProvider(
                    LocalLayoutDirection provides layoutDir,
                    LocalStrings provides strings
                ) {
                    PlayerScreen(
                        exoPlayer = exo,
                        isInPip = isInPip,
                        resumeExisting = resumeExisting,
                        onEnterPip = { enterPip() },
                        onBack = { finish() },
                        loadEpg = { item ->
                            if (item.kind == ContentKind.LIVE) {
                                val srv = repo.getActiveServer()
                                if (srv != null) ProviderFactory.create(srv).loadShortEpg(item.id) else emptyList()
                            } else emptyList()
                        },
                        getSavedPosition = { item ->
                            if (item.kind != ContentKind.LIVE) {
                                val key = "${item.serverId}_${item.kind.name}_${item.id}"
                                val h = repo.historyDao.getByKey(key)
                                if (h != null && h.positionMs > 5_000L && (h.durationMs <= 0L || h.positionMs < h.durationMs - 10_000L)) {
                                    h.positionMs
                                } else 0L
                            } else 0L
                        },
                        onSaveHistory = { item, pos, dur ->
                            if (item.id.isNotBlank()) {
                                CoroutineScope(Dispatchers.IO).launch {
                                    repo.saveHistory(
                                        serverId = item.serverId,
                                        itemId = item.id,
                                        kind = item.kind,
                                        name = item.title,
                                        logo = item.logo,
                                        streamUrl = item.url,
                                        positionMs = pos,
                                        durationMs = dur
                                    )
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (player?.isPlaying == true) {
            enterPip()
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPipState.value = isInPictureInPictureMode
    }

    override fun onPause() {
        super.onPause()
        // Background playback: never auto-pause when the screen locks or the
        // user leaves the app. The foreground PlayerService keeps the audio
        // alive; PiP handles the Home button. Audio focus (e.g. phone calls)
        // is still handled by ExoPlayer itself.
    }

    override fun onDestroy() {
        if (isFinishing) {
            if (player?.isPlaying == true) {
                // Keep playing in the background: the player stays in
                // PlayerHolder and PlayerService keeps it alive.
            } else {
                PlayerHolder.release()
                PlayerService.stop(this)
            }
        }
        player = null
        super.onDestroy()
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun PlayerScreen(
    exoPlayer: ExoPlayer,
    isInPip: Boolean,
    resumeExisting: Boolean,
    onEnterPip: () -> Unit,
    onBack: () -> Unit,
    loadEpg: suspend (QueueItem) -> List<EpgEntry>,
    getSavedPosition: suspend (QueueItem) -> Long,
    onSaveHistory: (QueueItem, Long, Long) -> Unit
) {
    val s = LocalStrings.current
    val queue = remember { PlayQueue.items }
    val scope = rememberCoroutineScope()
    var currentIndex by remember { mutableIntStateOf(PlayQueue.currentIndex) }
    val currentItem = queue.getOrNull(currentIndex)
    val currentItemState = rememberUpdatedState(currentItem)

    var showControls by remember { mutableStateOf(true) }
    var showPlaylistDrawer by remember { mutableStateOf(false) }
    var showTracksDialog by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var isBuffering by remember { mutableStateOf(exoPlayer.playbackState == Player.STATE_BUFFERING) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var resizeModeIndex by remember { mutableIntStateOf(0) }
    var playlistQuery by remember { mutableStateOf("") }
    var isLocked by remember { mutableStateOf(false) }
    var showUnlockBtn by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    // Sleep timer: deadline lives in PlayerHolder/PlayerService so it keeps
    // working even after leaving the player (background playback).
    var showSleepDialog by remember { mutableStateOf(false) }
    var sleepRemainingMs by remember { mutableLongStateOf(0L) }
    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    var epgList by remember { mutableStateOf<List<EpgEntry>>(emptyList()) }
    var gestureHudText by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val subSize by Prefs.subtitleSizeSp.collectAsState()
    val subColor by Prefs.subtitleColor.collectAsState()

    // Close the player when background playback is stopped from the
    // notification or by the sleep timer.
    LaunchedEffect(Unit) {
        PlayerControl.stopEvents.collect { onBack() }
    }

    LaunchedEffect(currentItem?.id) {
        epgList = emptyList()
        currentItem?.let { item ->
            epgList = runCatching { loadEpg(item) }.getOrDefault(emptyList())
        }
    }

    LaunchedEffect(gestureHudText) {
        if (gestureHudText != null) {
            delay(1200)
            gestureHudText = null
        }
    }

    LaunchedEffect(showUnlockBtn) {
        if (showUnlockBtn) {
            delay(3000)
            showUnlockBtn = false
        }
    }

    val resizeModes = listOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT to "احتواء",
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "ملء الشاشة",
        AspectRatioFrameLayout.RESIZE_MODE_FILL to "تمديد"
    )

    fun playIndex(newIndex: Int) {
        if (newIndex !in queue.indices) return
        currentItem?.let { onSaveHistory(it, exoPlayer.currentPosition, exoPlayer.duration.coerceAtLeast(0L)) }
        currentIndex = newIndex
        PlayQueue.currentIndex = newIndex
        errorMsg = null
        isBuffering = true
        val target = queue[newIndex]
        PlayerHolder.currentItem = target
        PlayerHolder.currentUrl = target.url
        PlayerService.start(context, target.title)
        scope.launch {
            val savedPos = runCatching { getSavedPosition(target) }.getOrDefault(0L)
            exoPlayer.setMediaItem(MediaItem.fromUri(target.url))
            if (savedPos > 0L) {
                exoPlayer.seekTo(savedPos)
            }
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        }
    }

    LaunchedEffect(Unit) {
        if (queue.isNotEmpty() && !resumeExisting) {
            playIndex(currentIndex)
        } else if (queue.isNotEmpty()) {
            // Already playing in the background: just re-attach the UI and
            // make sure the service notification shows the current title.
            currentItem?.let { PlayerService.start(context, it.title) }
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_ENDED) {
                    val item = queue.getOrNull(currentIndex)
                    if (item != null && item.kind != ContentKind.LIVE && currentIndex + 1 < queue.size) {
                        playIndex(currentIndex + 1)
                    }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                errorMsg = "تعذر تشغيل البث (${error.errorCodeName})"
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            // Only save when a real position exists: after an external stop
            // (notification / sleep timer) the player is already released and
            // currentPosition reads 0 — saving that would wipe the resume
            // position the service already stored.
            val pos = runCatching { exoPlayer.currentPosition }.getOrDefault(0L)
            if (pos > 5_000L) {
                currentItem?.let { onSaveHistory(it, pos, exoPlayer.duration.coerceAtLeast(0L)) }
            }
            exoPlayer.removeListener(listener)
        }
    }

    // Update seekbar every 500ms; also refresh the sleep countdown and
    // periodically persist the resume position (so a crash/kill does not
    // lose more than ~10s of progress).
    LaunchedEffect(exoPlayer) {
        var tick = 0
        while (true) {
            positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            val sleepEnd = PlayerHolder.sleepEndsAtMs
            sleepRemainingMs = if (sleepEnd > 0L) {
                (sleepEnd - System.currentTimeMillis()).coerceAtLeast(0L)
            } else 0L
            tick++
            if (tick % 20 == 0) {
                currentItemState.value?.let { item ->
                    if (item.kind != ContentKind.LIVE && positionMs > 5_000L) {
                        onSaveHistory(item, positionMs, durationMs)
                    }
                }
            }
            delay(500)
        }
    }

    // Auto-hide controls after 4 seconds
    LaunchedEffect(showControls, showPlaylistDrawer, isPlaying) {
        if (showControls && !showPlaylistDrawer && isPlaying) {
            delay(4000)
            showControls = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isLocked, showPlaylistDrawer, currentItem?.kind) {
                detectTapGestures(
                    onTap = {
                        if (isLocked) {
                            showUnlockBtn = !showUnlockBtn
                        } else if (showPlaylistDrawer) {
                            showPlaylistDrawer = false
                        } else {
                            showControls = !showControls
                        }
                    },
                    onDoubleTap = { offset ->
                        if (!isLocked && currentItem?.kind != ContentKind.LIVE) {
                            val isRight = offset.x > size.width / 2f
                            if (isRight) {
                                exoPlayer.seekTo(exoPlayer.currentPosition + 10_000)
                                gestureHudText = "+10s ⏩"
                            } else {
                                exoPlayer.seekTo((exoPlayer.currentPosition - 10_000).coerceAtLeast(0))
                                gestureHudText = "⏪ -10s"
                            }
                        }
                    }
                )
            }
            .pointerInput(isLocked) {
                var dragStartX = 0f
                detectVerticalDragGestures(
                    onDragStart = { offset -> dragStartX = offset.x },
                    onVerticalDrag = { _, dragAmount ->
                        if (isLocked) return@detectVerticalDragGestures
                        val delta = -dragAmount / (size.height.coerceAtLeast(1) * 0.6f)
                        if (dragStartX < size.width / 2f) {
                            // Left half: Brightness
                            activity?.window?.let { win ->
                                val lp = win.attributes
                                val cur = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                val next = (cur + delta).coerceIn(0.05f, 1.0f)
                                lp.screenBrightness = next
                                win.attributes = lp
                                gestureHudText = "☀️ السطوع ${(next * 100).toInt()}%"
                            }
                        } else {
                            // Right half: Volume
                            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                            val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                            if (kotlin.math.abs(dragAmount) > 12f) {
                                val step = if (dragAmount < 0) 1 else -1
                                val nextVol = (curVol + step).coerceIn(0, maxVol)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                                gestureHudText = "🔊 الصوت ${(nextVol * 100) / maxVol}%"
                            }
                        }
                    }
                )
            }
    ) {
        // Video Surface
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = resizeModes[resizeModeIndex].first
                }
            },
            update = { view ->
                view.resizeMode = resizeModes[resizeModeIndex].first
                view.subtitleView?.apply {
                    setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subSize)
                    setStyle(
                        CaptionStyleCompat(
                            subColor,
                            0x88000000.toInt(),
                            android.graphics.Color.TRANSPARENT,
                            CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                            android.graphics.Color.BLACK,
                            Typeface.DEFAULT_BOLD
                        )
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Buffering spinner
        if (isBuffering) {
            CircularProgressIndicator(
                color = AccentCyan,
                modifier = Modifier.align(Alignment.Center).size(48.dp)
            )
        }

        // Gesture HUD (Brightness / Volume / Double-Tap Seek)
        gestureHudText?.let { hud ->
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xCC0D111A))
                    .border(1.dp, AccentCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(hud, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        // Unlock button when Screen Lock is active
        if (isLocked && showUnlockBtn && !isInPip) {
            Button(
                onClick = {
                    isLocked = false
                    showControls = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black),
                modifier = Modifier.align(Alignment.TopEnd).padding(20.dp)
            ) {
                Icon(Icons.Default.LockOpen, contentDescription = "فتح القفل", modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("فتح القفل", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        // Error overlay
        errorMsg?.let { msg ->
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xDD141824))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(8.dp))
                Text(msg, color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { playIndex(currentIndex) },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
                ) {
                    Text("إعادة المحاولة", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Controls Overlay
        AnimatedVisibility(
            visible = showControls && !showPlaylistDrawer && !isInPip && !isLocked,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xBB000000), Color(0x22000000), Color(0xCC000000))
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentItem?.title ?: "",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (!currentItem?.subtitle.isNullOrBlank()) {
                            Text(
                                text = currentItem?.subtitle ?: "",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                    }

                    // Playback Speed (VOD / Series)
                    if (currentItem?.kind != ContentKind.LIVE) {
                        FilledTonalButton(
                            onClick = {
                                val nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.size
                                playbackSpeed = speeds[nextIdx]
                                exoPlayer.setPlaybackSpeed(playbackSpeed)
                            },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0x66FFFFFF),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("${playbackSpeed}x", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(6.dp))
                    }

                    // Screen Lock Toggle
                    IconButton(
                        onClick = {
                            isLocked = true
                            showControls = false
                            showUnlockBtn = true
                        },
                        modifier = Modifier.clip(CircleShape).background(Color(0x55FFFFFF))
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "قفل الشاشة", tint = Color.White)
                    }
                    Spacer(Modifier.width(6.dp))

                    // Sleep Timer
                    IconButton(
                        onClick = { showSleepDialog = true },
                        modifier = Modifier.clip(CircleShape).background(Color(0x55FFFFFF))
                    ) {
                        Icon(
                            Icons.Default.Bedtime,
                            contentDescription = "مؤقت النوم",
                            tint = if (sleepRemainingMs > 0L) AccentCyan else Color.White
                        )
                    }
                    Spacer(Modifier.width(6.dp))

                    // Aspect Ratio Toggle
                    FilledTonalButton(
                        onClick = { resizeModeIndex = (resizeModeIndex + 1) % resizeModes.size },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0x66FFFFFF),
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.AspectRatio, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(resizeModes[resizeModeIndex].second, fontSize = 12.sp)
                    }

                    Spacer(Modifier.width(8.dp))

                    // Picture-in-Picture button
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        IconButton(
                            onClick = onEnterPip,
                            modifier = Modifier.clip(CircleShape).background(Color(0x55FFFFFF))
                        ) {
                            Icon(Icons.Default.PictureInPictureAlt, contentDescription = s.pipMode, tint = Color.White)
                        }
                        Spacer(Modifier.width(8.dp))
                    }

                    // Audio/Subtitle tracks
                    IconButton(
                        onClick = { showTracksDialog = true },
                        modifier = Modifier.clip(CircleShape).background(Color(0x55FFFFFF))
                    ) {
                        Icon(Icons.Default.Subtitles, contentDescription = s.tracksTitle, tint = Color.White)
                    }

                    Spacer(Modifier.width(8.dp))

                    // In-Player Playlist Drawer Button
                    if (queue.size > 1) {
                        Button(
                            onClick = {
                                showPlaylistDrawer = true
                                showControls = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AccentCyan,
                                contentColor = Color.Black
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.PlaylistPlay, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("القائمة (${queue.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                // Center Playback Controls
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    if (queue.size > 1) {
                        IconButton(
                            onClick = { if (currentIndex > 0) playIndex(currentIndex - 1) },
                            enabled = currentIndex > 0,
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000))
                        ) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "السابق", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }

                    if (currentItem?.kind != ContentKind.LIVE) {
                        IconButton(
                            onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10_000).coerceAtLeast(0)) },
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000))
                        ) {
                            Icon(Icons.Default.Replay10, contentDescription = "-10s", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }

                    IconButton(
                        onClick = {
                            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                        },
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(AccentCyan)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "تشغيل/إيقاف",
                            tint = Color.Black,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    if (currentItem?.kind != ContentKind.LIVE) {
                        IconButton(
                            onClick = { exoPlayer.seekTo(exoPlayer.currentPosition + 10_000) },
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000))
                        ) {
                            Icon(Icons.Default.Forward10, contentDescription = "+10s", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }

                    if (queue.size > 1) {
                        IconButton(
                            onClick = { if (currentIndex + 1 < queue.size) playIndex(currentIndex + 1) },
                            enabled = currentIndex + 1 < queue.size,
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0x66000000))
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = "التالي", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }
                }

                // Bottom Bar (Live badge OR Seekbar)
                Column(
                    modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                ) {
                    if (sleepRemainingMs > 0L) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bedtime, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(
                                "مؤقت النوم: ${formatTime(sleepRemainingMs)}",
                                color = AccentCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    if (currentItem?.kind == ContentKind.LIVE || durationMs <= 0L) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFF3D57))
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("بث مباشر", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        if (epgList.isNotEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            val now = epgList.first()
                            Text(
                                text = "يُعرض الآن: ${now.title} (${now.start} - ${now.end})",
                                color = AccentCyan,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            epgList.getOrNull(1)?.let { next ->
                                Text(
                                    text = "التالي: ${next.title} (${next.start})",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    } else {
                        Slider(
                            value = positionMs.toFloat().coerceIn(0f, durationMs.toFloat().coerceAtLeast(1f)),
                            onValueChange = { exoPlayer.seekTo(it.toLong()) },
                            valueRange = 0f..durationMs.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = AccentCyan,
                                activeTrackColor = AccentCyan,
                                inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                            )
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(formatTime(positionMs), color = Color.White, fontSize = 12.sp)
                            Text(formatTime(durationMs), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Slide-Over In-Player Playlist Drawer
        AnimatedVisibility(
            visible = showPlaylistDrawer && !isInPip,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.CenterStart)
        ) {
            val listState = rememberLazyListState()
            LaunchedEffect(showPlaylistDrawer) {
                if (showPlaylistDrawer && currentIndex in queue.indices) {
                    listState.scrollToItem((currentIndex - 2).coerceAtLeast(0))
                }
            }

            val filtered = remember(queue, playlistQuery) {
                if (playlistQuery.isBlank()) queue.mapIndexed { i, item -> i to item }
                else queue.mapIndexedNotNull { i, item ->
                    if (item.title.contains(playlistQuery, ignoreCase = true)) i to item else null
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(340.dp)
                    .background(Color(0xEE0D111A))
                    .border(1.dp, AccentCyan.copy(alpha = 0.2f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {}
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = PlayQueue.sectionTitle,
                        color = AccentCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { showPlaylistDrawer = false }) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
                    }
                }

                OutlinedTextField(
                    value = playlistQuery,
                    onValueChange = { playlistQuery = it },
                    placeholder = { Text("بحث في القائمة...", fontSize = 13.sp, color = Color.Gray) },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AccentCyan) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentCyan,
                        unfocusedBorderColor = Color(0xFF2B3245)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                )

                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(filtered) { _, (origIndex, item) ->
                        val isCurrent = origIndex == currentIndex
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isCurrent) AccentCyan.copy(alpha = 0.2f) else Color(0xFF161C29))
                                .border(
                                    width = if (isCurrent) 1.5.dp else 0.dp,
                                    color = if (isCurrent) AccentCyan else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    playIndex(origIndex)
                                    showPlaylistDrawer = false
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0A0D14)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (item.logo.isNotBlank()) {
                                    AsyncImage(
                                        model = item.logo,
                                        contentDescription = item.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        if (item.kind == ContentKind.LIVE) Icons.Default.LiveTv else Icons.Default.Movie,
                                        contentDescription = null,
                                        tint = AccentViolet
                                    )
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    color = if (isCurrent) AccentCyan else Color.White,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (isCurrent) {
                                    Text("جاري التشغيل الآن", color = AccentCyan.copy(alpha = 0.85f), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sleep Timer Dialog
        if (showSleepDialog) {
            AlertDialog(
                onDismissRequest = { showSleepDialog = false },
                containerColor = Color(0xFF151A24),
                titleContentColor = Color.White,
                textContentColor = Color.White,
                title = { Text("مؤقت النوم", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (sleepRemainingMs > 0L) {
                            Text(
                                "النشط حالياً: متبقٍ ${formatTime(sleepRemainingMs)}",
                                color = AccentCyan,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(6.dp))
                        }
                        Text(
                            "سيتوقف التشغيل تلقائياً ويُغلق المشغّل عند انتهاء الوقت، حتى لو خرجت من التطبيق.",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        listOf(0 to "إيقاف المؤقت", 15 to "15 دقيقة", 30 to "30 دقيقة", 60 to "60 دقيقة", 90 to "90 دقيقة").forEach { (minutes, label) ->
                            val selected = if (minutes == 0) sleepRemainingMs == 0L
                            else sleepRemainingMs > 0L &&
                                kotlin.math.abs(minutes * 60_000L - sleepRemainingMs) < 8 * 60_000L
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        PlayerService.setSleepTimer(context, minutes)
                                        showSleepDialog = false
                                    }
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = selected, onClick = null)
                                Spacer(Modifier.width(8.dp))
                                Text(label, color = Color.White, fontSize = 14.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSleepDialog = false }) { Text("إغلاق", color = AccentCyan) }
                }
            )
        }

        // Audio / Subtitle Tracks Dialog
        if (showTracksDialog) {
            TracksDialog(
                exoPlayer = exoPlayer,
                onDismiss = { showTracksDialog = false }
            )
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun TracksDialog(exoPlayer: ExoPlayer, onDismiss: () -> Unit) {
    val groups = exoPlayer.currentTracks.groups
    val audioTracks = groups.filter { it.type == C.TRACK_TYPE_AUDIO }
    val textTracks = groups.filter { it.type == C.TRACK_TYPE_TEXT }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF151A24),
        titleContentColor = Color.White,
        textContentColor = Color.White,
        title = { Text("مسارات الصوت والترجمة", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الصوت:", color = AccentCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                if (audioTracks.isEmpty()) {
                    Text("الافتراضي", color = Color.Gray, fontSize = 12.sp)
                } else {
                    audioTracks.forEachIndexed { idx, group ->
                        val fmt = group.getTrackFormat(0)
                        val label = fmt.label ?: fmt.language ?: "مسار صوت ${idx + 1}"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                        .buildUpon()
                                        .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, 0))
                                        .build()
                                    onDismiss()
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = group.isSelected, onClick = null)
                            Spacer(Modifier.width(8.dp))
                            Text(label, color = Color.White, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("الترجمة:", color = AccentCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                .buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                .build()
                            onDismiss()
                        }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("إيقاف الترجمة", color = Color.White, fontSize = 13.sp)
                }
                textTracks.forEachIndexed { idx, group ->
                    val fmt = group.getTrackFormat(0)
                    val label = fmt.label ?: fmt.language ?: "ترجمة ${idx + 1}"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, 0))
                                    .build()
                                onDismiss()
                            }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = group.isSelected, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Text(label, color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق", color = AccentCyan) }
        }
    )
}

private fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) String.format("%02d:%02d:%02d", h, m, s)
    else String.format("%02d:%02d", m, s)
}
