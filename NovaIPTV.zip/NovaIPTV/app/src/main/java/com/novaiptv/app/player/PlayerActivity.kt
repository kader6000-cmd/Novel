@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.novaiptv.app.player

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.novaiptv.app.App
import com.novaiptv.app.data.*
import com.novaiptv.app.ui.Accent
import com.novaiptv.app.ui.Accent2
import com.novaiptv.app.ui.NovaTheme
import com.novaiptv.app.ui.Surface1
import com.novaiptv.app.ui.TextDim
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** طابور التشغيل الحالي (قنوات أو حلقات) */
object PlayQueue {
    var items: List<Content> = emptyList()
    var index: Int = 0
    fun set(list: List<Content>, i: Int) { items = list; index = i }
}

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as App
        val items = PlayQueue.items
        if (items.isEmpty()) { finish(); return }

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        lifecycleScope.launch {
            val start = PlayQueue.index.coerceIn(0, items.lastIndex)
            val server = app.db.servers().get(items[start].serverId)
            val ua = server?.userAgent?.ifBlank { null } ?: DEFAULT_UA
            val okFactory = OkHttpDataSource.Factory(app.http.client).setUserAgent(ua)
            val dsFactory = DefaultDataSource.Factory(this@PlayerActivity, okFactory)
            val exo = ExoPlayer.Builder(this@PlayerActivity)
                .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
                .build()
            player = exo
            setContent {
                NovaTheme { PlayerScreen(exo, items, start, app) { finish() } }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        val exo = player ?: return
        val c = PlayQueue.items.getOrNull(PlayQueue.index)
        if (c != null && c.kind != Kind.LIVE && exo.duration > 0) {
            val pos = exo.currentPosition
            val dur = exo.duration
            val app = application as App
            app.appScope.launch {
                app.db.history().upsert(HistoryEntity(c.key, c.serverId, c.toJson(), pos, dur, System.currentTimeMillis()))
            }
        }
        exo.pause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

private data class TrackOption(val label: String, val groupIndex: Int, val trackIndex: Int, val selected: Boolean)

@Composable
private fun PlayerScreen(exo: ExoPlayer, items: List<Content>, start: Int, app: App, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var index by remember { mutableIntStateOf(start.coerceIn(0, items.lastIndex)) }
    var showList by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val resizeModes = remember {
        listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT to "ملائم (Fit)",
            AspectRatioFrameLayout.RESIZE_MODE_FILL to "ملء الشاشة (Fill)",
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "تقريب (Zoom)"
        )
    }
    var resizeIndex by remember { mutableIntStateOf(0) }

    val speeds = remember { listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f) }
    var speedIndex by remember { mutableIntStateOf(1) }

    var showTracksDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun startItem(i: Int) {
        scope.launch {
            index = i
            PlayQueue.index = i
            error = null
            val c = items[i]
            try {
                val url = app.repo.playUrl(c)
                val h = if (c.kind == Kind.LIVE) null else app.db.history().get(c.key)
                val resumeAt = if (h != null && h.positionMs > 5_000 &&
                    (h.durationMs <= 0 || h.positionMs < h.durationMs - 20_000)) h.positionMs else 0L
                exo.setMediaItem(MediaItem.fromUri(url), resumeAt)
                exo.prepare()
                exo.playWhenReady = true
                app.db.history().upsert(
                    HistoryEntity(c.key, c.serverId, c.toJson(), resumeAt, h?.durationMs ?: 0, System.currentTimeMillis())
                )
            } catch (e: Exception) {
                error = e.message ?: "تعذّر التشغيل"
            }
        }
    }

    LaunchedEffect(Unit) { startItem(index) }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    val c = items[index]
                    if (c.kind != Kind.LIVE) {
                        val d = exo.duration.coerceAtLeast(0)
                        app.appScope.launch {
                            app.db.history().upsert(HistoryEntity(c.key, c.serverId, c.toJson(), d, d, System.currentTimeMillis()))
                        }
                        if (index + 1 < items.size) startItem(index + 1)
                    }
                }
            }
            override fun onPlayerError(e: PlaybackException) {
                error = "تعذّر تشغيل هذا المحتوى (${e.errorCodeName})"
            }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }

    // حفظ موضع المشاهدة كل 5 ثوانٍ
    LaunchedEffect(index) {
        while (true) {
            delay(5000)
            val c = items[index]
            if (c.kind != Kind.LIVE && exo.playbackState == Player.STATE_READY) {
                app.db.history().upsert(
                    HistoryEntity(c.key, c.serverId, c.toJson(), exo.currentPosition, exo.duration.coerceAtLeast(0), System.currentTimeMillis())
                )
            }
        }
    }

    BackHandler {
        when {
            locked -> Toast.makeText(ctx, "الشاشة مقفلة — اضغط على القفل لفتحها", Toast.LENGTH_SHORT).show()
            showList -> showList = false
            else -> onBack()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PlayerView(context).apply {
                    player = exo
                    useController = !locked
                    resizeMode = resizeModes[resizeIndex].first
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> controls = v == View.VISIBLE })
                }
            },
            update = { view ->
                view.useController = !locked
                view.resizeMode = resizeModes[resizeIndex].first
            }
        )

        // زر فك القفل عند تفعيل قفل اللمس
        if (locked) {
            IconButton(
                onClick = { locked = false; controls = true },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
                    .clip(CircleShape)
                    .background(Color(0x99000000))
            ) {
                Icon(Icons.Rounded.Lock, contentDescription = "فك القفل", tint = Accent2)
            }
        }

        AnimatedVisibility(visible = (!locked && controls) || error != null, modifier = Modifier.align(Alignment.TopCenter)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xDD000000), Color.Transparent)))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White) }
                Text(
                    items[index].display,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                // زر تغيير أبعاد الشاشة Aspect Ratio
                IconButton(
                    onClick = {
                        resizeIndex = (resizeIndex + 1) % resizeModes.size
                        Toast.makeText(ctx, resizeModes[resizeIndex].second, Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Rounded.AspectRatio, "أبعاد الشاشة", tint = Color.White)
                }

                // زر سرعة التشغيل للأفلام والمسلسلات
                if (items[index].kind != Kind.LIVE) {
                    TextButton(
                        onClick = {
                            speedIndex = (speedIndex + 1) % speeds.size
                            exo.setPlaybackSpeed(speeds[speedIndex])
                        }
                    ) {
                        Text("${speeds[speedIndex]}x", color = Accent2, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                // زر اختيار الصوت والترجمة
                IconButton(onClick = { showTracksDialog = true }) {
                    Icon(Icons.Rounded.Subtitles, "الصوت والترجمة", tint = Color.White)
                }

                // زر قفل الشاشة
                IconButton(onClick = { locked = true }) {
                    Icon(Icons.Rounded.LockOpen, "قفل الشاشة", tint = Color.White)
                }

                if (items.size > 1) {
                    IconButton(onClick = { if (index > 0) startItem(index - 1) }) { Icon(Icons.Rounded.SkipPrevious, null, tint = Color.White) }
                    IconButton(onClick = { if (index < items.lastIndex) startItem(index + 1) }) { Icon(Icons.Rounded.SkipNext, null, tint = Color.White) }
                    IconButton(onClick = { showList = !showList }) { Icon(Icons.Rounded.PlaylistPlay, null, tint = Accent2) }
                }
            }
        }

        error?.let { msg ->
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(msg, color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { startItem(index) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
            }
        }

        AnimatedVisibility(visible = showList && !locked, modifier = Modifier.align(Alignment.CenterEnd)) {
            Surface(Modifier.width(330.dp).fillMaxHeight(), color = Color(0xEE0B0E17)) {
                val ls = rememberLazyListState()
                LaunchedEffect(Unit) { ls.scrollToItem((index - 2).coerceAtLeast(0)) }
                Column {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("القائمة (${items.size})", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        IconButton(onClick = { showList = false }) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
                    }
                    LazyColumn(state = ls) {
                        itemsIndexed(items) { i, c ->
                            val cur = i == index
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .background(if (cur) Accent.copy(alpha = 0.25f) else Color.Transparent)
                                    .clickable { startItem(i); showList = false }
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                Text(
                                    if (c.kind == Kind.EPISODE) "م${c.season} · ح${c.episode}  ${c.title}" else c.title,
                                    color = if (cur) Accent2 else Color(0xFFD0D5E2),
                                    fontSize = 14.sp,
                                    fontWeight = if (cur) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (c.kind == Kind.LIVE && c.group.isNotBlank())
                                    Text(c.group, color = TextDim, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }

        if (showTracksDialog) {
            TracksDialog(exo = exo, onDismiss = { showTracksDialog = false })
        }
    }
}

@Composable
private fun TracksDialog(exo: ExoPlayer, onDismiss: () -> Unit) {
    val groups = exo.currentTracks.groups
    val audioTracks = remember(groups) {
        val list = ArrayList<TrackOption>()
        groups.forEachIndexed { gIdx, g ->
            if (g.type == C.TRACK_TYPE_AUDIO) {
                for (tIdx in 0 until g.length) {
                    val fmt = g.getTrackFormat(tIdx)
                    val label = listOfNotNull(
                        fmt.label,
                        fmt.language,
                        if (fmt.channelCount > 0) "${fmt.channelCount}ch" else null
                    ).joinToString(" · ").ifBlank { "مسار صوتي ${list.size + 1}" }
                    list += TrackOption(label, gIdx, tIdx, g.isTrackSelected(tIdx))
                }
            }
        }
        list
    }

    val textTracks = remember(groups) {
        val list = ArrayList<TrackOption>()
        groups.forEachIndexed { gIdx, g ->
            if (g.type == C.TRACK_TYPE_TEXT) {
                for (tIdx in 0 until g.length) {
                    val fmt = g.getTrackFormat(tIdx)
                    val label = listOfNotNull(fmt.label, fmt.language).joinToString(" · ").ifBlank { "ترجمة ${list.size + 1}" }
                    list += TrackOption(label, gIdx, tIdx, g.isTrackSelected(tIdx))
                }
            }
        }
        list
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("الصوت والترجمة", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المسار الصوتي", color = Accent2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                if (audioTracks.isEmpty()) {
                    Text("مسار صوتي افتراضي", color = TextDim, fontSize = 12.sp)
                } else {
                    audioTracks.forEach { t ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    val g = groups[t.groupIndex].mediaTrackGroup
                                    exo.trackSelectionParameters = exo.trackSelectionParameters
                                        .buildUpon()
                                        .setOverrideForType(TrackSelectionOverride(g, t.trackIndex))
                                        .build()
                                    onDismiss()
                                }
                                .padding(vertical = 6.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = t.selected, onClick = null)
                            Spacer(Modifier.width(8.dp))
                            Text(t.label, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("الترجمة", color = Accent2, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            exo.trackSelectionParameters = exo.trackSelectionParameters
                                .buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                .build()
                            onDismiss()
                        }
                        .padding(vertical = 6.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = textTracks.none { it.selected }, onClick = null)
                    Spacer(Modifier.width(8.dp))
                    Text("إيقاف الترجمة", fontSize = 13.sp)
                }
                textTracks.forEach { t ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                val g = groups[t.groupIndex].mediaTrackGroup
                                exo.trackSelectionParameters = exo.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                    .setOverrideForType(TrackSelectionOverride(g, t.trackIndex))
                                    .build()
                                onDismiss()
                            }
                            .padding(vertical = 6.dp, horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = t.selected, onClick = null)
                        Spacer(Modifier.width(8.dp))
                        Text(t.label, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}
