@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.novaiptv.app.player

import android.content.Context
import android.content.res.Configuration
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.novaiptv.app.App
import com.novaiptv.app.data.*
import com.novaiptv.app.ui.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

/** طابور التشغيل الحالي (قنوات أو حلقات) — يُمرَّر للمشغّل دون تسلسل */
object PlayQueue {
    var items: List<Content> = emptyList()
    var index: Int = 0
    fun set(list: List<Content>, i: Int) { items = list; index = i }
}

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val app = application as App
        val items = PlayQueue.items
        if (items.isEmpty()) { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        lifecycleScope.launch {
            val start = PlayQueue.index.coerceIn(0, items.lastIndex)
            val server = app.db.servers().get(items[start].serverId)
            val ua = server?.userAgent?.ifBlank { null } ?: DEFAULT_UA
            val okFactory = OkHttpDataSource.Factory(app.http.client).setUserAgent(ua)
            val dsFactory = DefaultDataSource.Factory(this@PlayerActivity, okFactory)
            val exo = ExoPlayer.Builder(this@PlayerActivity)
                .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
                .setHandleAudioBecomingNoisy(true)
                .build()
            exo.setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
            )
            player = exo
            setContent { NovaTheme { PlayerScreen(this@PlayerActivity, exo, items, start, app) } }
        }
    }

    override fun onStop() {
        super.onStop()
        val exo = player ?: return
        val c = PlayQueue.items.getOrNull(PlayQueue.index)
        if (c != null && c.kind != Kind.LIVE && exo.duration > 0) {
            val pos = exo.currentPosition
            val dur = exo.duration
            val app = application as App
            app.appScope.launch {
                app.db.history().upsert(HistoryEntity(c.key, c.serverId, c.toJson(), pos, dur, System.currentTimeMillis()))
            }
        }
        exo.pause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

/* ───────────────────────── حالة المشغّل ───────────────────────── */

private class PState(
    val exo: ExoPlayer, val items: List<Content>, val app: App, val scope: CoroutineScope, start: Int
) {
    var index by mutableIntStateOf(start)
    var controls by mutableStateOf(true)
    var bump by mutableIntStateOf(0)
    var locked by mutableStateOf(false)
    var showList by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var playing by mutableStateOf(false)
    var buffering by mutableStateOf(true)
    val pos = mutableLongStateOf(0L)
    val dur = mutableLongStateOf(0L)
    var speed by mutableFloatStateOf(1f)
    var resize by mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT)
    var hud by mutableStateOf<String?>(null)
    var dialog by mutableStateOf<Int?>(null)      // نوع المسار: C.TRACK_TYPE_AUDIO / TEXT
    var volF = 0f
    var retries = 0

    val cur: Content get() = items[index]

    fun touch() { controls = true; bump++ }

    fun startItem(i: Int) {
        scope.launch {
            index = i
            PlayQueue.index = i
            error = null
            val c = items[i]
            try {
                val url = app.repo.playUrl(c)
                val h = if (c.kind == Kind.LIVE) null else app.db.history().get(c.key)
                val resumeAt = if (h != null && h.positionMs > 5_000 &&
                    (h.durationMs <= 0 || h.positionMs < h.durationMs - 20_000)) h.positionMs else 0L
                exo.setMediaItem(MediaItem.fromUri(url), resumeAt)
                exo.prepare()
                exo.playWhenReady = true
                app.db.history().upsert(
                    HistoryEntity(c.key, c.serverId, c.toJson(), resumeAt, h?.durationMs ?: 0, System.currentTimeMillis())
                )
            } catch (e: Exception) {
                error = e.message ?: "تعذّر التشغيل"
            }
        }
    }

    fun seekBy(deltaMs: Long) {
        val d = exo.duration
        val target = exo.currentPosition + deltaMs
        exo.seekTo(if (d > 0) target.coerceIn(0L, d) else target.coerceAtLeast(0L))
        hud = if (deltaMs > 0) "⏩ ${deltaMs / 1000} ث" else "⏪ ${-deltaMs / 1000} ث"
    }
}

private fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%02d:%02d", m, sec)
}

/* ───────────────────────── الشاشة ───────────────────────── */

@Composable
private fun PlayerScreen(activity: ComponentActivity, exo: ExoPlayer, items: List<Content>, start: Int, app: App) {
    val scope = rememberCoroutineScope()
    val s = remember { PState(exo, items, app, scope, start.coerceIn(0, items.lastIndex)) }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    LaunchedEffect(Unit) { s.startItem(s.index) }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { s.playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                s.buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) s.retries = 0
                if (state == Player.STATE_ENDED) {
                    val c = items[s.index]
                    if (c.kind != Kind.LIVE) {
                        val d = exo.duration.coerceAtLeast(0)
                        app.appScope.launch {
                            app.db.history().upsert(HistoryEntity(c.key, c.serverId, c.toJson(), d, d, System.currentTimeMillis()))
                        }
                        if (s.index + 1 < items.size) s.startItem(s.index + 1)
                    }
                }
            }
            override fun onPlayerError(e: PlaybackException) {
                if (items[s.index].kind == Kind.LIVE && s.retries < 3) {
                    s.retries++
                    scope.launch { delay(2000); s.startItem(s.index) }
                } else {
                    s.error = "تعذّر تشغيل هذا المحتوى (${e.errorCodeName})"
                }
            }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }

    // مؤشر التقدم
    LaunchedEffect(Unit) {
        while (true) {
            s.pos.longValue = exo.currentPosition
            s.dur.longValue = exo.duration.coerceAtLeast(0)
            delay(500)
        }
    }
    // حفظ موضع المشاهدة كل 5 ثوانٍ
    LaunchedEffect(s.index) {
        while (true) {
            delay(5000)
            val c = items[s.index]
            if (c.kind != Kind.LIVE && exo.playbackState == Player.STATE_READY) {
                app.db.history().upsert(
                    HistoryEntity(c.key, c.serverId, c.toJson(), exo.currentPosition, exo.duration.coerceAtLeast(0), System.currentTimeMillis())
                )
            }
        }
    }
    // إخفاء الأزرار تلقائياً
    LaunchedEffect(s.controls, s.playing, s.bump) {
        if (s.controls && s.playing) { delay(4000); s.controls = false }
    }
    LaunchedEffect(s.hud) { if (s.hud != null) { delay(900); s.hud = null } }
    // أشرطة النظام: مخفية في العرض الأفقي
    LaunchedEffect(landscape) {
        val c = WindowInsetsControllerCompat(activity.window, activity.window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (landscape) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }

    BackHandler { if (landscape && s.showList) s.showList = false else activity.finish() }

    val toggleOrientation = {
        activity.requestedOrientation =
            if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    if (landscape) {
        Row(Modifier.fillMaxSize().background(Color.Black)) {
            Box(Modifier.weight(1f).fillMaxHeight()) { VideoSurface(activity, s, true, toggleOrientation) }
            if (s.showList && items.size > 1) {
                PlaylistPanel(s, Modifier.width(340.dp).fillMaxHeight().background(Bg)) { s.showList = false }
            }
        }
    } else {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Box(Modifier.fillMaxWidth().background(Color.Black).statusBarsPadding().aspectRatio(16f / 9f)) {
                VideoSurface(activity, s, false, toggleOrientation)
            }
            if (items.size > 1) {
                PlaylistPanel(s, Modifier.weight(1f).fillMaxWidth().navigationBarsPadding(), null)
            } else {
                Column(Modifier.padding(16.dp)) {
                    Text(s.cur.display, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    if (s.cur.plot.isNotBlank()) Text(s.cur.plot, color = TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }

    s.dialog?.let { type -> TrackDialog(s, type) { s.dialog = null } }
}

/* ───────────────────────── منطقة الفيديو + عناصر التحكم ───────────────────────── */

@Composable
private fun VideoSurface(activity: ComponentActivity, s: PState, landscape: Boolean, onRotate: () -> Unit) {
    val isLive = s.cur.kind == Kind.LIVE
    val favKeys by remember(s.cur.serverId) { s.app.db.favorites().keys(s.cur.serverId) }.collectAsState(initial = emptyList())
    val isFav = s.cur.key in favKeys

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = s.exo
                    useController = false
                    resizeMode = s.resize
                }
            },
            update = { it.resizeMode = s.resize }
        )

        // طبقة اللمس: نقرة = إظهار/إخفاء، نقرتان = تقديم/تأخير 10 ثوانٍ، سحب عمودي = سطوع/صوت
        Box(
            Modifier.fillMaxSize()
                .pointerInput(s.locked, isLive) {
                    detectTapGestures(
                        onTap = { s.controls = !s.controls; s.bump++ },
                        onDoubleTap = { off ->
                            if (!s.locked && !isLive) {
                                if (off.x < size.width / 2f) s.seekBy(-10_000) else s.seekBy(10_000)
                            }
                        }
                    )
                }
                .pointerInput(s.locked) {
                    if (!s.locked) {
                        var startX = 0f
                        val am = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        detectVerticalDragGestures(
                            onDragStart = { startX = it.x; s.volF = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                val delta = -dy / size.height * 1.4f
                                if (startX < size.width / 2f) {
                                    val lp = activity.window.attributes
                                    val curB = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                    lp.screenBrightness = (curB + delta).coerceIn(0.02f, 1f)
                                    activity.window.attributes = lp
                                    s.hud = "☀ " + (lp.screenBrightness * 100).roundToInt() + "%"
                                } else {
                                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                    s.volF = (s.volF + delta * max).coerceIn(0f, max.toFloat())
                                    am.setStreamVolume(AudioManager.STREAM_MUSIC, s.volF.roundToInt(), 0)
                                    s.hud = "🔊 " + (s.volF / max * 100).roundToInt() + "%"
                                }
                            }
                        )
                    }
                }
        )

        if (s.buffering && s.error == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Accent2)

        s.hud?.let {
            Text(
                it, color = Color.White, fontSize = 16.sp,
                modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        s.error?.let { msg ->
            Column(Modifier.align(Alignment.Center).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(msg, color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { s.startItem(s.index) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
            }
        }

        // قفل الشاشة
        if (s.locked) {
            AnimatedVisibility(s.controls, Modifier.align(Alignment.CenterStart), enter = fadeIn(), exit = fadeOut()) {
                IconButton(
                    onClick = { s.locked = false; s.touch() },
                    modifier = Modifier.padding(12.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.6f))
                ) { Icon(Icons.Rounded.Lock, null, tint = Accent2) }
            }
        } else {
            AnimatedVisibility(s.controls || s.error != null, Modifier.fillMaxSize(), enter = fadeIn(), exit = fadeOut()) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f))) {
                    // الشريط العلوي
                    Row(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { activity.finish() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White) }
                        Column(Modifier.weight(1f)) {
                            Text(s.cur.display, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                            if (s.cur.kind == Kind.LIVE && s.cur.group.isNotBlank())
                                Text(s.cur.group, color = Color(0xFFB8C0D4), fontSize = 11.sp, maxLines = 1)
                        }
                        IconButton(onClick = {
                            scopeToggleFav(s, isFav); s.touch()
                        }) { Icon(if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (isFav) Heart else Color.White) }
                        if (!isLive) {
                            TextButton(onClick = {
                                val opts = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
                                val next = opts[(opts.indexOf(s.speed).let { if (it < 0) 1 else it } + 1) % opts.size]
                                s.speed = next
                                s.exo.setPlaybackSpeed(next)
                                s.touch()
                            }) { Text(if (s.speed % 1f == 0f) "${s.speed.toInt()}x" else "${s.speed}x", color = Color.White, fontSize = 13.sp) }
                        }
                        IconButton(onClick = {
                            s.resize = when (s.resize) {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                            s.hud = when (s.resize) {
                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "تكبير"
                                AspectRatioFrameLayout.RESIZE_MODE_FILL -> "ملء الشاشة"
                                else -> "الأصلي"
                            }
                            s.touch()
                        }) { Icon(Icons.Rounded.AspectRatio, null, tint = Color.White) }
                        IconButton(onClick = { s.dialog = C.TRACK_TYPE_AUDIO; s.touch() }) { Icon(Icons.Rounded.Audiotrack, null, tint = Color.White) }
                        IconButton(onClick = { s.dialog = C.TRACK_TYPE_TEXT; s.touch() }) { Icon(Icons.Rounded.Subtitles, null, tint = Color.White) }
                        if (landscape && s.items.size > 1) {
                            IconButton(onClick = { s.showList = !s.showList; s.touch() }) { Icon(Icons.Rounded.PlaylistPlay, null, tint = Accent2) }
                        }
                        IconButton(onClick = onRotate) {
                            Icon(if (landscape) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen, null, tint = Color.White)
                        }
                    }

                    // أزرار الوسط
                    Row(
                        Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (s.items.size > 1) IconButton(onClick = { if (s.index > 0) s.startItem(s.index - 1); s.touch() }) {
                            Icon(Icons.Rounded.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(34.dp))
                        }
                        if (!isLive) IconButton(onClick = { s.seekBy(-10_000); s.touch() }) {
                            Icon(Icons.Rounded.Replay10, null, tint = Color.White, modifier = Modifier.size(34.dp))
                        }
                        Box(
                            Modifier.size(64.dp).clip(CircleShape).background(AccentBrush)
                                .clickable { if (s.exo.isPlaying) s.exo.pause() else s.exo.play(); s.touch() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(if (s.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                        if (!isLive) IconButton(onClick = { s.seekBy(10_000); s.touch() }) {
                            Icon(Icons.Rounded.Forward10, null, tint = Color.White, modifier = Modifier.size(34.dp))
                        }
                        if (s.items.size > 1) IconButton(onClick = { if (s.index < s.items.lastIndex) s.startItem(s.index + 1); s.touch() }) {
                            Icon(Icons.Rounded.SkipNext, null, tint = Color.White, modifier = Modifier.size(34.dp))
                        }
                    }

                    // الشريط السفلي
                    Row(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isLive) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFF3B30)))
                            Spacer(Modifier.width(6.dp))
                            Text("مباشر", color = Color.White, fontSize = 12.sp)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { s.locked = true; s.controls = false }) { Icon(Icons.Rounded.LockOpen, null, tint = Color.White) }
                        } else {
                            SeekBar(s)
                            IconButton(onClick = { s.locked = true; s.controls = false }) { Icon(Icons.Rounded.LockOpen, null, tint = Color.White) }
                        }
                    }
                }
            }
        }
    }
}

private fun scopeToggleFav(s: PState, isFav: Boolean) {
    val c = s.cur
    s.scope.launch {
        if (isFav) s.app.db.favorites().remove(c.key)
        else s.app.db.favorites().add(FavoriteEntity(c.key, c.serverId, c.toJson(), System.currentTimeMillis()))
    }
}

@Composable
private fun RowScope.SeekBar(s: PState) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val dur = s.dur.longValue
    val frac = if (dur > 0) (s.pos.longValue.toFloat() / dur).coerceIn(0f, 1f) else 0f
    Text(fmtTime(if (dragging) (dragValue * dur).toLong() else s.pos.longValue), color = Color.White, fontSize = 12.sp)
    Slider(
        value = if (dragging) dragValue else frac,
        onValueChange = { dragging = true; dragValue = it; s.bump++ },
        onValueChangeFinished = {
            s.exo.seekTo((dragValue * dur).toLong())
            dragging = false
        },
        enabled = dur > 0,
        colors = SliderDefaults.colors(thumbColor = Accent2, activeTrackColor = Accent, inactiveTrackColor = Color.White.copy(alpha = 0.25f)),
        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
    )
    Text(fmtTime(dur), color = Color.White, fontSize = 12.sp)
}

/* ───────────────────────── قائمة التشغيل (حلقات / قنوات) ───────────────────────── */

@Composable
private fun PlaylistPanel(s: PState, modifier: Modifier, onClose: (() -> Unit)?) {
    val items = s.items
    val episodesMode = remember(items) { items.isNotEmpty() && items.all { it.kind == Kind.EPISODE } }
    val liveMode = remember(items) { items.any { it.kind == Kind.LIVE } }
    fun tabOf(c: Content) = if (episodesMode) c.season.toString() else c.group

    var tab by remember { mutableStateOf(if (episodesMode) tabOf(s.cur) else G_ALL) }
    var query by remember { mutableStateOf("") }
    if (episodesMode) LaunchedEffect(s.index) { tab = tabOf(items[s.index]) }

    val tabs = remember(items) {
        when {
            episodesMode -> items.map { it.season }.distinct().sorted().map { it.toString() to "الموسم $it" }
            liveMode -> listOf(G_ALL to "الكل") + items.map { it.group }.filter { it.isNotBlank() }.distinct().map { it to it }
            else -> emptyList()
        }
    }
    val visible = remember(items, tab, query) {
        items.withIndex().filter { iv ->
            val c = iv.value
            (tab == G_ALL || tabOf(c) == tab) && (query.isBlank() || c.title.contains(query, true))
        }
    }
    val ls = rememberLazyListState()
    LaunchedEffect(s.index, tab) {
        val p = visible.indexOfFirst { it.index == s.index }
        if (p >= 0) ls.scrollToItem((p - 1).coerceAtLeast(0))
    }

    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                (if (episodesMode) "الحلقات" else if (liveMode) "القنوات" else "قائمة التشغيل") + " · ${visible.size}",
                fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            if (onClose != null) IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, null) }
        }
        if (tabs.size > 1) Pills(tabs, tab) { tab = it }
        if (liveMode) SearchField(query) { query = it }
        LazyColumn(state = ls, modifier = Modifier.weight(1f)) {
            items(visible) { iv ->
                val c = iv.value
                val playing = iv.index == s.index
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (playing) Accent.copy(alpha = 0.18f) else Color.Transparent)
                        .clickable { s.startItem(iv.index) }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (c.kind == Kind.LIVE) Poster(c.poster, c.title, Modifier.size(52.dp), fit = true)
                    else Poster(c.poster, c.title, Modifier.size(width = 92.dp, height = 52.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (c.kind == Kind.EPISODE) "${c.episode}. ${c.title}" else c.title,
                            fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            color = if (playing) Color.White else Color(0xFFD0D5E2),
                            fontWeight = if (playing) FontWeight.Bold else FontWeight.Normal
                        )
                        val sub = when (c.kind) { Kind.LIVE -> c.group; Kind.EPISODE -> ""; else -> c.display }
                        if (sub.isNotBlank()) Text(sub, color = TextDim, fontSize = 11.sp, maxLines = 1)
                    }
                    if (playing) Icon(Icons.Rounded.GraphicEq, null, tint = Accent2)
                }
            }
        }
    }
}

/* ───────────────────────── اختيار الصوت / الترجمة ───────────────────────── */

@Composable
private fun TrackDialog(s: PState, type: Int, onDismiss: () -> Unit) {
    val groups = s.exo.currentTracks.groups.filter { it.type == type && it.isSupported }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == C.TRACK_TYPE_AUDIO) "المسار الصوتي" else "الترجمة") },
        text = {
            Column {
                if (type == C.TRACK_TYPE_TEXT) {
                    TextButton(onClick = {
                        s.exo.trackSelectionParameters = s.exo.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                        onDismiss()
                    }) { Text("بدون ترجمة") }
                }
                if (groups.isEmpty()) Text("لا توجد مسارات متاحة", color = TextDim)
                var n = 0
                groups.forEach { g ->
                    for (i in 0 until g.length) {
                        n++
                        val f = g.getTrackFormat(i)
                        val label = f.label ?: f.language?.let { Locale(it).displayLanguage } ?: "مسار $n"
                        TextButton(onClick = {
                            s.exo.trackSelectionParameters = s.exo.trackSelectionParameters.buildUpon()
                                .setTrackTypeDisabled(type, false)
                                .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                                .build()
                            onDismiss()
                        }) { Text(label + if (g.isTrackSelected(i)) "  ✓" else "") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}
