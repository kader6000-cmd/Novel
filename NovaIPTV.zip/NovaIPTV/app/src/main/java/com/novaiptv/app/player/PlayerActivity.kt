@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.novaiptv.app.player

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.novaiptv.app.App
import com.novaiptv.app.data.*
import com.novaiptv.app.ui.Accent
import com.novaiptv.app.ui.NovaTheme
import com.novaiptv.app.ui.TextDim
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** طابور التشغيل الحالي (قنوات أو حلقات) — يُمرَّر للمشغّل دون تسلسل */
object PlayQueue {
    var items: List<Content> = emptyList()
    var index: Int = 0
    fun set(list: List<Content>, i: Int) { items = list; index = i }
}

class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as App
        val items = PlayQueue.items
        if (items.isEmpty()) { finish(); return }

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        lifecycleScope.launch {
            val start = PlayQueue.index.coerceIn(0, items.lastIndex)
            val server = app.db.servers().get(items[start].serverId)
            val ua = server?.userAgent?.ifBlank { null } ?: DEFAULT_UA
            val okFactory = OkHttpDataSource.Factory(app.http.client).setUserAgent(ua)
            val dsFactory = DefaultDataSource.Factory(this@PlayerActivity, okFactory)
            val exo = ExoPlayer.Builder(this@PlayerActivity)
                .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
                .build()
            player = exo
            setContent {
                NovaTheme { PlayerScreen(exo, items, start, app) { finish() } }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        val exo = player ?: return
        val c = PlayQueue.items.getOrNull(PlayQueue.index)
        if (c != null && c.kind != Kind.LIVE && exo.duration > 0) {
            val pos = exo.currentPosition
            val dur = exo.duration
            val app = application as App
            app.appScope.launch {
                app.db.history().upsert(HistoryEntity(c.key, c.serverId, c.toJson(), pos, dur, System.currentTimeMillis()))
            }
        }
        exo.pause()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
private fun PlayerScreen(exo: ExoPlayer, items: List<Content>, start: Int, app: App, onBack: () -> Unit) {
    var index by remember { mutableIntStateOf(start.coerceIn(0, items.lastIndex)) }
    var showList by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun startItem(i: Int) {
        scope.launch {
            index = i
            PlayQueue.index = i
            error = null
            val c = items[i]
            try {
                val url = app.repo.playUrl(c)
                val h = if (c.kind == Kind.LIVE) null else app.db.history().get(c.key)
                val resumeAt = if (h != null && h.positionMs > 5_000 &&
                    (h.durationMs <= 0 || h.positionMs < h.durationMs - 20_000)) h.positionMs else 0L
                exo.setMediaItem(MediaItem.fromUri(url), resumeAt)
                exo.prepare()
                exo.playWhenReady = true
                app.db.history().upsert(
                    HistoryEntity(c.key, c.serverId, c.toJson(), resumeAt, h?.durationMs ?: 0, System.currentTimeMillis())
                )
            } catch (e: Exception) {
                error = e.message ?: "تعذّر التشغيل"
            }
        }
    }

    LaunchedEffect(Unit) { startItem(index) }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    val c = items[index]
                    if (c.kind != Kind.LIVE) {
                        val d = exo.duration.coerceAtLeast(0)
                        app.appScope.launch {
                            app.db.history().upsert(HistoryEntity(c.key, c.serverId, c.toJson(), d, d, System.currentTimeMillis()))
                        }
                        if (index + 1 < items.size) startItem(index + 1)
                    }
                }
            }
            override fun onPlayerError(e: PlaybackException) {
                error = "تعذّر تشغيل هذا المحتوى (${e.errorCodeName})"
            }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }

    // حفظ موضع المشاهدة كل 5 ثوانٍ لاستكمال التشغيل لاحقاً
    LaunchedEffect(index) {
        while (true) {
            delay(5000)
            val c = items[index]
            if (c.kind != Kind.LIVE && exo.playbackState == Player.STATE_READY) {
                app.db.history().upsert(
                    HistoryEntity(c.key, c.serverId, c.toJson(), exo.currentPosition, exo.duration.coerceAtLeast(0), System.currentTimeMillis())
                )
            }
        }
    }

    BackHandler { if (showList) showList = false else onBack() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exo
                    useController = true
                    setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                    setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> controls = v == View.VISIBLE })
                }
            }
        )

        AnimatedVisibility(visible = controls || error != null, modifier = Modifier.align(Alignment.TopCenter)) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White) }
                Text(items[index].display, color = Color.White, fontSize = 15.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (items.size > 1) {
                    IconButton(onClick = { if (index > 0) startItem(index - 1) }) { Icon(Icons.Rounded.SkipPrevious, null, tint = Color.White) }
                    IconButton(onClick = { if (index < items.lastIndex) startItem(index + 1) }) { Icon(Icons.Rounded.SkipNext, null, tint = Color.White) }
                    IconButton(onClick = { showList = !showList }) { Icon(Icons.Rounded.PlaylistPlay, null, tint = Accent) }
                }
            }
        }

        error?.let { msg ->
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(msg, color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { startItem(index) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
            }
        }

        AnimatedVisibility(visible = showList, modifier = Modifier.align(Alignment.CenterEnd)) {
            Surface(Modifier.width(330.dp).fillMaxHeight(), color = Color(0xEE0B0E17)) {
                val ls = rememberLazyListState()
                LaunchedEffect(Unit) { ls.scrollToItem((index - 2).coerceAtLeast(0)) }
                Column {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("القائمة (${items.size})", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = { showList = false }) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
                    }
                    LazyColumn(state = ls) {
                        itemsIndexed(items) { i, c ->
                            val cur = i == index
                            Column(
                                Modifier.fillMaxWidth()
                                    .background(if (cur) Accent.copy(alpha = 0.25f) else Color.Transparent)
                                    .clickable { startItem(i); showList = false }
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                Text(
                                    if (c.kind == Kind.EPISODE) "م${c.season} · ح${c.episode}  ${c.title}" else c.title,
                                    color = if (cur) Color.White else Color(0xFFD0D5E2), fontSize = 14.sp,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                                if (c.kind == Kind.LIVE && c.group.isNotBlank())
                                    Text(c.group, color = TextDim, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}
