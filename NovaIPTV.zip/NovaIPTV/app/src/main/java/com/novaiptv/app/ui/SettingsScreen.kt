package com.novaiptv.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaiptv.app.data.BackupManager
import com.novaiptv.app.data.GoogleSyncManager
import com.novaiptv.app.data.Prefs
import com.novaiptv.app.i18n.AppLanguage
import com.novaiptv.app.i18n.LocalStrings
import com.novaiptv.app.security.SecurityGuard
import kotlinx.coroutines.launch

private enum class SettingsPage {
    GOOGLE, LANGUAGE, THEME, DOWNLOAD_PATH, DOWNLOAD_SPEED,
    WIFI_SUBTITLES, PARENTAL, BACKUP, SECURITY, ABOUT
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val s = LocalStrings.current
    val scope = rememberCoroutineScope()

    var settingsPage by remember { mutableStateOf<SettingsPage?>(null) }

    // System back inside a sub-page goes back to the hub first.
    BackHandler(enabled = settingsPage != null) { settingsPage = null }

    val currentLangCode by Prefs.language.collectAsState()
    val googleUser by GoogleSyncManager.currentUser.collectAsState()
    var isSyncing by remember { mutableStateOf(false) }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val res = GoogleSyncManager.handleSignInResult(result.data)
        res.onSuccess { user ->
            Toast.makeText(context, "تم تسجيل الدخول: ${user.email}", Toast.LENGTH_SHORT).show()
        }.onFailure { err ->
            Toast.makeText(context, "تعذر تسجيل الدخول بجوجل: ${err.localizedMessage ?: "تأكد من إعداد OAuth في Google Cloud"}", Toast.LENGTH_LONG).show()
        }
    }
    val currentPin by Prefs.parentalPin.collectAsState()
    val currentThemeId by Prefs.theme.collectAsState()
    val downloadPathLabel by Prefs.downloadPathLabel.collectAsState()
    val downloadTreeUri by Prefs.downloadTreeUri.collectAsState()
    val downloadThreads by Prefs.downloadThreads.collectAsState()
    val wifiOnly by Prefs.wifiOnlyDownloads.collectAsState()
    val subSize by Prefs.subtitleSizeSp.collectAsState()
    val subColor by Prefs.subtitleColor.collectAsState()
    val sigHash = remember { SecurityGuard.getCurrentSignatureSha256(context).take(23) + "..." }

    val folderPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, flags)
            }
            val cleanLabel = uri.lastPathSegment?.substringAfter(":")?.ifBlank { "مجلد مخصص" } ?: "مجلد مخصص"
            Prefs.setCustomDownloadTree(context, uri.toString(), cleanLabel)
            Toast.makeText(context, "تم تغيير مسار التحميل إلى: $cleanLabel", Toast.LENGTH_SHORT).show()
        }
    }

    var showPinDialog by remember { mutableStateOf(false) }
    var showDisclaimerDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val json = BackupManager.exportJson(context)
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                    Toast.makeText(context, "Backup exported successfully", Toast.LENGTH_SHORT).show()
                }.onFailure {
                    Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    val count = BackupManager.importJson(context, json)
                    Toast.makeText(context, "Imported $count servers", Toast.LENGTH_SHORT).show()
                }.onFailure {
                    Toast.makeText(context, "Import failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val pageTitle = when (settingsPage) {
        SettingsPage.GOOGLE -> "حساب جوجل والمزامنة"
        SettingsPage.LANGUAGE -> s.languageTitle
        SettingsPage.THEME -> "المظهر والسمات"
        SettingsPage.DOWNLOAD_PATH -> "مسار حفظ التحميلات"
        SettingsPage.DOWNLOAD_SPEED -> "تسريع التحميل"
        SettingsPage.WIFI_SUBTITLES -> "Wi-Fi والترجمة"
        SettingsPage.PARENTAL -> s.parentalTitle
        SettingsPage.BACKUP -> s.backupTitle
        SettingsPage.SECURITY -> s.securityTitle
        SettingsPage.ABOUT -> "عن التطبيق"
        null -> s.settingsTitle
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
    ) {
        // Sticky header: hub shows title + version badge; sub-page shows its title.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    androidx.compose.ui.graphics.Brush.horizontalGradient(
                        listOf(AccentCyan.copy(alpha = 0.10f), Color.Transparent)
                    )
                )
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (settingsPage != null) settingsPage = null else onBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = TextPrimary)
            }
            Text(pageTitle, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (settingsPage == null) {
                Spacer(Modifier.weight(1f))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AccentCyan.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, AccentCyan.copy(alpha = 0.45f))
                ) {
                    Text(
                        "v2.3.2",
                        color = AccentCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
                Spacer(Modifier.width(8.dp))
            }
        }
        HorizontalDivider(color = BorderSubtle)

        when (settingsPage) {
            null -> SettingsHub(
                s = s,
                currentPin = currentPin,
                onOpen = { settingsPage = it }
            )
            SettingsPage.GOOGLE -> SettingsSubPage(
                explanation = "اربط حساب جوجل عشان تحفظ نسخة من سيرفراتك وإعداداتك على Google Drive وتسترجعها على أي جهاز، وكمان المفضلة."
            ) {
                if (googleUser == null) {
                    Text(
                        text = "سجّل الدخول بحساب جوجل لحفظ إعدادات السيرفرات والمفضلة واسترجاعها على أي جهاز.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val intent = GoogleSyncManager.getClient(context).signInIntent
                            googleSignInLauncher.launch(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("تسجيل الدخول بحساب جوجل", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(googleUser!!.displayName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(googleUser!!.email, color = AccentCyan, fontSize = 12.sp)
                        }
                        TextButton(onClick = {
                            GoogleSyncManager.signOut(context) {
                                Toast.makeText(context, "تم تسجيل الخروج", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Text("خروج", color = LiveRed, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            enabled = !isSyncing,
                            onClick = {
                                scope.launch {
                                    isSyncing = true
                                    val res = GoogleSyncManager.uploadBackupToGoogleDrive(context)
                                    isSyncing = false
                                    res.onSuccess {
                                        Toast.makeText(context, "تم حفظ السيرفرات والإعدادات على حساب جوجل بنجاح", Toast.LENGTH_SHORT).show()
                                    }.onFailure { err ->
                                        Toast.makeText(context, "فشل الحفظ: ${err.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("حفظ على جوجل", fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                        }
                        OutlinedButton(
                            enabled = !isSyncing,
                            onClick = {
                                scope.launch {
                                    isSyncing = true
                                    val res = GoogleSyncManager.restoreBackupFromGoogleDrive(context)
                                    isSyncing = false
                                    res.onSuccess { count ->
                                        Toast.makeText(context, "تم استرجاع $count سيرفر من حساب جوجل بنجاح", Toast.LENGTH_SHORT).show()
                                    }.onFailure { err ->
                                        Toast.makeText(context, "فشل الاسترجاع: ${err.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("استرجاع من جوجل", fontSize = 11.sp, maxLines = 1)
                        }
                    }
                    if (isSyncing) {
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(color = AccentCyan, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            SettingsPage.LANGUAGE -> SettingsSubPage(
                explanation = "اختر لغة واجهة التطبيق. التغيير بيطبّق فوراً على كل الشاشات والقوائم."
            ) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        val selected = lang.code == currentLangCode
                        FilterChip(
                            selected = selected,
                            onClick = { Prefs.setLanguage(context, lang.code) },
                            label = {
                                Text(
                                    text = lang.nativeName,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentCyan,
                                selectedLabelColor = Color.Black,
                                containerColor = CardElevated,
                                labelColor = TextPrimary
                            )
                        )
                    }
                }
            }
            SettingsPage.THEME -> SettingsSubPage(
                explanation = "اختار اللون المميز للتطبيق — الأزرار والأيقونات والمؤشرات هتتلون بيه فوراً في كل الشاشات، والاختيار بيتحفظ."
            ) {
                // Live preview: gradient bar + sample button in the current accent.
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            androidx.compose.ui.graphics.Brush.horizontalGradient(
                                listOf(AccentCyan, AccentViolet)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("معاينة اللون الحالي", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(Modifier.height(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeAccents.forEach { accent ->
                        val selected = accent.id == currentThemeId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selected) AccentCyan.copy(alpha = 0.12f) else CardElevated)
                                .border(
                                    width = if (selected) 1.5.dp else 1.dp,
                                    color = if (selected) AccentCyan else BorderSubtle,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { Prefs.setTheme(context, accent.id) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(accent.color)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                accent.nameAr,
                                color = TextPrimary,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 14.sp,
                                modifier = Modifier.weight(1f)
                            )
                            if (selected) {
                                Icon(Icons.Default.Check, contentDescription = "نشط", tint = AccentCyan, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
            SettingsPage.DOWNLOAD_PATH -> SettingsSubPage(
                explanation = "اختار المجلد اللي هتتحفظ فيه الأفلام والمسلسلات اللي بتنزّلها. المجلد الافتراضي هو Downloads/NovaIPTV العام على الهاتف."
            ) {
                Text(
                    text = "المسار الحالي: $downloadPathLabel",
                    color = AccentCyan,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { folderPickerLauncher.launch(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("تغيير المسار", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    if (downloadTreeUri.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                Prefs.resetDownloadPathToDefault(context)
                                Toast.makeText(context, "تمت الاستعادة إلى Downloads/NovaIPTV", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                        ) {
                            Text("الافتراضي", fontSize = 12.sp)
                        }
                    }
                }
            }
            SettingsPage.DOWNLOAD_SPEED -> SettingsSubPage(
                explanation = "التطبيق بيقسّم الملف لأجزاء متوازية وبينزّلها مع بعض زي IDM، فالتحميل بيبقى أسرع. ولو السيرفر قيّد التعدد بيرجع لاتصال واحد تلقائياً."
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "1x عادي", 2 to "2x", 4 to "4x موصى به", 8 to "8x أقصى").forEach { (count, label) ->
                        val selected = downloadThreads == count
                        FilterChip(
                            selected = selected,
                            onClick = { Prefs.setDownloadThreads(context, count) },
                            label = { Text(label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentCyan,
                                selectedLabelColor = Color.Black,
                                containerColor = CardElevated,
                                labelColor = TextPrimary
                            )
                        )
                    }
                }
            }
            SettingsPage.WIFI_SUBTITLES -> SettingsSubPage(
                explanation = "وفّر باقة الموبايل: فعّل التحميل عبر Wi-Fi فقط عشان الباقة متخلصش، وظبّط حجم ولون خط الترجمة اللي بيظهر أثناء المشاهدة."
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("تفعيل التحميل عبر Wi-Fi فقط", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = wifiOnly,
                        onCheckedChange = { Prefs.setWifiOnlyDownloads(context, it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = AccentCyan)
                    )
                }
                HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 12.dp))
                Text("حجم الخط:", color = TextSecondary, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(14f to "صغير", 18f to "متوسط", 24f to "كبير").forEach { (sz, lbl) ->
                        FilterChip(
                            selected = subSize == sz,
                            onClick = { Prefs.setSubtitleStyle(context, sz, subColor) },
                            label = { Text(lbl, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = AccentCyan, selectedLabelColor = Color.Black)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("لون الخط:", color = TextSecondary, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        0xFFFFFFFF.toInt() to "أبيض",
                        0xFFFFEB3B.toInt() to "أصفر",
                        0xFF00E5FF.toInt() to "سماوي"
                    ).forEach { (clr, lbl) ->
                        FilterChip(
                            selected = subColor == clr,
                            onClick = { Prefs.setSubtitleStyle(context, subSize, clr) },
                            label = { Text(lbl, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(clr), selectedLabelColor = Color.Black)
                        )
                    }
                }
            }
            SettingsPage.PARENTAL -> SettingsSubPage(
                explanation = "حدّد رقماً سرياً من 4 أرقام يُطلب قبل فتح المحتوى المقيّد، عشان الأطفال مايفتحوش حاجة مش مناسبة ليهم."
            ) {
                Text(
                    text = if (currentPin.isNotBlank()) s.parentalEnabled else s.parentalDisabled,
                    color = if (currentPin.isNotBlank()) AccentCyan else TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { showPinDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
                    ) {
                        Text(s.setPin, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    if (currentPin.isNotBlank()) {
                        OutlinedButton(
                            onClick = { Prefs.setParentalPin(context, "") },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = LiveRed)
                        ) {
                            Text(s.removePin, fontSize = 12.sp)
                        }
                    }
                }
            }
            SettingsPage.BACKUP -> SettingsSubPage(
                explanation = "صدّر نسخة من سيرفراتك وإعداداتك كملف JSON تحتفظ بيه، أو استرجع نسخة قديمة في أي وقت — مفيدة لما تغيّر الموبايل."
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { exportLauncher.launch("novaiptv_backup.json") },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentViolet, contentColor = Color.White),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(s.exportBackup, fontSize = 11.sp, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(s.importBackup, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
            SettingsPage.SECURITY -> SettingsSubPage(
                explanation = "التطبيق بيتحقق من توقيعه الرقمي عند التشغيل، والكود محمي بـ R8. البصمة دي بتأكد إن النسخة دي أصلية وموقّعة بشهادة المطوّر."
            ) {
                Text("Version 2.3.2 • R8 Protected", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text("Signature SHA-256: $sigHash", color = TextSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
            }
            SettingsPage.ABOUT -> SettingsSubPage(
                explanation = "NovaIPTV مشغّل IPTV لمشاهدة القنوات المباشرة والأفلام والمسلسلات من سيرفراتك، مع تحميل للمشاهدة دون اتصال."
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(AccentCyan.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(40.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("NovaIPTV", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Text("الإصدار 2.3.2 (26)", color = AccentCyan, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("المطوّر: Abdelkader Ahmed", color = TextPrimary, fontSize = 13.sp)
                    Text("عبد القادر أحمد", color = TextSecondary, fontSize = 13.sp)
                }
                Spacer(Modifier.height(14.dp))
                Text("Signature SHA-256: $sigHash", color = TextSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { showDisclaimerDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(s.disclaimerTitle.substringBefore(" "), fontSize = 12.sp, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = { showPrivacyDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(s.privacyPolicyTitle, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
    }

    if (showPinDialog) {
        var newPin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            containerColor = CardDark,
            title = { Text(s.setPin, color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) newPin = it },
                    label = { Text("4-digit PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPin.length == 4) {
                            Prefs.setParentalPin(context, newPin)
                            showPinDialog = false
                        }
                    },
                    enabled = newPin.length == 4,
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
                ) {
                    Text(s.confirm, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text(s.cancel, color = TextSecondary) }
            }
        )
    }

    if (showDisclaimerDialog) {
        AlertDialog(
            onDismissRequest = { showDisclaimerDialog = false },
            containerColor = CardDark,
            title = { Text(s.disclaimerTitle, color = AccentCyan, fontWeight = FontWeight.Bold) },
            text = { Text(s.disclaimerBody, color = TextPrimary, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { showDisclaimerDialog = false }) { Text(s.close, color = AccentCyan) }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            containerColor = CardDark,
            title = { Text(s.privacyPolicyTitle, color = AccentCyan, fontWeight = FontWeight.Bold) },
            text = { Text(s.privacyPolicyBody, color = TextPrimary, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text(s.close, color = AccentCyan) }
            }
        )
    }
}

/** Main settings hub: one row per settings group. */
@Composable
private fun SettingsHub(
    s: com.novaiptv.app.i18n.AppStrings,
    currentPin: String,
    onOpen: (SettingsPage) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SettingsHubRow(
            title = "حساب جوجل والمزامنة",
            subtitle = "مزامنة سيرفراتك وإعداداتك مع حساب جوجل",
            icon = Icons.Default.CloudSync,
            onClick = { onOpen(SettingsPage.GOOGLE) }
        )
        SettingsHubRow(
            title = s.languageTitle,
            subtitle = s.languageSubtitle,
            icon = Icons.Default.Language,
            onClick = { onOpen(SettingsPage.LANGUAGE) }
        )
        SettingsHubRow(
            title = "المظهر والسمات",
            subtitle = "غيّر اللون المميز للتطبيق وشكله",
            icon = Icons.Default.Palette,
            onClick = { onOpen(SettingsPage.THEME) }
        )
        SettingsHubRow(
            title = "مسار حفظ التحميلات",
            subtitle = "اختر مجلد حفظ ملفات التحميل",
            icon = Icons.Default.Folder,
            onClick = { onOpen(SettingsPage.DOWNLOAD_PATH) }
        )
        SettingsHubRow(
            title = "تسريع التحميل",
            subtitle = "تقسيم الملف إلى أجزاء متوازية مثل IDM",
            icon = Icons.Default.Speed,
            onClick = { onOpen(SettingsPage.DOWNLOAD_SPEED) }
        )
        SettingsHubRow(
            title = "Wi-Fi والترجمة",
            subtitle = "التحميل عبر Wi-Fi فقط وحجم ولون الترجمة",
            icon = Icons.Default.Wifi,
            onClick = { onOpen(SettingsPage.WIFI_SUBTITLES) }
        )
        SettingsHubRow(
            title = s.parentalTitle,
            subtitle = if (currentPin.isNotBlank()) s.parentalEnabled else s.parentalDisabled,
            icon = Icons.Default.Lock,
            onClick = { onOpen(SettingsPage.PARENTAL) }
        )
        SettingsHubRow(
            title = s.backupTitle,
            subtitle = "تصدير واستيراد نسخة من سيرفراتك",
            icon = Icons.Default.Backup,
            onClick = { onOpen(SettingsPage.BACKUP) }
        )
        SettingsHubRow(
            title = s.securityTitle,
            subtitle = "التوقيع الرقمي والحماية",
            icon = Icons.Default.VerifiedUser,
            onClick = { onOpen(SettingsPage.SECURITY) }
        )
        SettingsHubRow(
            title = "عن التطبيق",
            subtitle = "النسخة والمطوّر والتوقيع",
            icon = Icons.Default.Info,
            onClick = { onOpen(SettingsPage.ABOUT) }
        )
        Spacer(Modifier.height(8.dp))
    }
}

/** One hub row: tinted icon square + title + grey description + chevron. */
@Composable
private fun SettingsHubRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(AccentCyan.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(subtitle, color = TextSecondary, fontSize = 12.sp)
        }
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = TextSecondary,
            modifier = Modifier.size(22.dp)
        )
    }
}

/** Sub-page shell: short explanation on top, then the page controls in a card. */
@Composable
private fun SettingsSubPage(
    explanation: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(explanation, color = TextSecondary, fontSize = 13.sp)
        SettingsCard(content = content)
    }
}

/** Unified card style: big rounded corners, content inside. */
@Composable
private fun SettingsCard(
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        content()
    }
}
