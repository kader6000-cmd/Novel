package com.novaiptv.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaiptv.app.data.BackupManager
import com.novaiptv.app.data.GoogleSyncManager
import com.novaiptv.app.data.Prefs
import com.novaiptv.app.i18n.AppLanguage
import com.novaiptv.app.i18n.LocalStrings
import com.novaiptv.app.security.SecurityGuard
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val s = LocalStrings.current
    val scope = rememberCoroutineScope()

    val currentLangCode by Prefs.language.collectAsState()
    val googleUser by GoogleSyncManager.currentUser.collectAsState()
    var isSyncing by remember { mutableStateOf(false) }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val res = GoogleSyncManager.handleSignInResult(result.data)
        res.onSuccess { user ->
            Toast.makeText(context, "تم تسجيل الدخول: ${user.email}", Toast.LENGTH_SHORT).show()
        }.onFailure { err ->
            Toast.makeText(context, "تعذر تسجيل الدخول بجوجل: ${err.localizedMessage ?: "تأكد من إعداد OAuth في Google Cloud"}", Toast.LENGTH_LONG).show()
        }
    }
    val currentPin by Prefs.parentalPin.collectAsState()

    var showPinDialog by remember { mutableStateOf(false) }
    var showDisclaimerDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val json = BackupManager.exportJson(context)
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                    Toast.makeText(context, "Backup exported successfully", Toast.LENGTH_SHORT).show()
                }.onFailure {
                    Toast.makeText(context, "Export failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    val count = BackupManager.importJson(context, json)
                    Toast.makeText(context, "Imported $count servers", Toast.LENGTH_SHORT).show()
                }.onFailure {
                    Toast.makeText(context, "Import failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = TextPrimary)
            }
            Spacer(Modifier.width(6.dp))
            Text(s.settingsTitle, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        
        // 0. Google Account & Cloud Sync Card
        SettingsCard(title = "حساب جوجل والمزامنة السحابية", icon = Icons.Default.CloudSync) {
            if (googleUser == null) {
                Text(
                    text = "سجّل الدخول بحساب جوجل لحفظ إعدادات السيرفرات والمفضلة واسترجاعها على أي جهاز.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val intent = GoogleSyncManager.getClient(context).signInIntent
                        googleSignInLauncher.launch(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("تسجيل الدخول بحساب جوجل", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(googleUser!!.displayName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(googleUser!!.email, color = AccentCyan, fontSize = 12.sp)
                    }
                    TextButton(onClick = {
                        GoogleSyncManager.signOut(context) {
                            Toast.makeText(context, "تم تسجيل الخروج", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Text("خروج", color = LiveRed, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = !isSyncing,
                        onClick = {
                            scope.launch {
                                isSyncing = true
                                val res = GoogleSyncManager.uploadBackupToGoogleDrive(context)
                                isSyncing = false
                                res.onSuccess {
                                    Toast.makeText(context, "تم حفظ السيرفرات والإعدادات على حساب جوجل بنجاح", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    Toast.makeText(context, "فشل الحفظ: ${err.localizedMessage}", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("حفظ على جوجل", fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                    }
                    OutlinedButton(
                        enabled = !isSyncing,
                        onClick = {
                            scope.launch {
                                isSyncing = true
                                val res = GoogleSyncManager.restoreBackupFromGoogleDrive(context)
                                isSyncing = false
                                res.onSuccess { count ->
                                    Toast.makeText(context, "تم استرجاع $count سيرفر من حساب جوجل بنجاح", Toast.LENGTH_SHORT).show()
                                }.onFailure { err ->
                                    Toast.makeText(context, "فشل الاسترجاع: ${err.localizedMessage}", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("استرجاع من جوجل", fontSize = 11.sp, maxLines = 1)
                    }
                }
                if (isSyncing) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(color = AccentCyan, modifier = Modifier.fillMaxWidth())
                }
            }
        }

        // 1. Language Selector Card
        SettingsCard(title = s.languageTitle, icon = Icons.Default.Language) {
            Text(s.languageSubtitle, color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppLanguage.entries.forEach { lang ->
                    val selected = lang.code == currentLangCode
                    FilterChip(
                        selected = selected,
                        onClick = { Prefs.setLanguage(context, lang.code) },
                        label = {
                            Text(
                                text = lang.nativeName,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AccentCyan,
                            selectedLabelColor = Color.Black,
                            containerColor = CardElevated,
                            labelColor = TextPrimary
                        )
                    )
                }
            }
        }

        // 2. Parental Control Card
        SettingsCard(title = s.parentalTitle, icon = Icons.Default.Lock) {
            Text(
                text = if (currentPin.isNotBlank()) s.parentalEnabled else s.parentalDisabled,
                color = if (currentPin.isNotBlank()) AccentCyan else TextSecondary,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { showPinDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
                ) {
                    Text(s.setPin, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                if (currentPin.isNotBlank()) {
                    OutlinedButton(
                        onClick = { Prefs.setParentalPin(context, "") },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LiveRed)
                    ) {
                        Text(s.removePin, fontSize = 12.sp)
                    }
                }
            }
        }

        // 3. Backup & Restore Card
        SettingsCard(title = s.backupTitle, icon = Icons.Default.Backup) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { exportLauncher.launch("novaiptv_backup.json") },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentViolet, contentColor = Color.White),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(s.exportBackup, fontSize = 11.sp, maxLines = 1)
                }
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(s.importBackup, fontSize = 11.sp, maxLines = 1)
                }
            }
        }

        // 4. Security, Privacy & Legal (Google Play Compliance)
        val sigHash = remember { SecurityGuard.getCurrentSignatureSha256(context).take(23) + "..." }
        SettingsCard(title = s.securityTitle, icon = Icons.Default.VerifiedUser) {
            Text("Version 2.1.0 • R8 Protected", color = TextSecondary, fontSize = 12.sp)
            Text("Signature SHA-256: $sigHash", color = TextSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { showDisclaimerDialog = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(s.disclaimerTitle.substringBefore(" "), fontSize = 12.sp, maxLines = 1)
                }
                OutlinedButton(
                    onClick = { showPrivacyDialog = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(s.privacyPolicyTitle, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }

    if (showPinDialog) {
        var newPin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            containerColor = CardDark,
            title = { Text(s.setPin, color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) newPin = it },
                    label = { Text("4-digit PIN") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPin.length == 4) {
                            Prefs.setParentalPin(context, newPin)
                            showPinDialog = false
                        }
                    },
                    enabled = newPin.length == 4,
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
                ) {
                    Text(s.confirm, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text(s.cancel, color = TextSecondary) }
            }
        )
    }

    if (showDisclaimerDialog) {
        AlertDialog(
            onDismissRequest = { showDisclaimerDialog = false },
            containerColor = CardDark,
            title = { Text(s.disclaimerTitle, color = AccentCyan, fontWeight = FontWeight.Bold) },
            text = { Text(s.disclaimerBody, color = TextPrimary, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { showDisclaimerDialog = false }) { Text(s.close, color = AccentCyan) }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            containerColor = CardDark,
            title = { Text(s.privacyPolicyTitle, color = AccentCyan, fontWeight = FontWeight.Bold) },
            text = { Text(s.privacyPolicyBody, color = TextPrimary, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text(s.close, color = AccentCyan) }
            }
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(CardDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}
