package com.novaiptv.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaiptv.app.data.GoogleSyncManager
import com.novaiptv.app.data.Prefs
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.novaiptv.app.i18n.AppLanguage
import com.novaiptv.app.i18n.LocalStrings
import com.novaiptv.app.i18n.stringsFor
import com.novaiptv.app.security.SecurityGuard
import com.novaiptv.app.ui.*
import kotlinx.coroutines.launch

enum class BottomTab(val icon: ImageVector) {
    HOME(Icons.Default.Home),
    LIVE(Icons.Default.LiveTv),
    MOVIES(Icons.Default.Movie),
    SERIES(Icons.Default.Tv),
    DOWNLOADS(Icons.Default.Download)
}

enum class SubPage { NONE, FAVORITES, HISTORY, SERVERS, SETTINGS, SEARCH }

class MainActivity : ComponentActivity() {

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GoogleSyncManager.refreshSignedInAccount(this)

        if (!SecurityGuard.isSignatureValid(this)) {
            finishAffinity()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            val langCode by Prefs.language.collectAsState()
            val appLang = remember(langCode) { AppLanguage.fromCode(langCode) }
            val strings = remember(appLang) { stringsFor(appLang) }
            val layoutDir = if (appLang.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            NovaTheme {
                CompositionLocalProvider(
                    LocalLayoutDirection provides layoutDir,
                    LocalStrings provides strings
                ) {
                    NovaRootApp()
                }
            }
        }
    }
}

@Composable
private fun NovaRootApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val s = LocalStrings.current
    val scope = rememberCoroutineScope()
    val disclaimerAccepted by Prefs.disclaimerAccepted.collectAsState()

    var currentTab by remember { mutableStateOf(BottomTab.HOME) }
    var subPage by remember { mutableStateOf(SubPage.NONE) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    val activeServer by vm.activeServer.collectAsState()
    val servers by vm.servers.collectAsState()
    var serverMenuExpanded by remember { mutableStateOf(false) }
    val googleUser by GoogleSyncManager.currentUser.collectAsState()
    val downloads by vm.downloads.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val history by vm.history.collectAsState()
    val activeDownloadsCount = downloads.count { it.state != "COMPLETED" }

    // System Back Button Handling: never exit app when in Drawer, SubPage (Settings/Fav/History/Servers), or non-Home tab!
    BackHandler(enabled = drawerState.isOpen) {
        scope.launch { drawerState.close() }
    }
    BackHandler(enabled = !drawerState.isOpen && subPage != SubPage.NONE) {
        subPage = SubPage.NONE
    }
    BackHandler(enabled = !drawerState.isOpen && subPage == SubPage.NONE && currentTab != BottomTab.HOME) {
        currentTab = BottomTab.HOME
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CardDark,
                drawerContentColor = TextPrimary,
                modifier = Modifier.width(290.dp)
            ) {
                // Drawer Header
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(Color(0xFF0E1525), Color(0xFF1A2540))))
                        .statusBarsPadding()
                        .padding(20.dp)
                ) {
                    Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(40.dp))
                    Spacer(Modifier.height(10.dp))
                    Text(s.appName, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text(
                        text = activeServer?.name ?: s.notConnected,
                        color = if (activeServer != null) AccentCyan else TextSecondary,
                        fontSize = 12.sp
                    )
                }

                if (googleUser != null) {
                    Text(
                        text = googleUser!!.email,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Spacer(Modifier.height(6.dp))

                // Stacked Main Sections: Live TV, Movies, Series
                NavigationDrawerItem(
                    label = { Text(s.tabLive, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.LiveTv, contentDescription = null, tint = AccentCyan) },
                    selected = subPage == SubPage.NONE && currentTab == BottomTab.LIVE,
                    onClick = {
                        subPage = SubPage.NONE
                        currentTab = BottomTab.LIVE
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.15f),
                        selectedTextColor = AccentCyan,
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = TextPrimary
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )

                NavigationDrawerItem(
                    label = { Text(s.tabMovies, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.Movie, contentDescription = null, tint = AccentCyan) },
                    selected = subPage == SubPage.NONE && currentTab == BottomTab.MOVIES,
                    onClick = {
                        subPage = SubPage.NONE
                        currentTab = BottomTab.MOVIES
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.15f),
                        selectedTextColor = AccentCyan,
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = TextPrimary
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )

                NavigationDrawerItem(
                    label = { Text(s.tabSeries, fontWeight = FontWeight.SemiBold) },
                    icon = { Icon(Icons.Default.Tv, contentDescription = null, tint = AccentCyan) },
                    selected = subPage == SubPage.NONE && currentTab == BottomTab.SERIES,
                    onClick = {
                        subPage = SubPage.NONE
                        currentTab = BottomTab.SERIES
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.15f),
                        selectedTextColor = AccentCyan,
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = TextPrimary
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )

                HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))

                NavigationDrawerItem(
                    label = { Text("${s.favorites} (${favorites.size})") },
                    icon = { Icon(Icons.Default.Favorite, contentDescription = null, tint = LiveRed) },
                    selected = subPage == SubPage.FAVORITES,
                    onClick = {
                        subPage = SubPage.FAVORITES
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.15f),
                        selectedTextColor = AccentCyan,
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = TextPrimary
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )

                NavigationDrawerItem(
                    label = { Text("${s.recentlyWatched} (${history.size})") },
                    icon = { Icon(Icons.Default.History, contentDescription = null, tint = AccentCyan) },
                    selected = subPage == SubPage.HISTORY,
                    onClick = {
                        subPage = SubPage.HISTORY
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.15f),
                        selectedTextColor = AccentCyan,
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = TextPrimary
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )

                HorizontalDivider(color = BorderSubtle, modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))

                NavigationDrawerItem(
                    label = { Text(s.tabServers) },
                    icon = { Icon(Icons.Default.Dns, contentDescription = null, tint = AccentViolet) },
                    selected = subPage == SubPage.SERVERS,
                    onClick = {
                        subPage = SubPage.SERVERS
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.15f),
                        selectedTextColor = AccentCyan,
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = TextPrimary
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )

                NavigationDrawerItem(
                    label = { Text(s.settingsTitle) },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null, tint = TextSecondary) },
                    selected = subPage == SubPage.SETTINGS,
                    onClick = {
                        subPage = SubPage.SETTINGS
                        scope.launch { drawerState.close() }
                    },
                    colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.15f),
                        selectedTextColor = AccentCyan,
                        unselectedContainerColor = Color.Transparent,
                        unselectedTextColor = TextPrimary
                    ),
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                )
                }
            }
        }
    ) {
        if (subPage == SubPage.SETTINGS) {
            SettingsScreen(onBack = { subPage = SubPage.NONE })
        } else {
            Scaffold(
                containerColor = BgDark,
                topBar = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(listOf(Color(0xFF0E1525), Color(0xFF141C30)))
                            )
                            .statusBarsPadding()
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu", tint = TextPrimary)
                            }
                            Column {
                                Text(s.appName, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                                Text(
                                    text = activeServer?.name ?: s.notConnected,
                                    color = if (activeServer != null) AccentCyan else TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { subPage = SubPage.SEARCH }) {
                                Icon(Icons.Default.Search, contentDescription = "بحث شامل", tint = TextPrimary)
                            }
                            if (activeDownloadsCount > 0) {
                                AssistChip(
                                    onClick = {
                                        subPage = SubPage.NONE
                                        currentTab = BottomTab.DOWNLOADS
                                    },
                                    label = { Text("${s.downloadingBadge} ($activeDownloadsCount)", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold) },
                                    colors = AssistChipDefaults.assistChipColors(containerColor = AccentCyan)
                                )
                                Spacer(Modifier.width(4.dp))
                            }
                            // Server switcher (top-left in RTL): replaces the Settings gear.
                            // Settings stays reachable from the side drawer only.
                            Box {
                                Surface(
                                    onClick = { serverMenuExpanded = true },
                                    shape = RoundedCornerShape(20.dp),
                                    color = CardElevated,
                                    border = BorderStroke(1.dp, BorderSubtle)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(if (activeServer != null) Color(0xFF22C55E) else Color(0xFF64748B))
                                        )
                                        Icon(Icons.Default.Dns, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
                                        Text(
                                            text = activeServer?.name ?: s.notConnected,
                                            color = TextPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            modifier = Modifier.widthIn(max = 120.dp)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                                    }
                                }
                                DropdownMenu(
                                    expanded = serverMenuExpanded,
                                    onDismissRequest = { serverMenuExpanded = false },
                                    modifier = Modifier.background(CardDark)
                                ) {
                                    if (servers.isEmpty()) {
                                        DropdownMenuItem(
                                            text = { Text(s.notConnected, color = TextSecondary, fontSize = 13.sp) },
                                            onClick = { serverMenuExpanded = false }
                                        )
                                    }
                                    servers.forEach { srv ->
                                        val isActive = srv.id == activeServer?.id
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    srv.name,
                                                    color = TextPrimary,
                                                    fontSize = 13.sp,
                                                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                                    maxLines = 1
                                                )
                                            },
                                            onClick = {
                                                vm.activateServer(srv)
                                                Toast.makeText(context, "تم التبديل إلى: ${srv.name}", Toast.LENGTH_SHORT).show()
                                                serverMenuExpanded = false
                                            },
                                            trailingIcon = {
                                                if (isActive) {
                                                    Icon(Icons.Default.Check, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        )
                                    }
                                    HorizontalDivider(color = BorderSubtle)
                                    DropdownMenuItem(
                                        text = { Text(s.manageServers, color = AccentCyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                                        leadingIcon = { Icon(Icons.Default.Dns, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp)) },
                                        onClick = {
                                            serverMenuExpanded = false
                                            subPage = SubPage.SERVERS
                                        }
                                    )
                                }
                            }
                        }
                    }
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = CardDark,
                        tonalElevation = 8.dp
                    ) {
                        BottomTab.entries.forEach { tab ->
                            val selected = subPage == SubPage.NONE && currentTab == tab
                            val label = when (tab) {
                                BottomTab.HOME -> s.tabHome
                                BottomTab.LIVE -> s.tabLive
                                BottomTab.MOVIES -> s.tabMovies
                                BottomTab.SERIES -> s.tabSeries
                                BottomTab.DOWNLOADS -> s.tabDownloads
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    subPage = SubPage.NONE
                                    currentTab = tab
                                },
                                icon = {
                                    if (tab == BottomTab.DOWNLOADS && activeDownloadsCount > 0) {
                                        BadgedBox(badge = { Badge(containerColor = LiveRed) { Text("$activeDownloadsCount") } }) {
                                            Icon(tab.icon, contentDescription = label)
                                        }
                                    } else {
                                        Icon(tab.icon, contentDescription = label)
                                    }
                                },
                                label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AccentCyan,
                                    selectedTextColor = AccentCyan,
                                    indicatorColor = AccentCyan.copy(alpha = 0.15f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                    when (subPage) {
                        SubPage.FAVORITES -> FavoritesAndHistoryScreen(vm, initialTab = 0)
                        SubPage.HISTORY -> FavoritesAndHistoryScreen(vm, initialTab = 1)
                        SubPage.SEARCH -> SearchScreen(
                            vm = vm,
                            onOpenSeries = {
                                subPage = SubPage.NONE
                                currentTab = BottomTab.SERIES
                            },
                            onClose = { subPage = SubPage.NONE }
                        )
                        SubPage.SERVERS -> ServersScreen(vm) {
                            subPage = SubPage.NONE
                            currentTab = BottomTab.HOME
                        }
                        else -> when (currentTab) {
                            BottomTab.HOME -> HomeScreen(
                                vm = vm,
                                onGoToLive = { currentTab = BottomTab.LIVE },
                                onGoToMovies = { currentTab = BottomTab.MOVIES },
                                onGoToSeries = { currentTab = BottomTab.SERIES },
                                onGoToServers = { subPage = SubPage.SERVERS }
                            )
                            BottomTab.LIVE -> LiveTvScreen(vm) { subPage = SubPage.SERVERS }
                            BottomTab.MOVIES -> MoviesScreen(vm) { subPage = SubPage.SERVERS }
                            BottomTab.SERIES -> SeriesScreen(vm) { subPage = SubPage.SERVERS }
                            BottomTab.DOWNLOADS -> DownloadsScreen(vm)
                        }
                    }
                }
            }
        }
    }

    if (!disclaimerAccepted) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = CardDark,
            title = { Text(s.disclaimerTitle, color = AccentCyan, fontWeight = FontWeight.Bold) },
            text = { Text(s.disclaimerBody, color = TextPrimary, fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = { Prefs.acceptDisclaimer(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
                ) {
                    Text(s.disclaimerAccept, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
