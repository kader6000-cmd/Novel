package com.novaiptv.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaiptv.app.ui.*

enum class AppTab(val label: String, val icon: ImageVector) {
    LIVE("مباشر", Icons.Default.LiveTv),
    MOVIES("أفلام", Icons.Default.Movie),
    SERIES("مسلسلات", Icons.Default.Tv),
    FAVORITES("المفضلة", Icons.Default.Favorite),
    DOWNLOADS("التحميلات", Icons.Default.Download),
    SERVERS("السيرفرات", Icons.Default.Dns)
}

class MainActivity : ComponentActivity() {

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            NovaTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    NovaRootApp()
                }
            }
        }
    }
}

@Composable
private fun NovaRootApp(vm: MainViewModel = viewModel()) {
    var currentTab by remember { mutableStateOf(AppTab.LIVE) }
    val activeServer by vm.activeServer.collectAsState()
    val downloads by vm.downloads.collectAsState()
    val activeDownloadsCount = downloads.count { it.state != "COMPLETED" }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(listOf(Color(0xFF0E1525), Color(0xFF141C30)))
                    )
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("NovaIPTV Pro", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text(
                            text = activeServer?.name ?: "غير متصل بسيرفر",
                            color = if (activeServer != null) AccentCyan else TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
                if (activeDownloadsCount > 0) {
                    AssistChip(
                        onClick = { currentTab = AppTab.DOWNLOADS },
                        label = { Text("جاري التحميل ($activeDownloadsCount)", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = AccentCyan)
                    )
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = CardDark,
                tonalElevation = 8.dp
            ) {
                AppTab.entries.forEach { tab ->
                    val selected = currentTab == tab
                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentTab = tab },
                        icon = {
                            if (tab == AppTab.DOWNLOADS && activeDownloadsCount > 0) {
                                BadgedBox(badge = { Badge(containerColor = LiveRed) { Text("$activeDownloadsCount") } }) {
                                    Icon(tab.icon, contentDescription = tab.label)
                                }
                            } else {
                                Icon(tab.icon, contentDescription = tab.label)
                            }
                        },
                        label = { Text(tab.label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AccentCyan,
                            selectedTextColor = AccentCyan,
                            indicatorColor = AccentCyan.copy(alpha = 0.15f),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when (currentTab) {
                AppTab.LIVE -> LiveTvScreen(vm) { currentTab = AppTab.SERVERS }
                AppTab.MOVIES -> MoviesScreen(vm) { currentTab = AppTab.SERVERS }
                AppTab.SERIES -> SeriesScreen(vm) { currentTab = AppTab.SERVERS }
                AppTab.FAVORITES -> FavoritesAndHistoryScreen(vm)
                AppTab.DOWNLOADS -> DownloadsScreen(vm)
                AppTab.SERVERS -> ServersScreen(vm) { currentTab = AppTab.LIVE }
            }
        }
    }
}
