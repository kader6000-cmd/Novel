package com.novaiptv.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaiptv.app.data.Prefs
import com.novaiptv.app.i18n.AppLanguage
import com.novaiptv.app.i18n.LocalStrings
import com.novaiptv.app.i18n.stringsFor
import com.novaiptv.app.security.SecurityGuard
import com.novaiptv.app.ui.*

enum class AppTab(val icon: ImageVector) {
    LIVE(Icons.Default.LiveTv),
    MOVIES(Icons.Default.Movie),
    SERIES(Icons.Default.Tv),
    FAVORITES(Icons.Default.Favorite),
    DOWNLOADS(Icons.Default.Download),
    SERVERS(Icons.Default.Dns)
}

class MainActivity : ComponentActivity() {

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (!SecurityGuard.isSignatureValid(this)) {
            finishAffinity()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            val langCode by Prefs.language.collectAsState()
            val appLang = remember(langCode) { AppLanguage.fromCode(langCode) }
            val strings = remember(appLang) { stringsFor(appLang) }
            val layoutDir = if (appLang.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            NovaTheme {
                CompositionLocalProvider(
                    LocalLayoutDirection provides layoutDir,
                    LocalStrings provides strings
                ) {
                    NovaRootApp()
                }
            }
        }
    }
}

@Composable
private fun NovaRootApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val s = LocalStrings.current
    val disclaimerAccepted by Prefs.disclaimerAccepted.collectAsState()

    var currentTab by remember { mutableStateOf(AppTab.LIVE) }
    var showSettings by remember { mutableStateOf(false) }

    val activeServer by vm.activeServer.collectAsState()
    val downloads by vm.downloads.collectAsState()
    val activeDownloadsCount = downloads.count { it.state != "COMPLETED" }

    if (showSettings) {
        SettingsScreen(onBack = { showSettings = false })
        return
    }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(listOf(Color(0xFF0E1525), Color(0xFF141C30)))
                    )
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(s.appName, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text(
                            text = activeServer?.name ?: s.notConnected,
                            color = if (activeServer != null) AccentCyan else TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (activeDownloadsCount > 0) {
                        AssistChip(
                            onClick = { currentTab = AppTab.DOWNLOADS },
                            label = { Text("${s.downloadingBadge} ($activeDownloadsCount)", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold) },
                            colors = AssistChipDefaults.assistChipColors(containerColor = AccentCyan)
                        )
                        Spacer(Modifier.width(4.dp))
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = s.settingsTitle, tint = TextPrimary)
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = CardDark,
                tonalElevation = 8.dp
            ) {
                AppTab.entries.forEach { tab ->
                    val selected = currentTab == tab
                    val label = when (tab) {
                        AppTab.LIVE -> s.tabLive
                        AppTab.MOVIES -> s.tabMovies
                        AppTab.SERIES -> s.tabSeries
                        AppTab.FAVORITES -> s.tabFavorites
                        AppTab.DOWNLOADS -> s.tabDownloads
                        AppTab.SERVERS -> s.tabServers
                    }
                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentTab = tab },
                        icon = {
                            if (tab == AppTab.DOWNLOADS && activeDownloadsCount > 0) {
                                BadgedBox(badge = { Badge(containerColor = LiveRed) { Text("$activeDownloadsCount") } }) {
                                    Icon(tab.icon, contentDescription = label)
                                }
                            } else {
                                Icon(tab.icon, contentDescription = label)
                            }
                        },
                        label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AccentCyan,
                            selectedTextColor = AccentCyan,
                            indicatorColor = AccentCyan.copy(alpha = 0.15f),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when (currentTab) {
                AppTab.LIVE -> LiveTvScreen(vm) { currentTab = AppTab.SERVERS }
                AppTab.MOVIES -> MoviesScreen(vm) { currentTab = AppTab.SERVERS }
                AppTab.SERIES -> SeriesScreen(vm) { currentTab = AppTab.SERVERS }
                AppTab.FAVORITES -> FavoritesAndHistoryScreen(vm)
                AppTab.DOWNLOADS -> DownloadsScreen(vm)
                AppTab.SERVERS -> ServersScreen(vm) { currentTab = AppTab.LIVE }
            }
        }
    }

    // First-launch Google Play Policy Disclaimer Dialog
    if (!disclaimerAccepted) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = CardDark,
            title = { Text(s.disclaimerTitle, color = AccentCyan, fontWeight = FontWeight.Bold) },
            text = { Text(s.disclaimerBody, color = TextPrimary, fontSize = 13.sp) },
            confirmButton = {
                Button(
                    onClick = { Prefs.acceptDisclaimer(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
                ) {
                    Text(s.disclaimerAccept, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
