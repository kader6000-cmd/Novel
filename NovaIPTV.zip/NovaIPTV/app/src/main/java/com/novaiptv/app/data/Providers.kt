package com.novaiptv.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.URLEncoder

/**
 * واجهة موحّدة لكل أنواع السيرفرات.
 */
interface IptvProvider {
    suspend fun load(kind: Kind): List<Content>
    suspend fun episodes(series: Content): List<Content>
    suspend fun movieDetails(movie: Content): Content = movie
    suspend fun resolve(c: Content): String = c.url
    suspend fun test() {}
}

object Providers {
    fun create(ctx: Context, s: ServerEntity, http: Http): IptvProvider = when (s.type) {
        ServerType.XTREAM.name -> XtreamProvider(s, http)
        ServerType.STALKER.name -> StalkerProvider(s, http)
        else -> M3uProvider(ctx, s, http)
    }
}

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
private fun uaOf(s: ServerEntity) = s.userAgent.ifBlank { DEFAULT_UA }

/** تنظيف رابط السيرفر وإزالة :80 الافتراضية لتجنب مشاكل التحويل في بعض السيرفرات */
fun cleanServerBaseUrl(rawUrl: String): String {
    var u = rawUrl.trim().trimEnd('/')
    if (!u.startsWith("http://", true) && !u.startsWith("https://", true)) {
        u = "http://$u"
    }
    if (u.startsWith("http://", true) && u.endsWith(":80")) {
        u = u.removeSuffix(":80")
    } else if (u.startsWith("https://", true) && u.endsWith(":443")) {
        u = u.removeSuffix(":443")
    }
    return u
}

private fun parseArray(text: String): JSONArray =
    try { JSONArray(text.trim()) } catch (e: Exception) {
        throw IOException("استجابة غير صالحة من السيرفر — تحقق من الرابط وبيانات الدخول")
    }

/* ───────────────────────── Xtream Codes ───────────────────────── */

class XtreamProvider(private val s: ServerEntity, private val http: Http) : IptvProvider {
    private val base = cleanServerBaseUrl(s.url)
    private val ua = uaOf(s)

    private fun api(action: String?, extra: String = ""): String =
        "$base/player_api.php?username=${enc(s.username.trim())}&password=${enc(s.password.trim())}" +
            (if (action != null) "&action=$action" else "") + extra

    override suspend fun test() {
        val o = try { JSONObject(http.get(api(null), ua)) } catch (e: IOException) { throw e } catch (e: Exception) {
            throw IOException("استجابة غير صالحة من السيرفر")
        }
        val ui = o.optJSONObject("user_info") ?: throw IOException("بيانات الدخول غير صحيحة")
        if (ui.str("auth") != "1") throw IOException("اسم المستخدم أو كلمة المرور غير صحيحة")
        val status = ui.str("status")
        if (status.isNotBlank() && !status.equals("Active", true)) throw IOException("الاشتراك غير فعّال: $status")
    }

    override suspend fun load(kind: Kind): List<Content> {
        val (catAction, listAction) = when (kind) {
            Kind.LIVE -> "get_live_categories" to "get_live_streams"
            Kind.MOVIE -> "get_vod_categories" to "get_vod_streams"
            else -> "get_series_categories" to "get_series"
        }
        val cats = HashMap<String, String>()
        try {
            parseArray(http.get(api(catAction), ua)).forEachObj { cats[it.str("category_id")] = it.str("category_name") }
        } catch (_: Exception) { }

        val arr = parseArray(http.get(api(listAction), ua))
        val out = ArrayList<Content>(arr.length())
        val uName = s.username.trim()
        val uPass = s.password.trim()
        arr.forEachObj { o ->
            val group = cats[o.str("category_id")] ?: ""
            when (kind) {
                Kind.LIVE -> {
                    val id = o.str("stream_id")
                    out += Content(
                        key = "${s.id}:L:$id", serverId = s.id, kind = Kind.LIVE, title = o.str("name"),
                        poster = o.str("stream_icon").ifBlank { null }, group = group,
                        url = "$base/live/$uName/$uPass/$id.${s.liveExt}"
                    )
                }
                Kind.MOVIE -> {
                    val id = o.str("stream_id")
                    val ext = o.str("container_extension").ifBlank { "mp4" }
                    out += Content(
                        key = "${s.id}:M:$id", serverId = s.id, kind = Kind.MOVIE, title = o.str("name"),
                        poster = o.str("stream_icon").ifBlank { null }, group = group,
                        url = "$base/movie/$uName/$uPass/$id.$ext",
                        seriesId = id,
                        rating = o.str("rating"), plot = o.str("plot"), ext = ext
                    )
                }
                else -> {
                    val id = o.str("series_id")
                    out += Content(
                        key = "${s.id}:S:$id", serverId = s.id, kind = Kind.SERIES, title = o.str("name"),
                        poster = o.str("cover").ifBlank { null }, group = group, seriesId = id,
                        rating = o.str("rating"), plot = o.str("plot")
                    )
                }
            }
        }
        return out
    }

    override suspend fun movieDetails(movie: Content): Content {
        val vodId = movie.seriesId ?: movie.key.substringAfterLast(':')
        if (vodId.isBlank()) return movie
        return try {
            val o = JSONObject(http.get(api("get_vod_info", "&vod_id=$vodId"), ua))
            val info = o.optJSONObject("info")
            val movieData = o.optJSONObject("movie_data")
            val ext = movieData?.str("container_extension")?.ifBlank { null } ?: movie.ext.ifBlank { "mp4" }
            val streamId = movieData?.str("stream_id")?.ifBlank { null } ?: vodId
            val plot = info?.str("plot")?.ifBlank { info.str("description") }?.ifBlank { movie.plot } ?: movie.plot
            val rating = info?.str("rating")?.ifBlank { movie.rating } ?: movie.rating
            val poster = info?.str("movie_image")?.ifBlank { info.str("cover_big") }?.ifBlank { movie.poster } ?: movie.poster
            val uName = s.username.trim()
            val uPass = s.password.trim()
            movie.copy(
                poster = poster,
                plot = plot,
                rating = rating,
                ext = ext,
                url = "$base/movie/$uName/$uPass/$streamId.$ext"
            )
        } catch (_: Exception) {
            movie
        }
    }

    override suspend fun episodes(series: Content): List<Content> {
        val o = JSONObject(http.get(api("get_series_info", "&series_id=${series.seriesId}"), ua))
        val out = ArrayList<Content>()
        val uName = s.username.trim()
        val uPass = s.password.trim()
        fun addSeason(season: Int, arr: JSONArray) {
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                val id = e.str("id")
                val ext = e.str("container_extension").ifBlank { "mp4" }
                val info = e.optJSONObject("info")
                val epNum = e.str("episode_num").toIntOrNull() ?: (i + 1)
                out += Content(
                    key = "${s.id}:E:$id", serverId = s.id, kind = Kind.EPISODE,
                    title = e.str("title").ifBlank { "حلقة $epNum" },
                    poster = info?.str("movie_image")?.ifBlank { null } ?: series.poster,
                    group = series.group, url = "$base/series/$uName/$uPass/$id.$ext",
                    seriesId = series.seriesId, seriesTitle = series.title,
                    season = season, episode = epNum, ext = ext, plot = info?.str("plot") ?: ""
                )
            }
        }
        when (val raw = o.opt("episodes")) {
            is JSONObject -> raw.keys().asSequence().toList().sortedBy { it.toIntOrNull() ?: 0 }.forEach { k ->
                raw.optJSONArray(k)?.let { addSeason(k.toIntOrNull() ?: 1, it) }
            }
            is JSONArray -> for (i in 0 until raw.length()) raw.optJSONArray(i)?.let { addSeason(i + 1, it) }
            else -> {}
        }
        return out
    }
}

/* ───────────────────────── M3U (رابط أو ملف) ───────────────────────── */

class M3uProvider(private val ctx: Context, private val s: ServerEntity, private val http: Http) : IptvProvider {
    private class Parsed(val live: List<Content>, val movies: List<Content>, val episodes: List<Content>)

    private var parsed: Parsed? = null
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")
    private val epRe = Regex("^(.*?)[\\s._-]*[Ss](\\d{1,2})[\\s._-]*[Ee](\\d{1,3})")
    private val videoExt = Regex("\\.(mp4|mkv|avi|mov|wmv|flv)(\\?.*)?$")
    private val movieWords = listOf("movie", "film", "vod", "أفلام", "افلام", "فيلم")
    private val seriesWords = listOf("series", "مسلسل", "season")

    private fun open(): BufferedReader =
        if (s.type == ServerType.M3U_FILE.name) {
            val ins = ctx.contentResolver.openInputStream(Uri.parse(s.url)) ?: throw IOException("تعذّر فتح الملف")
            BufferedReader(InputStreamReader(ins, Charsets.UTF_8), 64 * 1024)
        } else {
            http.reader(s.url.trim(), uaOf(s))
        }

    override suspend fun test() {
        withContext(Dispatchers.IO) {
            open().use { r ->
                var line = r.readLine()
                while (line != null && line.isBlank()) line = r.readLine()
                if (line == null || !line.trim().startsWith("#EXTM3U")) throw IOException("الملف ليس قائمة M3U صالحة")
            }
        }
    }

    private suspend fun ensure(): Parsed {
        parsed?.let { return it }
        val p = withContext(Dispatchers.IO) { open().use { parse(it) } }
        parsed = p
        return p
    }

    private fun parse(r: BufferedReader): Parsed {
        val live = ArrayList<Content>(); val movies = ArrayList<Content>(); val eps = ArrayList<Content>()
        var title = ""; var logo: String? = null; var group = ""; var pending = false
        r.forEachLine { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    val attrs = attr.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    val noAttrs = attr.replace(line, "")
                    title = noAttrs.substringAfter(",", "").trim().ifBlank { attrs["tvg-name"] ?: "" }
                    logo = attrs["tvg-logo"]?.ifBlank { null }
                    group = attrs["group-title"] ?: ""
                    pending = true
                }
                line.startsWith("#EXTGRP:") -> group = line.removePrefix("#EXTGRP:").trim()
                line.isEmpty() || line.startsWith("#") -> {}
                pending -> {
                    pending = false
                    val url = line
                    val h = Integer.toHexString(url.hashCode())
                    val g = group.lowercase()
                    val m = epRe.find(title)
                    val kind = when {
                        url.contains("/series/") || m != null -> Kind.EPISODE
                        url.contains("/movie/") || videoExt.containsMatchIn(url.lowercase()) ||
                            movieWords.any { g.contains(it) } -> Kind.MOVIE
                        seriesWords.any { g.contains(it) } -> Kind.EPISODE
                        else -> Kind.LIVE
                    }
                    when (kind) {
                        Kind.LIVE -> live += Content("${s.id}:L:$h", s.id, Kind.LIVE, title.ifBlank { "قناة" }, logo, group, url)
                        Kind.MOVIE -> movies += Content("${s.id}:M:$h", s.id, Kind.MOVIE, title.ifBlank { "فيلم" }, logo, group, url)
                        else -> {
                            val name = (m?.groupValues?.get(1)?.trim()).orEmpty().ifBlank { title.ifBlank { group.ifBlank { "مسلسل" } } }
                            val season = m?.groupValues?.get(2)?.toIntOrNull() ?: 1
                            val ep = m?.groupValues?.get(3)?.toIntOrNull() ?: (eps.size + 1)
                            eps += Content(
                                "${s.id}:E:$h", s.id, Kind.EPISODE, title.ifBlank { "حلقة $ep" }, logo, group, url,
                                seriesId = name, seriesTitle = name, season = season, episode = ep
                            )
                        }
                    }
                }
            }
        }
        return Parsed(live, movies, eps)
    }

    override suspend fun load(kind: Kind): List<Content> {
        val p = ensure()
        return when (kind) {
            Kind.LIVE -> p.live
            Kind.MOVIE -> p.movies
            else -> p.episodes.groupBy { it.seriesId }.map { (name, list) ->
                val first = list.first()
                Content(
                    key = "${s.id}:S:$name", serverId = s.id, kind = Kind.SERIES, title = name ?: first.title,
                    poster = list.firstNotNullOfOrNull { it.poster }, group = first.group, seriesId = name
                )
            }
        }
    }

    override suspend fun episodes(series: Content): List<Content> =
        ensure().episodes.filter { it.seriesId == series.seriesId }.sortedWith(compareBy({ it.season }, { it.episode }))
}

/* ───────────────────────── Stalker / MAG Portal ───────────────────────── */

class StalkerProvider(private val s: ServerEntity, private val http: Http) : IptvProvider {
    private val ua = s.userAgent.ifBlank {
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
    }
    private val api: String = run {
        var u = cleanServerBaseUrl(s.url)
        when {
            u.endsWith("load.php") || u.endsWith("portal.php") -> u
            u.endsWith("/c") -> u.removeSuffix("/c") + "/server/load.php"
            else -> "$u/server/load.php"
        }
    }
    private val origin: String = Regex("^(https?://[^/]+)").find(api)?.groupValues?.get(1) ?: api
    private var token = ""
    private val seriesEpisodes = HashMap<String, List<Content>>()
    private var vodCache: Pair<List<Content>, List<Content>>? = null

    private fun headers(): Map<String, String> = buildMap {
        put("Cookie", "mac=${s.mac}; stb_lang=en; timezone=Europe/London")
        put("X-User-Agent", "Model: MAG250; Link: WiFi")
        if (token.isNotEmpty()) put("Authorization", "Bearer $token")
    }

    private suspend fun call(query: String): Any? {
        val txt = http.get("$api?$query&JsHttpRequest=1-xml", ua, headers())
        return try { JSONObject(txt).opt("js") } catch (e: Exception) { throw IOException("استجابة غير صالحة من البوابة") }
    }
    private suspend fun callObj(q: String): JSONObject = call(q) as? JSONObject ?: JSONObject()
    private suspend fun callArr(q: String): JSONArray = call(q) as? JSONArray ?: JSONArray()

    private suspend fun auth() {
        if (token.isNotEmpty()) return
        if (s.mac.isBlank()) throw IOException("أدخل عنوان MAC للبوابة")
        token = callObj("type=stb&action=handshake&token=").str("token")
        if (token.isEmpty()) throw IOException("فشل الاتصال بالبوابة (handshake) — تحقق من الرابط و MAC")
        callObj("type=stb&action=get_profile&hd=1&sn=&stb_type=MAG250&client_type=STB&auth_second_step=1&not_valid_token=0")
    }

    override suspend fun test() { auth() }

    private fun logo(o: JSONObject): String? {
        val l = o.str("logo").ifBlank { o.str("screenshot_uri") }
        return if (l.startsWith("http")) l else null
    }

    override suspend fun load(kind: Kind): List<Content> {
        auth()
        if (kind == Kind.LIVE) {
            val genres = HashMap<String, String>()
            callArr("type=itv&action=get_genres").forEachObj { genres[it.str("id")] = it.str("title") }
            val data = callObj("type=itv&action=get_all_channels").optJSONArray("data") ?: JSONArray()
            val out = ArrayList<Content>(data.length())
            data.forEachObj { o ->
                out += Content(
                    key = "${s.id}:L:${o.str("id")}", serverId = s.id, kind = Kind.LIVE, title = o.str("name"),
                    poster = logo(o), group = genres[o.str("tv_genre_id")] ?: "", url = o.str("cmd"), resolve = true
                )
            }
            return out
        }
        val (movies, series) = loadVod()
        return if (kind == Kind.MOVIE) movies else series
    }

    private suspend fun loadVod(): Pair<List<Content>, List<Content>> {
        vodCache?.let { return it }
        auth()
        val cats = HashMap<String, String>()
        callArr("type=vod&action=get_categories").forEachObj { cats[it.str("id")] = it.str("title") }
        val movies = ArrayList<Content>(); val series = ArrayList<Content>()
        var page = 1; var total = Int.MAX_VALUE; var seen = 0
        while (page <= 40 && seen < total) {
            val js = callObj("type=vod&action=get_ordered_list&category=0&sortby=added&p=$page")
            total = js.optInt("total_items", 0)
            val data = js.optJSONArray("data") ?: break
            if (data.length() == 0) break
            seen += data.length()
            data.forEachObj { o ->
                val id = o.str("id"); val cmd = o.str("cmd"); val group = cats[o.str("category_id")] ?: ""
                val ser = o.optJSONArray("series")
                if (o.str("is_series") == "1" && ser != null && ser.length() > 0) {
                    val sc = Content(
                        key = "${s.id}:S:$id", serverId = s.id, kind = Kind.SERIES, title = o.str("name"),
                        poster = logo(o), group = group, seriesId = id, plot = o.str("description"), rating = o.str("rating_imdb")
                    )
                    series += sc
                    seriesEpisodes[id] = (0 until ser.length()).map { i ->
                        val n = ser.optInt(i)
                        Content(
                            key = "${s.id}:E:$id:$n", serverId = s.id, kind = Kind.EPISODE, title = "حلقة $n",
                            poster = sc.poster, group = group, url = "$cmd#series=$n", seriesId = id,
                            seriesTitle = sc.title, season = 1, episode = n, resolve = true
                        )
                    }
                } else {
                    movies += Content(
                        key = "${s.id}:M:$id", serverId = s.id, kind = Kind.MOVIE, title = o.str("name"),
                        poster = logo(o), group = group, url = cmd, plot = o.str("description"),
                        rating = o.str("rating_imdb"), resolve = true
                    )
                }
            }
            page++
        }
        return (movies as List<Content> to series as List<Content>).also { vodCache = it }
    }

    override suspend fun episodes(series: Content): List<Content> {
        loadVod()
        return seriesEpisodes[series.seriesId] ?: emptyList()
    }

    override suspend fun resolve(c: Content): String {
        auth()
        val parts = c.url.split("#series=")
        val cmd = parts[0]
        val extra = parts.getOrNull(1)?.let { "&series=$it" } ?: ""
        val type = if (c.kind == Kind.LIVE) "itv" else "vod"
        val js = callObj("type=$type&action=create_link&cmd=${enc(cmd)}$extra&forced_storage=undefined&disable_ad=0")
        val link = js.str("cmd").removePrefix("ffmpeg ").removePrefix("auto ").trim()
        if (link.isBlank()) throw IOException("لم تُرجع البوابة رابط تشغيل")
        return if (link.startsWith("http")) link else origin + link
    }
}
