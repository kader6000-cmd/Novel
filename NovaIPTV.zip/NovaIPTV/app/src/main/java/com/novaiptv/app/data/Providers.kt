package com.novaiptv.app.data

import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URLEncoder

interface IptvProvider {
    suspend fun loadCategories(kind: ContentKind): List<Category>
    suspend fun loadItems(kind: ContentKind, categoryId: String? = null): List<MediaItem>
    suspend fun loadSeriesDetail(series: MediaItem): SeriesDetail
}

class XtreamProvider(private val server: ServerEntity) : IptvProvider {
    private val base = server.host.trim().trimEnd('/')
    private val user = URLEncoder.encode(server.username.trim(), "UTF-8")
    private val pass = URLEncoder.encode(server.password.trim(), "UTF-8")

    private fun api(action: String, extra: String = ""): String {
        return "$base/player_api.php?username=$user&password=$pass&action=$action$extra"
    }

    override suspend fun loadCategories(kind: ContentKind): List<Category> = withContext(Dispatchers.IO) {
        val action = when (kind) {
            ContentKind.LIVE -> "get_live_categories"
            ContentKind.MOVIE -> "get_vod_categories"
            ContentKind.SERIES -> "get_series_categories"
        }
        val raw = HttpClient.getString(api(action))
        val result = mutableListOf<Category>()
        val el = runCatching { JsonParser.parseString(raw) }.getOrNull() ?: return@withContext result
        if (el.isJsonArray) {
            el.asJsonArray.forEach { node ->
                if (!node.isJsonObject) return@forEach
                val obj = node.asJsonObject
                val id = obj.get("category_id")?.takeIf { !it.isJsonNull }?.asString ?: return@forEach
                val name = obj.get("category_name")?.takeIf { !it.isJsonNull }?.asString ?: "تصنيف"
                result.add(Category(id, name))
            }
        }
        result
    }

    override suspend fun loadItems(kind: ContentKind, categoryId: String?): List<MediaItem> = withContext(Dispatchers.IO) {
        val action = when (kind) {
            ContentKind.LIVE -> "get_live_streams"
            ContentKind.MOVIE -> "get_vod_streams"
            ContentKind.SERIES -> "get_series"
        }
        val extra = if (!categoryId.isNullOrBlank() && categoryId != "ALL") "&category_id=$categoryId" else ""
        val raw = HttpClient.getString(api(action, extra))
        val result = mutableListOf<MediaItem>()
        val el = runCatching { JsonParser.parseString(raw) }.getOrNull() ?: return@withContext result
        if (!el.isJsonArray) return@withContext result

        el.asJsonArray.forEach { node ->
            if (!node.isJsonObject) return@forEach
            val obj = node.asJsonObject
            when (kind) {
                ContentKind.LIVE -> {
                    val id = obj.get("stream_id")?.takeIf { !it.isJsonNull }?.asString ?: return@forEach
                    val name = obj.get("name")?.takeIf { !it.isJsonNull }?.asString ?: "قناة"
                    val logo = obj.get("stream_icon")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    val catId = obj.get("category_id")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    val url = "$base/live/${server.username.trim()}/${server.password.trim()}/$id.ts"
                    result.add(MediaItem(id, name, logo, catId, "", url, ContentKind.LIVE, "ts"))
                }
                ContentKind.MOVIE -> {
                    val id = obj.get("stream_id")?.takeIf { !it.isJsonNull }?.asString ?: return@forEach
                    val name = obj.get("name")?.takeIf { !it.isJsonNull }?.asString ?: "فيلم"
                    val logo = obj.get("stream_icon")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    val catId = obj.get("category_id")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    val ext = obj.get("container_extension")?.takeIf { !it.isJsonNull }?.asString?.ifBlank { "mp4" } ?: "mp4"
                    val rating = obj.get("rating")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    val url = "$base/movie/${server.username.trim()}/${server.password.trim()}/$id.$ext"
                    result.add(MediaItem(id, name, logo, catId, "", url, ContentKind.MOVIE, ext, rating))
                }
                ContentKind.SERIES -> {
                    val id = obj.get("series_id")?.takeIf { !it.isJsonNull }?.asString ?: return@forEach
                    val name = obj.get("name")?.takeIf { !it.isJsonNull }?.asString ?: "مسلسل"
                    val logo = obj.get("cover")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    val catId = obj.get("category_id")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    val rating = obj.get("rating")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    val plot = obj.get("plot")?.takeIf { !it.isJsonNull }?.asString ?: ""
                    result.add(MediaItem(id, name, logo, catId, "", "", ContentKind.SERIES, "mp4", rating, plot))
                }
            }
        }
        result
    }

    override suspend fun loadSeriesDetail(series: MediaItem): SeriesDetail = withContext(Dispatchers.IO) {
        val raw = HttpClient.getString(api("get_series_info", "&series_id=${series.id}"))
        val seasonsMap = sortedMapOf<Int, MutableList<EpisodeItem>>()
        val el = runCatching { JsonParser.parseString(raw) }.getOrNull()
        if (el != null && el.isJsonObject) {
            val root = el.asJsonObject
            val episodesEl = root.get("episodes")
            if (episodesEl != null && episodesEl.isJsonObject) {
                val epObj = episodesEl.asJsonObject
                for (seasonKey in epObj.keySet()) {
                    val seasonNum = seasonKey.toIntOrNull() ?: 1
                    val arr = epObj.get(seasonKey)
                    if (arr != null && arr.isJsonArray) {
                        val list = seasonsMap.getOrPut(seasonNum) { mutableListOf() }
                        arr.asJsonArray.forEach { epNode ->
                            if (!epNode.isJsonObject) return@forEach
                            val e = epNode.asJsonObject
                            val id = e.get("id")?.takeIf { !it.isJsonNull }?.asString ?: return@forEach
                            val epNum = e.get("episode_num")?.takeIf { !it.isJsonNull }?.asString?.toIntOrNull() ?: (list.size + 1)
                            val title = e.get("title")?.takeIf { !it.isJsonNull }?.asString?.ifBlank { "الحلقة $epNum" } ?: "الحلقة $epNum"
                            val ext = e.get("container_extension")?.takeIf { !it.isJsonNull }?.asString?.ifBlank { "mp4" } ?: "mp4"
                            val infoObj = e.get("info")?.takeIf { it.isJsonObject }?.asJsonObject
                            val thumb = infoObj?.get("movie_image")?.takeIf { !it.isJsonNull }?.asString ?: series.logo
                            val duration = infoObj?.get("duration")?.takeIf { !it.isJsonNull }?.asString ?: ""
                            val url = "$base/series/${server.username.trim()}/${server.password.trim()}/$id.$ext"
                            list.add(EpisodeItem(id, seasonNum, epNum, title, url, thumb, ext, duration))
                        }
                    }
                }
            }
        }
        SeriesDetail(series, seasonsMap)
    }
}

class M3uProvider(private val server: ServerEntity) : IptvProvider {
    @Volatile private var cachedItems: List<MediaItem>? = null

    private suspend fun ensureParsed(): List<MediaItem> = withContext(Dispatchers.IO) {
        cachedItems?.let { return@withContext it }
        val raw = HttpClient.getString(server.host.trim())
        val lines = raw.lines()
        val items = mutableListOf<MediaItem>()
        var currentName = ""
        var currentLogo = ""
        var currentGroup = "عام"
        var index = 0

        val logoRegex = Regex("tvg-logo=\"([^\"]*)\"")
        val groupRegex = Regex("group-title=\"([^\"]*)\"")

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.startsWith("#EXTINF", ignoreCase = true)) {
                currentLogo = logoRegex.find(trimmed)?.groupValues?.getOrNull(1) ?: ""
                currentGroup = groupRegex.find(trimmed)?.groupValues?.getOrNull(1)?.ifBlank { "عام" } ?: "عام"
                currentName = trimmed.substringAfterLast(",", "قناة").trim()
            } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                index++
                val lowerUrl = trimmed.lowercase()
                val lowerGroup = currentGroup.lowercase()
                val kind = when {
                    lowerUrl.contains("/series/") || lowerGroup.contains("series") || lowerGroup.contains("مسلسل") -> ContentKind.SERIES
                    lowerUrl.contains("/movie/") || lowerUrl.endsWith(".mp4") || lowerUrl.endsWith(".mkv") || lowerGroup.contains("movie") || lowerGroup.contains("أفلام") || lowerGroup.contains("افلام") -> ContentKind.MOVIE
                    else -> ContentKind.LIVE
                }
                val ext = when {
                    lowerUrl.endsWith(".mkv") -> "mkv"
                    lowerUrl.endsWith(".mp4") -> "mp4"
                    lowerUrl.endsWith(".m3u8") -> "m3u8"
                    else -> "ts"
                }
                items.add(
                    MediaItem(
                        id = "m3u_$index",
                        name = currentName.ifBlank { "عنصر $index" },
                        logo = currentLogo,
                        categoryId = currentGroup,
                        categoryName = currentGroup,
                        streamUrl = trimmed,
                        kind = kind,
                        extension = ext
                    )
                )
            }
        }
        cachedItems = items
        items
    }

    override suspend fun loadCategories(kind: ContentKind): List<Category> {
        val all = ensureParsed().filter { it.kind == kind }
        return all.map { it.categoryName }.distinct().map { Category(it, it) }
    }

    override suspend fun loadItems(kind: ContentKind, categoryId: String?): List<MediaItem> {
        val all = ensureParsed().filter { it.kind == kind }
        return if (categoryId.isNullOrBlank() || categoryId == "ALL") all
        else all.filter { it.categoryId == categoryId }
    }

    override suspend fun loadSeriesDetail(series: MediaItem): SeriesDetail {
        val ep = EpisodeItem(series.id, 1, 1, series.name, series.streamUrl, series.logo, series.extension)
        return SeriesDetail(series, mapOf(1 to listOf(ep)))
    }
}

class StalkerProvider(private val server: ServerEntity) : IptvProvider {
    private val portal = server.host.trim().trimEnd('/')
    private val mac = server.mac.trim().uppercase()
    @Volatile private var token: String = ""

    private fun headers(): Map<String, String> = buildMap {
        put("Cookie", "mac=${URLEncoder.encode(mac, "UTF-8")}; stb_lang=en; timezone=UTC")
        put("X-User-Agent", "Model: MAG250; Link: WiFi")
        if (token.isNotBlank()) put("Authorization", "Bearer $token")
    }

    private fun ensureToken() {
        if (token.isNotBlank()) return
        val url = "$portal/portal.php?type=stb&action=handshake&JsHttpRequest=1-xml"
        val raw = HttpClient.getString(url, headers())
        val el = runCatching { JsonParser.parseString(raw) }.getOrNull()
        token = el?.asJsonObject?.getAsJsonObject("js")?.get("token")?.asString ?: ""
    }

    override suspend fun loadCategories(kind: ContentKind): List<Category> = withContext(Dispatchers.IO) {
        ensureToken()
        val type = if (kind == ContentKind.LIVE) "itv" else "vod"
        val action = if (kind == ContentKind.LIVE) "get_genres" else "get_categories"
        val raw = HttpClient.getString("$portal/portal.php?type=$type&action=$action&JsHttpRequest=1-xml", headers())
        val out = mutableListOf<Category>()
        val js = runCatching { JsonParser.parseString(raw).asJsonObject.get("js") }.getOrNull()
        if (js != null && js.isJsonArray) {
            js.asJsonArray.forEach { n ->
                if (!n.isJsonObject) return@forEach
                val o = n.asJsonObject
                val id = o.get("id")?.takeIf { !it.isJsonNull }?.asString ?: return@forEach
                val title = o.get("title")?.takeIf { !it.isJsonNull }?.asString ?: "تصنيف"
                if (id != "*") out.add(Category(id, title))
            }
        }
        out
    }

    override suspend fun loadItems(kind: ContentKind, categoryId: String?): List<MediaItem> = withContext(Dispatchers.IO) {
        ensureToken()
        val type = if (kind == ContentKind.LIVE) "itv" else "vod"
        val catParam = if (!categoryId.isNullOrBlank() && categoryId != "ALL") "&genre=$categoryId&category=$categoryId" else ""
        val raw = HttpClient.getString("$portal/portal.php?type=$type&action=get_ordered_list$catParam&p=1&JsHttpRequest=1-xml", headers())
        val out = mutableListOf<MediaItem>()
        val data = runCatching { JsonParser.parseString(raw).asJsonObject.getAsJsonObject("js").getAsJsonArray("data") }.getOrNull()
        data?.forEach { n ->
            if (!n.isJsonObject) return@forEach
            val o = n.asJsonObject
            val id = o.get("id")?.takeIf { !it.isJsonNull }?.asString ?: return@forEach
            val name = o.get("name")?.takeIf { !it.isJsonNull }?.asString ?: "عنصر"
            val logo = o.get("logo")?.takeIf { !it.isJsonNull }?.asString ?: ""
            val cmd = o.get("cmd")?.takeIf { !it.isJsonNull }?.asString?.removePrefix("ffmpeg ")?.trim() ?: ""
            out.add(MediaItem(id, name, logo, categoryId ?: "", "", cmd, kind))
        }
        out
    }

    override suspend fun loadSeriesDetail(series: MediaItem): SeriesDetail {
        val ep = EpisodeItem(series.id, 1, 1, series.name, series.streamUrl, series.logo)
        return SeriesDetail(series, mapOf(1 to listOf(ep)))
    }
}

object ProviderFactory {
    fun create(server: ServerEntity): IptvProvider = when (server.type) {
        ServerType.M3U.name -> M3uProvider(server)
        ServerType.STALKER.name -> StalkerProvider(server)
        else -> XtreamProvider(server)
    }
}
