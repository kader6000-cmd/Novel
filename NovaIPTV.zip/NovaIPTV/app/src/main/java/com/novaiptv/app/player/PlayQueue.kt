package com.novaiptv.app.player

import com.novaiptv.app.data.ContentKind

data class QueueItem(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val url: String,
    val logo: String = "",
    val kind: ContentKind = ContentKind.LIVE,
    val serverId: Long = 0L
)

object PlayQueue {
    @Volatile var items: List<QueueItem> = emptyList()
    @Volatile var currentIndex: Int = 0
    @Volatile var sectionTitle: String = "قائمة التشغيل"

    fun setQueue(list: List<QueueItem>, startIndex: Int, title: String) {
        items = list
        currentIndex = startIndex.coerceIn(0, (list.size - 1).coerceAtLeast(0))
        sectionTitle = title
    }

    fun current(): QueueItem? = items.getOrNull(currentIndex)
}
