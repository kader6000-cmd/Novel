package com.novaiptv.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.data.ContentKind
import com.novaiptv.app.data.MediaItem
import com.novaiptv.app.data.SeriesDetail
import com.novaiptv.app.player.PlayerActivity
import com.novaiptv.app.player.QueueItem

@Composable
fun LiveTvScreen(vm: MainViewModel, onGoToServers: () -> Unit) {
    val context = LocalContext.current
    val activeServer by vm.activeServer.collectAsState()
    val state by vm.liveState.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val favKeys = remember(favorites) { favorites.map { it.key }.toSet() }

    var searchQuery by remember { mutableStateOf("") }
    var isGrid by remember { mutableStateOf(true) }

    LaunchedEffect(activeServer?.id) {
        if (activeServer != null) vm.loadSection(ContentKind.LIVE)
    }

    if (activeServer == null) {
        EmptyOrErrorBox("لا يوجد سيرفر مضاف حالياً.\nأضف سيرفر Xtream أو M3U أو Stalker للبدء.", "إضافة سيرفر", onGoToServers)
        return
    }

    val filtered = remember(state.items, searchQuery) {
        if (searchQuery.isBlank()) state.items
        else state.items.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    val selectedCatName = state.categories.find { it.id == state.selectedCategoryId }?.name ?: "القنوات المباشرة"

    Column(modifier = Modifier.fillMaxSize()) {
        SearchAndControlsBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            placeholder = "ابحث عن قناة...",
            isGrid = isGrid,
            onToggleGrid = { isGrid = !isGrid },
            onRefresh = { vm.loadSection(ContentKind.LIVE, state.selectedCategoryId, force = true) }
        )

        CategoryTabsRow(
            categories = state.categories,
            selectedId = state.selectedCategoryId,
            onSelect = { catId -> vm.loadSection(ContentKind.LIVE, catId) }
        )

        when {
            state.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentCyan)
            }
            state.error != null -> EmptyOrErrorBox(state.error!!, "إعادة المحاولة") {
                vm.loadSection(ContentKind.LIVE, state.selectedCategoryId, force = true)
            }
            filtered.isEmpty() -> EmptyOrErrorBox("لا توجد قنوات في هذا التصنيف")
            isGrid -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(116.dp),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(filtered, key = { idx, it -> "${it.id}_$idx" }) { index, item ->
                        val favKey = "${activeServer!!.id}_${item.kind.name}_${item.id}"
                        val isFav = favKey in favKeys
                        LiveChannelGridCard(
                            item = item,
                            isFavorite = isFav,
                            onClick = {
                                val queue = filtered.map {
                                    QueueItem(it.id, it.name, selectedCatName, it.streamUrl, it.logo, ContentKind.LIVE, activeServer!!.id)
                                }
                                PlayerActivity.launch(context, queue, index, selectedCatName)
                            },
                            onToggleFav = { vm.toggleFavorite(item, isFav) }
                        )
                    }
                }
            }
            else -> {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(filtered, key = { idx, it -> "${it.id}_$idx" }) { index, item ->
                        val favKey = "${activeServer!!.id}_${item.kind.name}_${item.id}"
                        val isFav = favKey in favKeys
                        LiveChannelListRow(
                            item = item,
                            isFavorite = isFav,
                            onClick = {
                                val queue = filtered.map {
                                    QueueItem(it.id, it.name, selectedCatName, it.streamUrl, it.logo, ContentKind.LIVE, activeServer!!.id)
                                }
                                PlayerActivity.launch(context, queue, index, selectedCatName)
                            },
                            onToggleFav = { vm.toggleFavorite(item, isFav) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MoviesScreen(vm: MainViewModel, onGoToServers: () -> Unit) {
    val context = LocalContext.current
    val activeServer by vm.activeServer.collectAsState()
    val state by vm.movieState.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val favKeys = remember(favorites) { favorites.map { it.key }.toSet() }
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(activeServer?.id) {
        if (activeServer != null) vm.loadSection(ContentKind.MOVIE)
    }

    if (activeServer == null) {
        EmptyOrErrorBox("لا يوجد سيرفر مضاف حالياً.", "إضافة سيرفر", onGoToServers)
        return
    }

    val filtered = remember(state.items, searchQuery) {
        if (searchQuery.isBlank()) state.items
        else state.items.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    val selectedCatName = state.categories.find { it.id == state.selectedCategoryId }?.name ?: "الأفلام"

    Column(modifier = Modifier.fillMaxSize()) {
        SearchAndControlsBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            placeholder = "ابحث عن فيلم...",
            onRefresh = { vm.loadSection(ContentKind.MOVIE, state.selectedCategoryId, force = true) }
        )

        CategoryTabsRow(
            categories = state.categories,
            selectedId = state.selectedCategoryId,
            onSelect = { catId -> vm.loadSection(ContentKind.MOVIE, catId) }
        )

        when {
            state.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentCyan)
            }
            state.error != null -> EmptyOrErrorBox(state.error!!, "إعادة المحاولة") {
                vm.loadSection(ContentKind.MOVIE, state.selectedCategoryId, force = true)
            }
            filtered.isEmpty() -> EmptyOrErrorBox("لا توجد أفلام في هذا التصنيف")
            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(115.dp),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(filtered, key = { idx, it -> "${it.id}_$idx" }) { index, item ->
                        val favKey = "${activeServer!!.id}_${item.kind.name}_${item.id}"
                        val isFav = favKey in favKeys
                        PosterMediaCard(
                            item = item,
                            isFavorite = isFav,
                            showDownloadButton = true,
                            onClick = {
                                val queue = filtered.map {
                                    QueueItem(it.id, it.name, selectedCatName, it.streamUrl, it.logo, ContentKind.MOVIE, activeServer!!.id)
                                }
                                PlayerActivity.launch(context, queue, index, selectedCatName)
                            },
                            onToggleFav = { vm.toggleFavorite(item, isFav) },
                            onDownload = {
                                vm.startDownload("movie_${item.id}", item.name, item.streamUrl, item.logo, item.extension)
                                Toast.makeText(context, "بدأ تحميل: ${item.name}", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesScreen(vm: MainViewModel, onGoToServers: () -> Unit) {
    val context = LocalContext.current
    val activeServer by vm.activeServer.collectAsState()
    val state by vm.seriesState.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val favKeys = remember(favorites) { favorites.map { it.key }.toSet() }
    val seriesDetail by vm.seriesDetail.collectAsState()
    val detailLoading by vm.seriesDetailLoading.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(activeServer?.id) {
        if (activeServer != null) vm.loadSection(ContentKind.SERIES)
    }

    if (activeServer == null) {
        EmptyOrErrorBox("لا يوجد سيرفر مضاف حالياً.", "إضافة سيرفر", onGoToServers)
        return
    }

    val filtered = remember(state.items, searchQuery) {
        if (searchQuery.isBlank()) state.items
        else state.items.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SearchAndControlsBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            placeholder = "ابحث عن مسلسل...",
            onRefresh = { vm.loadSection(ContentKind.SERIES, state.selectedCategoryId, force = true) }
        )

        CategoryTabsRow(
            categories = state.categories,
            selectedId = state.selectedCategoryId,
            onSelect = { catId -> vm.loadSection(ContentKind.SERIES, catId) }
        )

        when {
            state.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentCyan)
            }
            state.error != null -> EmptyOrErrorBox(state.error!!, "إعادة المحاولة") {
                vm.loadSection(ContentKind.SERIES, state.selectedCategoryId, force = true)
            }
            filtered.isEmpty() -> EmptyOrErrorBox("لا توجد مسلسلات في هذا التصنيف")
            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(115.dp),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(filtered, key = { idx, it -> "${it.id}_$idx" }) { _, item ->
                        val favKey = "${activeServer!!.id}_${item.kind.name}_${item.id}"
                        val isFav = favKey in favKeys
                        PosterMediaCard(
                            item = item,
                            isFavorite = isFav,
                            showDownloadButton = false,
                            onClick = { vm.openSeriesDetail(item) },
                            onToggleFav = { vm.toggleFavorite(item, isFav) }
                        )
                    }
                }
            }
        }
    }

    if (detailLoading || seriesDetail != null) {
        ModalBottomSheet(
            onDismissRequest = { vm.closeSeriesDetail() },
            containerColor = CardDark
        ) {
            if (detailLoading) {
                Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = AccentCyan)
                }
            } else {
                seriesDetail?.let { detail ->
                    SeriesDetailContent(
                        detail = detail,
                        serverId = activeServer!!.id,
                        onPlayEpisode = { seasonEpisodes, epIndex ->
                            val queue = seasonEpisodes.map { ep ->
                                QueueItem(
                                    id = ep.id,
                                    title = "${detail.info.name} - ${ep.title}",
                                    subtitle = "الموسم ${ep.season} • الحلقة ${ep.episodeNum}",
                                    url = ep.streamUrl,
                                    logo = ep.logo.ifBlank { detail.info.logo },
                                    kind = ContentKind.SERIES,
                                    serverId = activeServer!!.id
                                )
                            }
                            PlayerActivity.launch(context, queue, epIndex, "${detail.info.name} (الحلقات)")
                        },
                        onDownloadEpisode = { ep ->
                            val title = "${detail.info.name}_S${ep.season}E${ep.episodeNum}"
                            vm.startDownload("ep_${ep.id}", title, ep.streamUrl, ep.logo.ifBlank { detail.info.logo }, ep.extension)
                            Toast.makeText(context, "بدأ تحميل: $title", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SeriesDetailContent(
    detail: SeriesDetail,
    serverId: Long,
    onPlayEpisode: (List<com.novaiptv.app.data.EpisodeItem>, Int) -> Unit,
    onDownloadEpisode: (com.novaiptv.app.data.EpisodeItem) -> Unit
) {
    val seasonKeys = detail.seasons.keys.toList()
    var selectedSeason by remember(detail) { mutableIntStateOf(seasonKeys.firstOrNull() ?: 1) }
    val episodes = detail.seasons[selectedSeason].orEmpty()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.82f)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (detail.info.logo.isNotBlank()) {
                AsyncImage(
                    model = detail.info.logo,
                    contentDescription = detail.info.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(64.dp, 90.dp).clip(RoundedCornerShape(10.dp))
                )
                Spacer(Modifier.width(12.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(detail.info.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (detail.info.plot.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(detail.info.plot, color = TextSecondary, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        if (seasonKeys.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(seasonKeys) { s ->
                    val active = s == selectedSeason
                    FilterChip(
                        selected = active,
                        onClick = { selectedSeason = s },
                        label = { Text("الموسم $s", fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AccentCyan,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        if (episodes.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                Text("لا توجد حلقات متاحة", color = TextSecondary)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(episodes) { idx, ep ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardElevated)
                            .clickable { onPlayEpisode(episodes, idx) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(AccentCyan.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("${ep.episodeNum}", color = AccentCyan, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(ep.title, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (ep.duration.isNotBlank()) {
                                Text(ep.duration, color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                        IconButton(onClick = { onDownloadEpisode(ep) }) {
                            Icon(Icons.Default.Download, contentDescription = "تحميل الحلقة", tint = AccentCyan)
                        }
                        IconButton(onClick = { onPlayEpisode(episodes, idx) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل", tint = TextPrimary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FavoritesAndHistoryScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val favorites by vm.favorites.collectAsState()
    val history by vm.history.collectAsState()
    var tabIndex by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = tabIndex,
            containerColor = CardDark,
            contentColor = AccentCyan
        ) {
            Tab(selected = tabIndex == 0, onClick = { tabIndex = 0 }, text = { Text("المفضلة (${favorites.size})") })
            Tab(selected = tabIndex == 1, onClick = { tabIndex = 1 }, text = { Text("السجل (${history.size})") })
        }

        if (tabIndex == 0) {
            if (favorites.isEmpty()) {
                EmptyOrErrorBox("قائمة المفضلة فارغة")
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(favorites, key = { _, it -> it.key }) { idx, fav ->
                        val kind = runCatching { ContentKind.valueOf(fav.kind) }.getOrDefault(ContentKind.LIVE)
                        val item = MediaItem(fav.itemId, fav.name, fav.logo, fav.categoryId, fav.categoryName, fav.streamUrl, kind, fav.extension)
                        LiveChannelListRow(
                            item = item,
                            isFavorite = true,
                            onClick = {
                                if (kind == ContentKind.SERIES) {
                                    vm.openSeriesDetail(item)
                                } else {
                                    val queue = favorites.map { f ->
                                        QueueItem(f.itemId, f.name, "المفضلة", f.streamUrl, f.logo, runCatching { ContentKind.valueOf(f.kind) }.getOrDefault(ContentKind.LIVE), f.serverId)
                                    }
                                    PlayerActivity.launch(context, queue, idx, "المفضلة")
                                }
                            },
                            onToggleFav = { vm.toggleFavorite(item, true) }
                        )
                    }
                }
            }
        } else {
            if (history.isEmpty()) {
                EmptyOrErrorBox("لا يوجد سجل مشاهدة بعد")
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(history, key = { _, it -> it.key }) { idx, h ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(CardDark)
                                .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                                .clickable {
                                    val queue = history.map {
                                        QueueItem(it.itemId, it.name, "سجل المشاهدة", it.streamUrl, it.logo, runCatching { ContentKind.valueOf(it.kind) }.getOrDefault(ContentKind.LIVE), it.serverId)
                                    }
                                    PlayerActivity.launch(context, queue, idx, "سجل المشاهدة")
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = AccentCyan)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(h.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (h.durationMs > 0) {
                                    val pct = ((h.positionMs * 100) / h.durationMs).coerceIn(0, 100)
                                    Text("تمت مشاهدة $pct%", color = TextSecondary, fontSize = 11.sp)
                                }
                            }
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = AccentCyan)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val downloads by vm.downloads.collectAsState()
    val storageBytes by vm.storageBytes.collectAsState()

    LaunchedEffect(downloads.size) {
        vm.refreshStorageUsage()
    }

    Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
        // Storage & Cleanup Header Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CardDark)
                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("مساحة التحميلات المستخدمة", color = TextSecondary, fontSize = 12.sp)
                Spacer(Modifier.height(2.dp))
                Text(formatBytes(storageBytes), color = AccentCyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            OutlinedButton(
                onClick = {
                    vm.cleanTempStorage { freed ->
                        Toast.makeText(
                            context,
                            if (freed > 0) "تم تنظيف ${formatBytes(freed)} من الملفات المؤقتة" else "لا توجد ملفات ناقصة أو مؤقتة",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan)
            ) {
                Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("تنظيف المؤقتة", fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(12.dp))

        if (downloads.isEmpty()) {
            EmptyOrErrorBox("لا توجد تحميلات حالياً.\nيمكنك تحميل الأفلام أو الحلقات بسرعة عالية حتى مع قفل الشاشة.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(downloads, key = { it.id }) { item ->
                    val isCompleted = item.state == "COMPLETED"
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(CardDark)
                            .border(1.dp, if (isCompleted) Color(0xFF1F3B2D) else BorderSubtle, RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0E131D)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (item.logo.isNotBlank()) {
                                    AsyncImage(
                                        model = item.logo,
                                        contentDescription = item.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(Icons.Default.Movie, contentDescription = null, tint = AccentCyan)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                if (isCompleted) {
                                    Text("مكتمل • ${formatBytes(item.totalBytes)}", color = Color(0xFF4ADE80), fontSize = 12.sp)
                                } else {
                                    val speedStr = if (item.speedBytesPerSec > 0) "${formatBytes(item.speedBytesPerSec)}/s" else "..."
                                    val sizeStr = if (item.totalBytes > 0) "${formatBytes(item.downloadedBytes)} / ${formatBytes(item.totalBytes)}" else formatBytes(item.downloadedBytes)
                                    Text("${item.progress}% • $sizeStr • $speedStr", color = AccentCyan, fontSize = 12.sp)
                                }
                            }

                            if (isCompleted) {
                                IconButton(onClick = {
                                    val completedQueue = downloads.filter { it.state == "COMPLETED" }.map { d ->
                                        QueueItem(d.id, d.title, "التحميلات", d.filePath, d.logo, ContentKind.MOVIE, 0L)
                                    }
                                    val startIdx = completedQueue.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
                                    PlayerActivity.launch(context, completedQueue, startIdx, "ملفاتي المحملة")
                                }) {
                                    Icon(Icons.Default.PlayCircleFilled, contentDescription = "تشغيل", tint = AccentCyan, modifier = Modifier.size(30.dp))
                                }
                                IconButton(onClick = { vm.deleteDownload(item) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = LiveRed)
                                }
                            } else {
                                // Interactive Cancel Button that immediately stops & deletes partial file!
                                FilledTonalButton(
                                    onClick = {
                                        vm.cancelDownload(item.id)
                                        Toast.makeText(context, "تم إلغاء التحميل وحذف الملف المؤقت", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = LiveRed.copy(alpha = 0.2f),
                                        contentColor = LiveRed
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("إلغاء", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        if (!isCompleted) {
                            Spacer(Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = { (item.progress / 100f).coerceIn(0f, 1f) },
                                color = AccentCyan,
                                trackColor = Color(0xFF232C3F),
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}
