package com.novaiptv.app.ui

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.novaiptv.app.Actions
import com.novaiptv.app.data.*
import kotlinx.coroutines.delay

private fun pct(d: DownloadEntity) = if (d.total > 0) (d.downloaded * 100 / d.total).toInt().coerceIn(0, 100) else 0

/* ───────────────────────── مكوّنات مشتركة ───────────────────────── */

@Composable
private fun Rail(title: String, items: List<Content>, favKeys: Set<String>, act: Actions, onMore: (() -> Unit)? = null) {
    Column {
        SectionTitle(title, onMore)
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items) { c -> PosterCard(c, Modifier.width(112.dp), fav = c.key in favKeys) { act.open(c) } }
        }
    }
}

@Composable
private fun Hero(items: List<Content>, act: Actions) {
    val state = rememberPagerState(pageCount = { items.size })
    LaunchedEffect(items.size) {
        while (items.size > 1) {
            delay(5000)
            state.animateScrollToPage((state.currentPage + 1) % items.size)
        }
    }
    Box(Modifier.fillMaxWidth().height(270.dp)) {
        HorizontalPager(state = state, modifier = Modifier.fillMaxSize()) { p ->
            val c = items[p]
            Box(Modifier.fillMaxSize().clickable { act.open(c) }) {
                AsyncImage(
                    model = c.poster, contentDescription = null, contentScale = ContentScale.Crop,
                    alignment = Alignment.TopCenter, modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Bg.copy(alpha = 0.55f), Bg))))
                Column(Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 26.dp)) {
                    Text(kindLabel(c.kind), color = Accent2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(c.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                        RatingBadge(c.rating)
                        if (c.group.isNotBlank()) Text("  " + c.group, color = TextDim, fontSize = 12.sp, maxLines = 1)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { act.open(c) }, colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("التفاصيل")
                    }
                }
            }
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            for (i in items.indices) {
                Box(
                    Modifier.size(if (i == state.currentPage) 18.dp else 6.dp, 6.dp).clip(CircleShape)
                        .background(if (i == state.currentPage) Accent2 else Color.White.copy(alpha = 0.35f))
                )
            }
        }
    }
}

/* ───────────────────────── الرئيسية ───────────────────────── */

@Composable
fun HomeScreen(vm: MainVM, act: Actions) {
    val cur by vm.current.collectAsState()
    val lists by vm.lists.collectAsState()
    val recent by vm.recent.collectAsState()
    val favs by vm.favorites.collectAsState()
    val favKeys by vm.favKeys.collectAsState()
    LaunchedEffect(cur?.id) { vm.ensure(Kind.MOVIE); vm.ensure(Kind.SERIES) }

    val cont = recent.filter { it.content.kind != Kind.LIVE && it.pos > 10_000 && (it.dur <= 0 || it.pos < it.dur - 20_000) }
    val watched = recent.take(20)
    val movies = lists[Kind.MOVIE]?.items?.take(30).orEmpty()
    val series = lists[Kind.SERIES]?.items?.take(30).orEmpty()
    val hero = remember(movies, series) { (movies.take(4) + series.take(3)).filter { !it.poster.isNullOrBlank() } }
    val st = lists[Kind.MOVIE]
    val homeErr = st?.error

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NOVA", style = TextStyle(brush = AccentBrush, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold))
                    Text(cur?.name.orEmpty(), color = TextDim, fontSize = 12.sp)
                }
                IconButton(onClick = { act.servers() }) { Icon(Icons.Rounded.Dns, null) }
            }
        }
        if (hero.isNotEmpty()) item { Hero(hero, act) }
        if (cont.isNotEmpty()) {
            item {
                Column {
                    SectionTitle("تابع المشاهدة")
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(cont) { h ->
                            PosterCard(h.content, Modifier.width(124.dp), progress = if (h.dur > 0) (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) else null) {
                                act.resume(h.content)
                            }
                        }
                    }
                }
            }
        }
        if (watched.isNotEmpty()) item { Rail("شوهد مؤخراً", watched.map { it.content }, favKeys, act) }
        if (favs.isNotEmpty()) item { Rail("المفضلة", favs, favKeys, act) }
        if (movies.isNotEmpty()) item { Rail("أفلام", movies, favKeys, act) }
        if (series.isNotEmpty()) item { Rail("مسلسلات", series, favKeys, act) }
        if (st?.loading == true && movies.isEmpty()) item {
            Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
        }
        if (homeErr != null && movies.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(homeErr, color = TextDim, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.ensure(Kind.MOVIE, true); vm.ensure(Kind.SERIES, true) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
            }
        }
    }
}

/* ───────────────────────── البث المباشر / الأفلام / المسلسلات ───────────────────────── */

@Composable
fun BrowseScreen(vm: MainVM, kind: Kind, title: String, act: Actions) {
    val cur by vm.current.collectAsState()
    val st = vm.lists.collectAsState().value[kind]
    val favKeys by vm.favKeys.collectAsState()
    LaunchedEffect(cur?.id) { vm.ensure(kind) }
    var query by rememberSaveable(kind.name) { mutableStateOf("") }
    var group by rememberSaveable(kind.name) { mutableStateOf(if (kind == Kind.LIVE) G_ALL else G_HOME) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title, cur?.name, { vm.ensure(kind, true) }, { act.servers() })
        SearchField(query) { query = it }
        val err = st?.error
        if (st == null || st.loading) {
            Loading()
        } else if (err != null) {
            ErrorBox(err) { vm.ensure(kind, true) }
        } else {
            val all = st.items
            val byGroup = remember(all) { all.groupBy { it.group } }
            val groups = remember(byGroup) {
                byGroup.entries.filter { it.key.isNotBlank() }.sortedByDescending { it.value.size }.map { it.key }
            }
            val options = remember(groups, kind) {
                buildList<Pair<String, String>> {
                    if (kind == Kind.LIVE) { add(G_ALL to "الكل"); add(G_FAV to "★ المفضلة") }
                    else { add(G_HOME to "الرئيسية"); add(G_ALL to "الكل") }
                    groups.forEach { add(it to it) }
                }
            }
            Pills(options, group) { group = it }

            val searching = query.isNotBlank()
            val railMode = kind != Kind.LIVE && group == G_HOME && !searching && groups.isNotEmpty()
            val filtered = remember(all, group, query, if (group == G_FAV) favKeys else null) {
                all.filter { c ->
                    val inGroup = when (group) {
                        G_ALL, G_HOME -> true
                        G_FAV -> c.key in favKeys
                        else -> c.group == group
                    }
                    inGroup && (query.isBlank() || c.title.contains(query, true))
                }
            }

            if (railMode) {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp)) {
                    items(groups.take(40)) { g ->
                        Rail(g, byGroup[g].orEmpty().take(20), favKeys, act, onMore = { group = g })
                    }
                }
            } else if (filtered.isEmpty()) {
                EmptyBox(if (group == G_FAV) "لا توجد قنوات مفضلة بعد" else "لا توجد نتائج")
            } else if (kind == Kind.LIVE) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(104.dp), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(filtered) { i, c ->
                        ChannelTile(c, c.key in favKeys, onFav = { vm.toggleFav(c) }) { act.play(filtered, i) }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(110.dp), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(filtered) { _, c -> PosterCard(c, fav = c.key in favKeys) { act.open(c) } }
                }
            }
        }
    }
}

/* ───────────────────────── مكتبتي ───────────────────────── */

@Composable
fun LibraryScreen(vm: MainVM, act: Actions) {
    val favs by vm.favorites.collectAsState()
    val recent by vm.recent.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("مكتبتي", null, null) { act.servers() }
        Pills(listOf("0" to "المفضلة", "1" to "السجل", "2" to "التحميلات"), tab.toString()) { tab = it.toInt() }
        when (tab) {
            0 -> if (favs.isEmpty()) EmptyBox("لا توجد عناصر في المفضلة بعد") else {
                val live = favs.filter { it.kind == Kind.LIVE }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(110.dp), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(favs) { _, c ->
                        PosterCard(c, fav = true) {
                            if (c.kind == Kind.LIVE) act.play(live, live.indexOfFirst { it.key == c.key }.coerceAtLeast(0)) else act.open(c)
                        }
                    }
                }
            }
            1 -> if (recent.isEmpty()) EmptyBox("لم تشاهد شيئاً بعد") else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp)) {
                item {
                    TextButton(onClick = { vm.clearHistory() }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("مسح السجل", color = Heart) }
                }
                items(recent) { h ->
                    Row(Modifier.fillMaxWidth().clickable { act.resume(h.content) }.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Poster(h.content.poster, h.content.title, Modifier.size(width = 56.dp, height = 78.dp), fit = h.content.kind == Kind.LIVE)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.content.display, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            if (h.content.kind != Kind.LIVE && h.dur > 0) {
                                Spacer(Modifier.height(6.dp))
                                LinearProgressIndicator(progress = { (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) }, color = Accent2, trackColor = Surface2, modifier = Modifier.fillMaxWidth().height(3.dp))
                            }
                        }
                        IconButton(onClick = { vm.removeHistory(h.content.key) }) { Icon(Icons.Rounded.Close, null, tint = TextDim) }
                    }
                }
            }
            else -> DownloadsTab(vm, act)
        }
    }
}

@Composable
private fun BatteryBanner() {
    val ctx = LocalContext.current
    fun ignoring() = ctx.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(ctx.packageName) ?: true
    var ok by remember { mutableStateOf(ignoring()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { ok = ignoring() }
    if (!ok) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                .background(Accent.copy(alpha = 0.18f)).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Info, null, tint = Accent2)
            Spacer(Modifier.width(10.dp))
            Text("لضمان استمرار التحميل والشاشة مقفولة اسمح للتطبيق بالعمل في الخلفية.", fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = {
                runCatching {
                    launcher.launch(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
                }
            }) { Text("السماح", color = Accent2) }
        }
    }
}

@Composable
private fun DownloadsTab(vm: MainVM, act: Actions) {
    val dls by vm.downloads.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    val done = remember(dls) {
        dls.filter { it.status == "DONE" }.map { contentFromJson(it.json) }
            .sortedWith(compareBy({ it.seriesId ?: it.title }, { it.season }, { it.episode }))
    }
    val used = dls.sumOf { it.downloaded }
    val active = dls.any { it.status == "QUEUED" || it.status == "RUNNING" }
    val stopped = dls.any { it.status == "PAUSED" || it.status == "FAILED" }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            Column {
                BatteryBanner()
                if (dls.isNotEmpty()) {
                    Text("${dls.size} عنصر · المساحة المستخدمة ${fmtBytes(used)}", color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    Row(Modifier.padding(horizontal = 8.dp)) {
                        if (active) TextButton(onClick = { vm.pauseAllDownloads() }) { Icon(Icons.Rounded.Pause, null); Spacer(Modifier.width(4.dp)); Text("إيقاف الكل") }
                        if (stopped) TextButton(onClick = { vm.resumeAllDownloads() }) { Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("استئناف الكل") }
                        TextButton(onClick = { confirmClear = true }) { Icon(Icons.Rounded.Delete, null, tint = Heart); Spacer(Modifier.width(4.dp)); Text("حذف الكل", color = Heart) }
                    }
                }
                Text("سرعة التحميل (عدد الاتصالات المتوازية)", color = TextDim, fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp, top = 6.dp))
                Pills(listOf("1", "2", "4", "8").map { it to "×$it" }, vm.dlConn.toString()) { vm.setDlConn(it.toInt()) }
                if (dls.isEmpty()) Text("لا توجد تحميلات. افتح فيلماً أو مسلسلاً واضغط تحميل.", color = TextDim, modifier = Modifier.padding(24.dp))
            }
        }
        items(dls) { d ->
            val c = contentFromJson(d.json)
            Row(
                Modifier.fillMaxWidth().clickable(enabled = d.status == "DONE") {
                    act.play(done, done.indexOfFirst { it.key == c.key }.coerceAtLeast(0))
                }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Poster(c.poster, c.title, Modifier.size(width = 56.dp, height = 78.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.display, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                    Spacer(Modifier.height(4.dp))
                    when (d.status) {
                        "DONE" -> Text("جاهز بدون إنترنت · ${fmtBytes(d.downloaded)}", color = Accent2, fontSize = 12.sp)
                        "FAILED" -> Text(d.error.ifBlank { "فشل التحميل" }, color = Heart, fontSize = 12.sp, maxLines = 2)
                        "QUEUED" -> Text("في الانتظار…", color = TextDim, fontSize = 12.sp)
                        "PAUSED" -> Text("متوقف مؤقتاً · ${pct(d)}% (${fmtBytes(d.downloaded)})", color = TextDim, fontSize = 12.sp)
                        else -> {
                            Text("${pct(d)}% · ${fmtBytes(d.downloaded)} / ${fmtBytes(d.total)}", color = TextDim, fontSize = 12.sp)
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(progress = { pct(d) / 100f }, color = Accent, trackColor = Surface2, modifier = Modifier.fillMaxWidth().height(3.dp))
                        }
                    }
                }
                when (d.status) {
                    "RUNNING", "QUEUED" -> IconButton(onClick = { vm.pauseDownload(d) }) { Icon(Icons.Rounded.Pause, null) }
                    "PAUSED" -> IconButton(onClick = { vm.resumeDownload(d) }) { Icon(Icons.Rounded.PlayArrow, null) }
                    "FAILED" -> IconButton(onClick = { vm.resumeDownload(d) }) { Icon(Icons.Rounded.Refresh, null) }
                    else -> {}
                }
                // إلغاء/حذف: يحذف الملف (الكامل أو الجزئي) فوراً ويحرر المساحة
                IconButton(onClick = { vm.removeDownload(d) }) {
                    Icon(if (d.status == "DONE") Icons.Rounded.Delete else Icons.Rounded.Close, null, tint = Heart)
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("حذف كل التحميلات؟") },
            text = { Text("سيتم إلغاء التحميلات الجارية وحذف كل الملفات وتحرير المساحة.") },
            confirmButton = { TextButton(onClick = { vm.clearDownloads(); confirmClear = false }) { Text("حذف", color = Heart) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("إلغاء") } }
        )
    }
}

/* ───────────────────────── التفاصيل: فيلم أو مسلسل ───────────────────────── */

@Composable
fun DetailScreen(vm: MainVM, act: Actions, onBack: () -> Unit) {
    val c = vm.detail
    if (c == null) { LaunchedEffect(Unit) { onBack() }; return }
    val eps by vm.episodes.collectAsState()
    val favKeys by vm.favKeys.collectAsState()
    val dls by vm.downloads.collectAsState()
    val recent by vm.recent.collectAsState()
    val isSeries = c.kind == Kind.SERIES
    val dlMap = remember(dls) { dls.associateBy { it.contentKey } }
    val hMap = remember(recent) { recent.associateBy { it.content.key } }
    val list = eps.items
    val seasons = remember(list) { list.map { it.season }.distinct().sorted() }
    var season by rememberSaveable(c.key) { mutableIntStateOf(-1) }
    val curSeason = if (season in seasons) season else (seasons.firstOrNull() ?: 0)
    val inSeason = remember(list, curSeason) { list.filter { it.season == curSeason } }

    LaunchedEffect(list) {
        val p = vm.pendingPlay
        if (p != null && list.isNotEmpty()) {
            vm.pendingPlay = null
            val i = list.indexOfFirst { it.key == p }
            if (i >= 0) act.play(list, i)
        }
    }

    val lastEp = recent.firstOrNull { it.content.kind == Kind.EPISODE && it.content.seriesId == c.seriesId }?.content

    LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(290.dp)) {
                AsyncImage(
                    model = c.poster, contentDescription = null, contentScale = ContentScale.Crop,
                    alignment = Alignment.TopCenter, alpha = 0.55f, modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Bg))))
                IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(4.dp)) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, null)
                }
                Row(Modifier.align(Alignment.BottomStart).padding(16.dp), verticalAlignment = Alignment.Bottom) {
                    Poster(c.poster, c.title, Modifier.width(110.dp).aspectRatio(0.68f), radius = 14)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(c.title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RatingBadge(c.rating)
                            if (c.group.isNotBlank()) Text("  " + c.group, color = TextDim, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
        if (c.plot.isNotBlank()) item {
            Text(c.plot, color = TextDim, fontSize = 13.sp, maxLines = 6, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 16.dp))
        }
        item {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        if (!isSeries) act.play(listOf(c), 0)
                        else if (list.isNotEmpty()) {
                            val i = if (lastEp != null) list.indexOfFirst { it.key == lastEp.key }.coerceAtLeast(0) else 0
                            act.play(list, i)
                        }
                    },
                    enabled = !isSeries || list.isNotEmpty(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(4.dp))
                    Text(if (isSeries && lastEp != null || !isSeries && hMap[c.key] != null) "استكمال" else "تشغيل")
                }
                OutlinedButton(onClick = { vm.toggleFav(c) }, shape = RoundedCornerShape(12.dp)) {
                    val fav = c.key in favKeys
                    Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (fav) Heart else Color.White)
                }
                if (!isSeries) {
                    val d = dlMap[c.key]
                    OutlinedButton(
                        shape = RoundedCornerShape(12.dp),
                        onClick = {
                            when (d?.status) {
                                null -> vm.download(listOf(c))
                                "QUEUED", "RUNNING" -> vm.removeDownload(d!!)
                                "PAUSED", "FAILED" -> vm.resumeDownload(d!!)
                                else -> {}
                            }
                        }
                    ) {
                        Icon(
                            when (d?.status) { "DONE" -> Icons.Rounded.DownloadDone; "QUEUED", "RUNNING" -> Icons.Rounded.Close; else -> Icons.Rounded.Download },
                            null
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            when (d?.status) {
                                null -> "تحميل"
                                "DONE" -> "تم التحميل"
                                "FAILED" -> "إعادة"
                                "PAUSED" -> "استئناف"
                                else -> "إلغاء (${pct(d!!)}%)"
                            }
                        )
                    }
                }
            }
        }
        if (isSeries) {
            when {
                eps.loading -> item { Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) } }
                eps.error != null -> item {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(eps.error!!, color = TextDim, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { vm.loadEpisodes(c) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
                    }
                }
                list.isEmpty() -> item { Text("لا توجد حلقات", color = TextDim, modifier = Modifier.padding(16.dp)) }
                else -> {
                    item { Pills(seasons.map { it.toString() to "الموسم $it" }, curSeason.toString()) { season = it.toInt() } }
                    item {
                        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            TextButton(onClick = { vm.download(inSeason) }) { Icon(Icons.Rounded.Download, null); Spacer(Modifier.width(4.dp)); Text("تحميل الموسم") }
                            TextButton(onClick = { vm.download(list) }) { Text("تحميل الكل") }
                            if (list.any { dlMap[it.key]?.status.let { s -> s != null && s != "DONE" } })
                                TextButton(onClick = { vm.cancelDownloads(list.map { it.key }.toSet()) }) { Text("إلغاء الجارية", color = Heart) }
                        }
                    }
                    items(inSeason) { e ->
                        val d = dlMap[e.key]
                        val h = hMap[e.key]
                        Row(
                            Modifier.fillMaxWidth().clickable { act.play(list, list.indexOfFirst { it.key == e.key }.coerceAtLeast(0)) }
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Poster(e.poster, e.title, Modifier.size(width = 100.dp, height = 58.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("${e.episode}. ${e.title}", maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                if (h != null && h.dur > 0) {
                                    Spacer(Modifier.height(5.dp))
                                    LinearProgressIndicator(progress = { (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) }, color = Accent2, trackColor = Surface2, modifier = Modifier.fillMaxWidth().height(3.dp))
                                }
                            }
                            when (d?.status) {
                                null -> IconButton(onClick = { vm.download(listOf(e)) }) { Icon(Icons.Rounded.Download, null, tint = TextDim) }
                                "DONE" -> Icon(Icons.Rounded.DownloadDone, null, tint = Accent2, modifier = Modifier.padding(12.dp))
                                "FAILED", "PAUSED" -> IconButton(onClick = { vm.resumeDownload(d!!) }) { Icon(Icons.Rounded.Refresh, null, tint = Heart) }
                                else -> Box(Modifier.size(48.dp).clip(CircleShape).clickable { vm.removeDownload(d!!) }, contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(progress = { pct(d!!) / 100f }, modifier = Modifier.size(28.dp), strokeWidth = 2.dp, color = Accent)
                                    Icon(Icons.Rounded.Close, null, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
