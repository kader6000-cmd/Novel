package com.novaiptv.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaiptv.app.Actions
import com.novaiptv.app.data.*

private fun pct(d: DownloadEntity) = if (d.total > 0) (d.downloaded * 100 / d.total).toInt().coerceIn(0, 100) else 0

/* ───────────────────────── الرئيسية ───────────────────────── */

@Composable
fun HomeScreen(vm: MainVM, act: Actions) {
    val cur by vm.current.collectAsState()
    val lists by vm.lists.collectAsState()
    val recent by vm.recent.collectAsState()
    val favs by vm.favorites.collectAsState()
    LaunchedEffect(cur?.id) { vm.ensure(Kind.MOVIE); vm.ensure(Kind.SERIES) }

    val cont = recent.filter { it.content.kind != Kind.LIVE && it.pos > 10_000 && (it.dur <= 0 || it.pos < it.dur - 20_000) }
    val watched = recent.take(20)
    val movies = lists[Kind.MOVIE]?.items?.take(24).orEmpty()
    val series = lists[Kind.SERIES]?.items?.take(24).orEmpty()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NOVA", style = TextStyle(brush = AccentBrush, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold))
                    Text(cur?.name.orEmpty(), color = TextDim, fontSize = 12.sp)
                }
                IconButton(onClick = { act.servers() }) { Icon(Icons.Rounded.Dns, null) }
            }
        }
        if (cont.isNotEmpty()) {
            item { SectionTitle("تابع المشاهدة") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(cont) { h ->
                        PosterCard(h.content, Modifier.width(120.dp), progress = if (h.dur > 0) (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) else null) {
                            act.resume(h.content)
                        }
                    }
                }
            }
        }
        if (watched.isNotEmpty()) {
            item { SectionTitle("شوهد مؤخراً") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(watched) { h -> PosterCard(h.content, Modifier.width(110.dp)) { act.resume(h.content) } }
                }
            }
        }
        if (favs.isNotEmpty()) {
            item { SectionTitle("المفضلة") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(favs) { c -> PosterCard(c, Modifier.width(110.dp), fav = true) { act.open(c) } }
                }
            }
        }
        if (movies.isNotEmpty()) {
            item { SectionTitle("أفلام") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(movies) { c -> PosterCard(c, Modifier.width(110.dp)) { act.open(c) } }
                }
            }
        }
        if (series.isNotEmpty()) {
            item { SectionTitle("مسلسلات") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(series) { c -> PosterCard(c, Modifier.width(110.dp)) { act.open(c) } }
                }
            }
        }
        val st = lists[Kind.MOVIE]
        val homeErr = st?.error
        if (st?.loading == true && movies.isEmpty()) item { Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) } }
        if (homeErr != null && movies.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(homeErr, color = TextDim, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.ensure(Kind.MOVIE, true); vm.ensure(Kind.SERIES, true) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
            }
        }
    }
}

/* ───────────────────────── البث المباشر / الأفلام / المسلسلات ───────────────────────── */

@Composable
fun BrowseScreen(vm: MainVM, kind: Kind, title: String, act: Actions) {
    val cur by vm.current.collectAsState()
    val st = vm.lists.collectAsState().value[kind]
    val favKeys by vm.favKeys.collectAsState()
    LaunchedEffect(cur?.id) { vm.ensure(kind) }
    var query by rememberSaveable(kind.name) { mutableStateOf("") }
    var group by rememberSaveable(kind.name) { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title, cur?.name, { vm.ensure(kind, true) }, { act.servers() })
        SearchField(query) { query = it }
        val err = st?.error
        if (st == null || st.loading) Loading()
        else if (err != null) ErrorBox(err) { vm.ensure(kind, true) }
        else {
            run {
                val all = st.items
                val groups = remember(all) {
                    all.groupingBy { it.group }.eachCount().entries.filter { it.key.isNotBlank() }
                        .sortedByDescending { it.value }.map { it.key }
                }
                if (groups.isNotEmpty()) GroupChips(groups, group) { group = it }
                val filtered = remember(all, group, query) {
                    all.filter { (group == null || it.group == group) && (query.isBlank() || it.title.contains(query, true)) }
                }
                if (filtered.isEmpty()) EmptyBox("لا توجد نتائج")
                else if (kind == Kind.LIVE) {
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 6.dp, bottom = 12.dp)) {
                        itemsIndexed(filtered) { i, c ->
                            val fav = c.key in favKeys
                            Row(
                                Modifier.fillMaxWidth().clickable { act.play(filtered, i) }.padding(horizontal = 16.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Poster(c.poster, c.title, Modifier.size(52.dp), fit = true)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
                                    if (c.group.isNotBlank()) Text(c.group, maxLines = 1, color = TextDim, fontSize = 12.sp)
                                }
                                IconButton(onClick = { vm.toggleFav(c) }) {
                                    Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (fav) Heart else TextDim)
                                }
                            }
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(110.dp), contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filtered) { c -> PosterCard(c, fav = c.key in favKeys) { act.open(c) } }
                    }
                }
            }
        }
    }
}

/* ───────────────────────── مكتبتي: المفضلة / السجل / التحميلات ───────────────────────── */

@Composable
fun LibraryScreen(vm: MainVM, act: Actions) {
    val favs by vm.favorites.collectAsState()
    val recent by vm.recent.collectAsState()
    val dls by vm.downloads.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("مكتبتي", null, null) { act.servers() }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("المفضلة", "السجل", "التحميلات").forEachIndexed { i, t ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t) })
            }
        }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> if (favs.isEmpty()) EmptyBox("لا توجد عناصر في المفضلة بعد") else {
                val live = favs.filter { it.kind == Kind.LIVE }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(110.dp), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(favs) { c ->
                        PosterCard(c, fav = true) {
                            if (c.kind == Kind.LIVE) act.play(live, live.indexOf(c).coerceAtLeast(0)) else act.open(c)
                        }
                    }
                }
            }
            1 -> if (recent.isEmpty()) EmptyBox("لم تشاهد شيئاً بعد") else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp)) {
                item {
                    TextButton(onClick = { vm.clearHistory() }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("مسح السجل", color = Heart) }
                }
                items(recent) { h ->
                    Row(Modifier.fillMaxWidth().clickable { act.resume(h.content) }.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Poster(h.content.poster, h.content.title, Modifier.size(width = 56.dp, height = 78.dp), fit = h.content.kind == Kind.LIVE)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.content.display, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            if (h.content.kind != Kind.LIVE && h.dur > 0) {
                                Spacer(Modifier.height(6.dp))
                                LinearProgressIndicator(progress = { (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) }, color = Accent2, trackColor = Surface2, modifier = Modifier.fillMaxWidth().height(3.dp))
                            }
                        }
                        IconButton(onClick = { vm.removeHistory(h.content.key) }) { Icon(Icons.Rounded.Close, null, tint = TextDim) }
                    }
                }
            }
            else -> if (dls.isEmpty()) EmptyBox("لا توجد تحميلات. افتح فيلماً أو مسلسلاً واضغط تحميل") else {
                val done = dls.filter { it.status == "DONE" }
                    .map { contentFromJson(it.json) }
                    .sortedWith(compareBy({ it.seriesId ?: it.title }, { it.season }, { it.episode }))
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp)) {
                    items(dls) { d ->
                        val c = contentFromJson(d.json)
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = d.status == "DONE") {
                                act.play(done, done.indexOfFirst { it.key == c.key }.coerceAtLeast(0))
                            }.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Poster(c.poster, c.title, Modifier.size(width = 56.dp, height = 78.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.display, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                Spacer(Modifier.height(4.dp))
                                when (d.status) {
                                    "DONE" -> Text("جاهز للمشاهدة بدون إنترنت", color = Accent2, fontSize = 12.sp)
                                    "FAILED" -> Text(d.error.ifBlank { "فشل التحميل" }, color = Heart, fontSize = 12.sp, maxLines = 2)
                                    "QUEUED" -> Text("في الانتظار…", color = TextDim, fontSize = 12.sp)
                                    else -> {
                                        Text("جارٍ التحميل ${pct(d)}%", color = TextDim, fontSize = 12.sp)
                                        Spacer(Modifier.height(4.dp))
                                        LinearProgressIndicator(progress = { pct(d) / 100f }, color = Accent, trackColor = Surface2, modifier = Modifier.fillMaxWidth().height(3.dp))
                                    }
                                }
                            }
                            if (d.status == "FAILED") IconButton(onClick = { vm.retryDownload(d) }) { Icon(Icons.Rounded.Refresh, null) }
                            IconButton(onClick = { vm.removeDownload(d) }) { Icon(Icons.Rounded.Delete, null, tint = TextDim) }
                        }
                    }
                }
            }
        }
    }
}

/* ───────────────────────── التفاصيل: فيلم أو مسلسل ───────────────────────── */

@Composable
fun DetailScreen(vm: MainVM, act: Actions, onBack: () -> Unit) {
    val c = vm.detail
    if (c == null) { LaunchedEffect(Unit) { onBack() }; return }
    val eps by vm.episodes.collectAsState()
    val favKeys by vm.favKeys.collectAsState()
    val dls by vm.downloads.collectAsState()
    val recent by vm.recent.collectAsState()
    val isSeries = c.kind == Kind.SERIES
    val dlMap = remember(dls) { dls.associateBy { it.contentKey } }
    val hMap = remember(recent) { recent.associateBy { it.content.key } }
    val list = eps.items
    val seasons = remember(list) { list.map { it.season }.distinct().sorted() }
    var season by rememberSaveable(c.key) { mutableIntStateOf(-1) }
    val curSeason = if (season in seasons) season else (seasons.firstOrNull() ?: 0)
    val inSeason = remember(list, curSeason) { list.filter { it.season == curSeason } }

    // تشغيل تلقائي عند الاستكمال من "تابع المشاهدة"
    LaunchedEffect(list) {
        val p = vm.pendingPlay
        if (p != null && list.isNotEmpty()) {
            vm.pendingPlay = null
            val i = list.indexOfFirst { it.key == p }
            if (i >= 0) act.play(list, i)
        }
    }

    val lastEp = recent.firstOrNull { it.content.kind == Kind.EPISODE && it.content.seriesId == c.seriesId }?.content

    LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
          Column {
            IconButton(onClick = onBack, modifier = Modifier.padding(4.dp)) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Row(Modifier.padding(horizontal = 16.dp)) {
                Poster(c.poster, c.title, Modifier.width(120.dp).aspectRatio(0.68f))
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(c.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (c.group.isNotBlank()) Text(c.group, color = TextDim, fontSize = 12.sp)
                    if (c.rating.isNotBlank() && c.rating != "0") Text("★ ${c.rating}", color = Accent2, fontSize = 13.sp)
                    if (c.plot.isNotBlank()) Text(c.plot, color = TextDim, fontSize = 13.sp, maxLines = 7, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                }
            }
          }
        }
        item {
            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = {
                        if (!isSeries) act.play(listOf(c), 0)
                        else if (list.isNotEmpty()) {
                            val i = if (lastEp != null) list.indexOfFirst { it.key == lastEp.key }.coerceAtLeast(0) else 0
                            act.play(list, i)
                        }
                    },
                    enabled = !isSeries || list.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(4.dp))
                    Text(if (isSeries && lastEp != null || !isSeries && hMap[c.key] != null) "استكمال" else "تشغيل")
                }
                OutlinedButton(onClick = { vm.toggleFav(c) }) {
                    val fav = c.key in favKeys
                    Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null, tint = if (fav) Heart else Color.White)
                }
                if (!isSeries) {
                    val d = dlMap[c.key]
                    OutlinedButton(onClick = { if (d == null) vm.download(listOf(c)) else if (d.status == "FAILED") vm.retryDownload(d) }) {
                        Icon(if (d?.status == "DONE") Icons.Rounded.DownloadDone else Icons.Rounded.Download, null)
                        Spacer(Modifier.width(4.dp))
                        Text(
                            when (d?.status) {
                                null -> "تحميل"; "DONE" -> "تم التحميل"; "FAILED" -> "إعادة"
                                "QUEUED" -> "في الانتظار"; else -> "${pct(d!!)}%"
                            }
                        )
                    }
                }
            }
        }
        if (isSeries) {
            when {
                eps.loading -> item { Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) } }
                eps.error != null -> item { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(eps.error!!, color = TextDim, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { vm.loadEpisodes(c) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("إعادة المحاولة") }
                } }
                list.isEmpty() -> item { Text("لا توجد حلقات", color = TextDim, modifier = Modifier.padding(16.dp)) }
                else -> {
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(seasons) { s -> FilterChip(selected = s == curSeason, onClick = { season = s }, label = { Text("الموسم $s") }) }
                        }
                    }
                    item {
                        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { vm.download(inSeason) }) { Icon(Icons.Rounded.Download, null); Spacer(Modifier.width(4.dp)); Text("تحميل الموسم") }
                            TextButton(onClick = { vm.download(list) }) { Text("تحميل الكل") }
                        }
                    }
                    items(inSeason) { e ->
                        val d = dlMap[e.key]
                        val h = hMap[e.key]
                        Row(
                            Modifier.fillMaxWidth().clickable { act.play(list, list.indexOfFirst { it.key == e.key }.coerceAtLeast(0)) }
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Poster(e.poster, e.title, Modifier.size(width = 96.dp, height = 56.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("${e.episode}. ${e.title}", maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                if (h != null && h.dur > 0) {
                                    Spacer(Modifier.height(5.dp))
                                    LinearProgressIndicator(progress = { (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) }, color = Accent2, trackColor = Surface2, modifier = Modifier.fillMaxWidth().height(3.dp))
                                }
                            }
                            when (d?.status) {
                                null -> IconButton(onClick = { vm.download(listOf(e)) }) { Icon(Icons.Rounded.Download, null, tint = TextDim) }
                                "DONE" -> Icon(Icons.Rounded.DownloadDone, null, tint = Accent2, modifier = Modifier.padding(12.dp))
                                "FAILED" -> IconButton(onClick = { vm.retryDownload(d!!) }) { Icon(Icons.Rounded.Refresh, null, tint = Heart) }
                                else -> CircularProgressIndicator(progress = { pct(d!!) / 100f }, modifier = Modifier.padding(12.dp).size(22.dp), strokeWidth = 2.dp, color = Accent)
                            }
                        }
                    }
                }
            }
        }
    }
}
