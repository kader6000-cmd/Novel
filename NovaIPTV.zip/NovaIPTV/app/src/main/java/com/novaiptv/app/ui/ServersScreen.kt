package com.novaiptv.app.ui

import android.os.SystemClock
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaiptv.app.data.HttpClient
import com.novaiptv.app.data.ServerType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.util.concurrent.TimeUnit

@Composable
fun ServersScreen(vm: MainViewModel, onServerSelected: () -> Unit) {
    val context = LocalContext.current
    val servers by vm.servers.collectAsState()
    val accountInfo by vm.accountInfo.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Speed test results: serverId -> response time in ms (-1 = unreachable).
    var speedResults by remember { mutableStateOf<Map<Long, Long>>(emptyMap()) }
    var testing by remember { mutableStateOf(false) }
    val fastestServerId = remember(speedResults) {
        speedResults.entries.filter { it.value >= 0 }.minByOrNull { it.value }?.key
    }

    fun runSpeedTest() {
        val list = servers
        if (testing || list.isEmpty()) return
        testing = true
        speedResults = emptyMap()
        scope.launch {
            val results = list.map { srv ->
                async(Dispatchers.IO) { srv.id to measureServerMs(srv.host) }
            }.awaitAll().toMap()
            speedResults = results
            testing = false
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("إدارة السيرفرات", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("إضافة سيرفر", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(12.dp))

        OutlinedButton(
            onClick = { runSpeedTest() },
            enabled = !testing && servers.isNotEmpty(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (testing) {
                CircularProgressIndicator(color = AccentCyan, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            } else {
                Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(6.dp))
            Text(
                if (testing) "جاري قياس سرعة السيرفرات..." else "اختبار سرعة السيرفرات",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }

        Spacer(Modifier.height(14.dp))

        if (servers.isEmpty()) {
            EmptyOrErrorBox("لم تقم بإضافة أي سيرفر بعد.\nاضغط على (إضافة سيرفر) لإدخال بيانات Xtream أو M3U أو Stalker.", "إضافة سيرفر الآن") {
                showAddDialog = true
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(servers, key = { it.id }) { srv ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (srv.isActive) AccentCyan.copy(alpha = 0.13f) else CardDark)
                            .border(
                                width = if (srv.isActive) 1.5.dp else 1.dp,
                                color = if (srv.isActive) AccentCyan else BorderSubtle,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                vm.activateServer(srv)
                                Toast.makeText(context, "تم تفعيل: ${srv.name}", Toast.LENGTH_SHORT).show()
                                onServerSelected()
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Dns,
                            contentDescription = null,
                            tint = if (srv.isActive) AccentCyan else TextSecondary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(srv.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${srv.type} • ${srv.host}", color = TextSecondary, fontSize = 12.sp, maxLines = 1)
                            if (testing && !speedResults.containsKey(srv.id)) {
                                Spacer(Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(color = AccentCyan, modifier = Modifier.size(12.dp), strokeWidth = 2.dp)
                                    Spacer(Modifier.width(6.dp))
                                    Text("جاري القياس...", color = TextSecondary, fontSize = 11.sp)
                                }
                            }
                            speedResults[srv.id]?.let { ms ->
                                Spacer(Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (ms >= 0) {
                                        Text(
                                            "$ms ms",
                                            color = if (srv.id == fastestServerId) Color(0xFF4ADE80) else TextSecondary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (srv.id == fastestServerId) {
                                            Spacer(Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = AccentCyan.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    "الأسرع ⚡",
                                                    color = AccentCyan,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    } else {
                                        Text("تعذّر الوصول للسيرفر", color = LiveRed, fontSize = 11.sp)
                                    }
                                }
                            }
                            if (srv.isActive) {
                                Text("السيرفر النشط حالياً", color = AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                accountInfo?.let { info ->
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = "الحالة: ${info.status} • الانتهاء: ${info.expDateFormatted} • الأجهزة: ${info.activeCons}/${info.maxConnections}",
                                        color = Color(0xFF4ADE80),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                        IconButton(onClick = { vm.deleteServer(srv) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = LiveRed)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddServerDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, type, host, user, pass, mac ->
                vm.addServer(name, type, host, user, pass, mac)
                showAddDialog = false
                Toast.makeText(context, "تمت إضافة السيرفر بنجاح", Toast.LENGTH_SHORT).show()
                onServerSelected()
            }
        )
    }
}

@Composable
private fun AddServerDialog(
    onDismiss: () -> Unit,
    onSave: (String, ServerType, String, String, String, String) -> Unit
) {
    var selectedType by remember { mutableStateOf(ServerType.XTREAM) }
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardDark,
        title = { Text("إضافة سيرفر جديد", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ServerType.entries.forEach { t ->
                        FilterChip(
                            selected = selectedType == t,
                            onClick = { selectedType = t },
                            label = { Text(t.name, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentCyan,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم السيرفر") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it },
                    label = {
                        Text(
                            when (selectedType) {
                                ServerType.XTREAM -> "الرابط (http://host:port)"
                                ServerType.M3U -> "رابط ملف M3U / M3U8"
                                ServerType.STALKER -> "رابط البورتال (http://.../c)"
                            }
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (selectedType == ServerType.XTREAM) {
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("اسم المستخدم") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("كلمة المرور") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (selectedType == ServerType.STALKER) {
                    OutlinedTextField(
                        value = mac,
                        onValueChange = { mac = it },
                        label = { Text("عنوان MAC (00:1A:79:...)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (host.isNotBlank()) {
                        onSave(name, selectedType, host, username, password, mac)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
            ) {
                Text("حفظ وتفعيل", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء", color = TextSecondary) }
        }
    )
}

/**
 * Measures a server's response time with a tiny 1-byte Range GET (more
 * reliable than HEAD on IPTV servers). Returns milliseconds, or -1 when
 * the host cannot be reached within 5 seconds. Read-only: it never
 * changes the active server.
 */
private suspend fun measureServerMs(host: String): Long = withContext(Dispatchers.IO) {
    val base = host.trim().trimEnd('/')
    val url = if (base.endsWith(".m3u") || base.endsWith(".m3u8")) base else "$base/"
    return@withContext try {
        val client = HttpClient.client.newBuilder()
            .callTimeout(5, TimeUnit.SECONDS)
            .build()
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", HttpClient.USER_AGENT)
            .header("Range", "bytes=0-0")
            .get()
            .build()
        val start = SystemClock.elapsedRealtime()
        client.newCall(req).execute().use { resp ->
            resp.body?.close()
            SystemClock.elapsedRealtime() - start
        }
    } catch (_: Exception) {
        -1L
    }
}
