package com.novaiptv.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaiptv.app.data.ServerType

@Composable
fun ServersScreen(vm: MainViewModel, onServerSelected: () -> Unit) {
    val context = LocalContext.current
    val servers by vm.servers.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("إدارة السيرفرات", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("إضافة سيرفر", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(14.dp))

        if (servers.isEmpty()) {
            EmptyOrErrorBox("لم تقم بإضافة أي سيرفر بعد.\nاضغط على (إضافة سيرفر) لإدخال بيانات Xtream أو M3U أو Stalker.", "إضافة سيرفر الآن") {
                showAddDialog = true
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(servers, key = { it.id }) { srv ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (srv.isActive) Color(0x2200E5FF) else CardDark)
                            .border(
                                width = if (srv.isActive) 1.5.dp else 1.dp,
                                color = if (srv.isActive) AccentCyan else BorderSubtle,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                vm.activateServer(srv)
                                Toast.makeText(context, "تم تفعيل: ${srv.name}", Toast.LENGTH_SHORT).show()
                                onServerSelected()
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Dns,
                            contentDescription = null,
                            tint = if (srv.isActive) AccentCyan else TextSecondary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(srv.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("${srv.type} • ${srv.host}", color = TextSecondary, fontSize = 12.sp, maxLines = 1)
                            if (srv.isActive) {
                                Text("السيرفر النشط حالياً", color = AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        IconButton(onClick = { vm.deleteServer(srv) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = LiveRed)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddServerDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, type, host, user, pass, mac ->
                vm.addServer(name, type, host, user, pass, mac)
                showAddDialog = false
                Toast.makeText(context, "تمت إضافة السيرفر بنجاح", Toast.LENGTH_SHORT).show()
                onServerSelected()
            }
        )
    }
}

@Composable
private fun AddServerDialog(
    onDismiss: () -> Unit,
    onSave: (String, ServerType, String, String, String, String) -> Unit
) {
    var selectedType by remember { mutableStateOf(ServerType.XTREAM) }
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardDark,
        title = { Text("إضافة سيرفر جديد", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ServerType.entries.forEach { t ->
                        FilterChip(
                            selected = selectedType == t,
                            onClick = { selectedType = t },
                            label = { Text(t.name, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentCyan,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم السيرفر") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it },
                    label = {
                        Text(
                            when (selectedType) {
                                ServerType.XTREAM -> "الرابط (http://host:port)"
                                ServerType.M3U -> "رابط ملف M3U / M3U8"
                                ServerType.STALKER -> "رابط البورتال (http://.../c)"
                            }
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (selectedType == ServerType.XTREAM) {
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("اسم المستخدم") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("كلمة المرور") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else if (selectedType == ServerType.STALKER) {
                    OutlinedTextField(
                        value = mac,
                        onValueChange = { mac = it },
                        label = { Text("عنوان MAC (00:1A:79:...)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (host.isNotBlank()) {
                        onSave(name, selectedType, host, username, password, mac)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black)
            ) {
                Text("حفظ وتفعيل", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء", color = TextSecondary) }
        }
    )
}
