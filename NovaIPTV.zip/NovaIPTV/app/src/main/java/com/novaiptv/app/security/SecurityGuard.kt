package com.novaiptv.app.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * Runtime integrity & anti-tampering guard for Google Play release builds.
 * Before publishing to Google Play, paste your Google Play App Signing SHA-256
 * fingerprint into EXPECTED_RELEASE_SHA256.
 */
object SecurityGuard {

    // Leave empty during development/CI; set your Play App Signing SHA-256 before release
    private const val EXPECTED_RELEASE_SHA256 = ""

    fun getCurrentSignatureSha256(context: Context): String {
        return try {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val signingInfo = info.signingInfo
                if (signingInfo == null) emptyArray()
                else if (signingInfo.hasMultipleSigners()) signingInfo.apkContentsSigners
                else signingInfo.signingCertificateHistory
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
            }
            val certBytes = signatures.firstOrNull()?.toByteArray() ?: return ""
            val digest = MessageDigest.getInstance("SHA-256").digest(certBytes)
            digest.joinToString(":") { "%02X".format(it) }
        } catch (_: Exception) {
            ""
        }
    }

    fun isSignatureValid(context: Context): Boolean {
        if (EXPECTED_RELEASE_SHA256.isBlank()) return true
        val current = getCurrentSignatureSha256(context)
        return current.equals(EXPECTED_RELEASE_SHA256, ignoreCase = true)
    }

    fun isInstalledFromPlayStore(context: Context): Boolean {
        return try {
            val installer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.packageManager.getInstallSourceInfo(context.packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getInstallerPackageName(context.packageName)
            }
            installer == "com.android.vending"
        } catch (_: Exception) {
            false
        }
    }
}
