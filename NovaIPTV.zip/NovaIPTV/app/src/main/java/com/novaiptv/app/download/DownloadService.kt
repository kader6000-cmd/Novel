package com.novaiptv.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.novaiptv.app.App
import com.novaiptv.app.MainActivity
import com.novaiptv.app.data.DEFAULT_UA
import com.novaiptv.app.data.DownloadEntity
import com.novaiptv.app.data.contentFromJson
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.util.Locale
import java.util.concurrent.atomic.AtomicLongArray
import java.util.concurrent.atomic.AtomicReference

/**
 * خدمة تحميل أمامية (Foreground Service):
 *  - تستمر والشاشة مقفولة (WakeLock + WifiLock)
 *  - تحميل متعدد الاتصالات (تقسيم الملف إلى أجزاء) لسرعة أعلى، مع استكمال بعد الانقطاع
 *  - إيقاف مؤقت / إلغاء فوري مع حذف الملف الجزئي
 */
class DownloadService : Service() {
    companion object {
        const val ACTION_PAUSE_ALL = "com.novaiptv.app.PAUSE_ALL"
        private const val CH = "downloads"
        private const val CH_DONE = "downloads_done"
        private const val NID = 1001
    }

    private enum class Out { DONE, PAUSED, CANCELED }
    private class Probe(val total: Long, val ranged: Boolean)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    @Volatile private var rerun = false
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var title = ""
    private var progressText = ""
    private var percent = -1
    private var lastNotify = 0L
    private var doneCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "التحميلات الجارية", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "اكتمال التحميل", NotificationManager.IMPORTANCE_DEFAULT))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(this, NID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            // أندرويد منع التشغيل من الخلفية — يُستأنف عند فتح التطبيق
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_PAUSE_ALL) scope.launch { Downloads.pauseAll(applicationContext) }
        acquireLocks()
        if (loop?.isActive == true) rerun = true else loop = scope.launch { runLoop() }
        return START_STICKY
    }

    /** أندرويد 15: خدمات dataSync لها مهلة — نوقف مؤقتاً ويمكن الاستئناف من التطبيق */
    override fun onTimeout(startId: Int, fgsType: Int) {
        scope.launch { Downloads.pauseAll(applicationContext) }
    }

    override fun onDestroy() {
        scope.cancel()
        releaseLocks()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        if (wake == null) {
            wake = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nova:download").apply {
                    setReferenceCounted(false)
                    acquire(6 * 60 * 60 * 1000L)
                }
        }
        if (wifi == null) {
            wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "nova:download").apply {
                    setReferenceCounted(false)
                    acquire()
                }
        }
    }

    private fun releaseLocks() {
        runCatching { wake?.takeIf { it.isHeld }?.release() }
        runCatching { wifi?.takeIf { it.isHeld }?.release() }
        wake = null
        wifi = null
    }

    private fun now() = System.currentTimeMillis()

    /* ─────────────── الطابور ─────────────── */

    private suspend fun runLoop() {
        val dao = (application as App).db.downloads()
        try {
            while (true) {
                rerun = false
                val d = dao.nextPending()
                if (d == null) {
                    if (rerun) continue else break
                }
                try {
                    process(d)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (dao.get(d.contentKey) != null)
                        dao.setStatus(d.contentKey, "FAILED", e.message ?: "فشل التحميل", now())
                }
            }
        } finally {
            releaseLocks()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private suspend fun process(d: DownloadEntity) {
        val app = application as App
        val dao = app.db.downloads()
        val key = d.contentKey
        val c = contentFromJson(d.json)
        title = c.display
        progressText = "جارٍ التحضير…"
        percent = -1
        lastNotify = 0
        updateNotification()

        val server = app.db.servers().get(c.serverId) ?: throw IllegalStateException("السيرفر غير موجود")
        val ua = server.userAgent.ifBlank { DEFAULT_UA }
        val url = app.repo.remoteUrl(c)
        if (url.contains(".m3u8", true)) throw IllegalStateException("بث HLS لا يمكن تحميله — متاح للأفلام والحلقات بصيغة ملف فقط")

        val ext = c.ext.ifBlank { url.substringBefore('?').substringAfterLast('.', "mp4").take(4).ifBlank { "mp4" } }
        val file = if (d.filePath.isNotBlank()) File(d.filePath) else Downloads.fileFor(this, key, ext)
        val meta = File(file.path + ".meta")
        dao.setFilePath(key, file.absolutePath)
        dao.markRunning(key, now())

        val conn = getSharedPreferences("nova", Context.MODE_PRIVATE).getInt("dl_conn", 4)
        var attempt = 0
        while (true) {
            try {
                val out = attemptDownload(app, key, url, ua, file, meta, conn, attempt > 0)
                when (out) {
                    Out.DONE -> {
                        val size = file.length()
                        dao.updateProgress(key, size, size, now())
                        dao.setStatus(key, "DONE", "", now())
                        notifyDone(c.display)
                    }
                    Out.CANCELED -> { file.delete(); meta.delete() }
                    Out.PAUSED -> {}
                }
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                attempt++
                val cur = dao.get(key)
                if (cur == null) { file.delete(); meta.delete(); return }
                if (cur.status == "PAUSED") return
                if (attempt > 4) throw e
                progressText = "انقطع الاتصال — إعادة المحاولة ($attempt)…"
                updateNotification()
                delay(3000L * attempt)
            }
        }
    }

    private suspend fun attemptDownload(
        app: App, key: String, url: String, ua: String, file: File, meta: File, conn: Int, sequential: Boolean
    ): Out {
        val client = app.http.client
        val p = withContext(Dispatchers.IO) { probe(client, url, ua) }
        return if (p.ranged && p.total > 0)
            segmented(app, key, url, ua, file, meta, p.total, conn, sequential)
        else
            single(app, key, url, ua, file, meta, p.total)
    }

    private fun probe(client: OkHttpClient, url: String, ua: String): Probe {
        val req = Request.Builder().url(url).header("User-Agent", ua).header("Range", "bytes=0-0").build()
        return client.newCall(req).execute().use { r ->
            when {
                r.code == 206 -> Probe(r.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull() ?: 0L, true)
                r.isSuccessful -> Probe(r.body?.contentLength()?.takeIf { it > 0 } ?: 0L, false)
                else -> throw IOException("HTTP ${r.code}")
            }
        }
    }

    /* ─────────────── تحميل متعدد الأجزاء مع استكمال ─────────────── */

    private suspend fun segmented(
        app: App, key: String, url: String, ua: String, file: File, meta: File,
        total: Long, connPref: Int, sequential: Boolean
    ): Out {
        val dao = app.db.downloads()
        val client = app.http.client

        var n = 0
        var doneInit = LongArray(0)
        if (file.exists() && meta.exists()) {
            val parts = runCatching { meta.readText().trim().split(";") }.getOrNull()
            if (parts != null && parts.size == 3 && parts[0].toLongOrNull() == total) {
                val nn = parts[1].toIntOrNull() ?: 0
                val ds = parts[2].split(",").mapNotNull { it.toLongOrNull() }
                if (nn in 1..16 && ds.size == nn) { n = nn; doneInit = ds.toLongArray() }
            }
        }
        if (n == 0) {
            file.delete(); meta.delete()
            n = connPref.coerceIn(1, 8).coerceAtMost(maxOf(1L, total / (2L * 1024 * 1024)).toInt())
            doneInit = LongArray(n)
            val free = (file.parentFile ?: file).usableSpace
            if (free < total + 64L * 1024 * 1024) throw IllegalStateException("المساحة غير كافية على الجهاز")
            withContext(Dispatchers.IO) { RandomAccessFile(file, "rw").use { it.setLength(total) } }
        }

        val segLen = total / n
        val starts = LongArray(n) { it * segLen }
        val ends = LongArray(n) { if (it == n - 1) total - 1 else (it + 1) * segLen - 1 }
        val done = AtomicLongArray(n)
        for (i in 0 until n) done.set(i, doneInit[i].coerceIn(0L, ends[i] - starts[i] + 1))
        val stop = AtomicReference<String?>(null)
        val failure = AtomicReference<Throwable?>(null)
        val segCount = n

        fun sum(): Long { var s = 0L; for (i in 0 until segCount) s += done.get(i); return s }
        fun writeMeta() {
            runCatching { meta.writeText("$total;$segCount;" + (0 until segCount).joinToString(",") { done.get(it).toString() }) }
        }

        coroutineScope {
            val ticker = launch {
                var lastBytes = sum()
                var lastTime = SystemClock.elapsedRealtime()
                while (isActive) {
                    delay(1000)
                    val cur = dao.get(key)
                    if (cur == null) { stop.set("CANCEL"); break }
                    if (cur.status == "PAUSED") { stop.set("PAUSE"); break }
                    val s = sum()
                    val t = SystemClock.elapsedRealtime()
                    val speed = (s - lastBytes) * 1000.0 / maxOf(1L, t - lastTime)
                    lastBytes = s; lastTime = t
                    dao.updateProgress(key, s, total, now())
                    writeMeta()
                    percent = (s * 100 / total).toInt()
                    progressText = String.format(Locale.US, "%d%% · %.1f MB/s", percent, speed / 1048576.0)
                    updateNotification()
                }
            }
            val permits = Semaphore(if (sequential) 1 else segCount)
            val workers = (0 until segCount).map { i ->
                launch {
                    permits.withPermit {
                        if (stop.get() == null) {
                            try {
                                segment(client, url, ua, file, i, starts[i], ends[i], done, stop)
                            } catch (e: IOException) {
                                failure.compareAndSet(null, e)
                                stop.compareAndSet(null, "FAIL")
                            }
                        }
                    }
                }
            }
            workers.joinAll()
            ticker.cancel()
        }
        writeMeta()

        when (stop.get()) {
            "CANCEL" -> { file.delete(); meta.delete(); return Out.CANCELED }
            "PAUSE" -> return Out.PAUSED
            "FAIL" -> throw (failure.get() ?: IOException("فشل التحميل"))
        }
        if (sum() < total) throw IOException("انقطع الاتصال")
        meta.delete()
        return Out.DONE
    }

    private fun segment(
        client: OkHttpClient, url: String, ua: String, file: File, i: Int, start: Long, end: Long,
        done: AtomicLongArray, stop: AtomicReference<String?>
    ) {
        var pos = start + done.get(i)
        if (pos > end) return
        val req = Request.Builder().url(url).header("User-Agent", ua).header("Range", "bytes=$pos-$end").build()
        client.newCall(req).execute().use { r ->
            if (r.code != 206) throw IOException("HTTP ${r.code}")
            val ins = r.body?.byteStream() ?: throw IOException("رد فارغ")
            RandomAccessFile(file, "rw").use { raf ->
                raf.seek(pos)
                val buf = ByteArray(256 * 1024)
                while (stop.get() == null) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    val len = minOf(n.toLong(), end - pos + 1).toInt()
                    if (len <= 0) break
                    raf.write(buf, 0, len)
                    pos += len
                    done.addAndGet(i, len.toLong())
                    if (pos > end) break
                }
            }
        }
        if (stop.get() == null && done.get(i) < end - start + 1) throw IOException("انقطع الاتصال")
    }

    /* ─────────────── تحميل بسيط (سيرفر لا يدعم Range) ─────────────── */

    private suspend fun single(app: App, key: String, url: String, ua: String, file: File, meta: File, total: Long): Out {
        val dao = app.db.downloads()
        file.delete(); meta.delete()
        if (total > 0) {
            val free = (file.parentFile ?: file).usableSpace
            if (free < total + 64L * 1024 * 1024) throw IllegalStateException("المساحة غير كافية على الجهاز")
        }
        val req = Request.Builder().url(url).header("User-Agent", ua).build()
        var stopped: String? = null
        withContext(Dispatchers.IO) {
            app.http.client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val body = r.body ?: throw IOException("رد فارغ")
                val len = body.contentLength().let { if (it > 0) it else total }
                var done = 0L
                var lastTick = 0L
                var lastBytes = 0L
                FileOutputStream(file).use { out ->
                    body.byteStream().use { ins ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            ensureActive()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val t = SystemClock.elapsedRealtime()
                            if (t - lastTick >= 1000) {
                                val cur = dao.get(key)
                                if (cur == null) { stopped = "CANCEL"; break }
                                if (cur.status == "PAUSED") { stopped = "PAUSE"; break }
                                val speed = (done - lastBytes) * 1000.0 / maxOf(1L, t - lastTick)
                                lastTick = t; lastBytes = done
                                dao.updateProgress(key, done, len, now())
                                percent = if (len > 0) (done * 100 / len).toInt() else -1
                                progressText = String.format(Locale.US, "%.1f MB/s", speed / 1048576.0)
                                updateNotification()
                            }
                        }
                    }
                }
                if (stopped == null && len > 0 && done < len) throw IOException("انقطع الاتصال")
            }
        }
        return when (stopped) {
            "CANCEL" -> Out.CANCELED
            "PAUSE" -> { file.delete(); Out.PAUSED }
            else -> Out.DONE
        }
    }

    /* ─────────────── الإشعارات ─────────────── */

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE
        )
        val pause = PendingIntent.getService(
            this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_PAUSE_ALL), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(if (title.isBlank()) "جارٍ التحضير…" else title)
            .setContentText(progressText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف مؤقت", pause)
            .setProgress(100, maxOf(percent, 0), percent < 0)
            .build()
    }

    private fun updateNotification() {
        val t = SystemClock.elapsedRealtime()
        if (t - lastNotify < 1000) return
        lastNotify = t
        getSystemService(NotificationManager::class.java).notify(NID, buildNotification())
    }

    private fun notifyDone(name: String) {
        doneCount++
        val n = NotificationCompat.Builder(this, CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("اكتمل التحميل")
            .setContentText(name)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(2000 + doneCount, n)
    }
}
