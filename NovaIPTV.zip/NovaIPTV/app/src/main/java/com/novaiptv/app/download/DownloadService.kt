package com.novaiptv.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.novaiptv.app.MainActivity
import com.novaiptv.app.data.AppDatabase
import com.novaiptv.app.data.DownloadDao
import com.novaiptv.app.data.DownloadEntity
import com.novaiptv.app.data.HttpClient
import kotlinx.coroutines.*
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class DownloadService : Service() {

    companion object {
        const val ACTION_START = "com.novaiptv.app.action.START_DOWNLOAD"
        const val ACTION_CANCEL = "com.novaiptv.app.action.CANCEL_DOWNLOAD"
        const val EXTRA_ID = "id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_URL = "url"
        const val EXTRA_LOGO = "logo"
        const val EXTRA_EXT = "ext"

        private const val CHANNEL_ID = "novaiptv_downloads"
        private const val NOTIF_ID = 4041
        private const val BUFFER_SIZE = 256 * 1024 // 256KB high-throughput buffer
        private const val MAX_RETRIES = 12

        val activeDownloadIds: MutableSet<String> = ConcurrentHashMap.newKeySet()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val activeCalls = ConcurrentHashMap<String, Call>()
    private val cancelledIds = ConcurrentHashMap.newKeySet<String>()

    private val downloadClient: OkHttpClient by lazy {
        HttpClient.client.newBuilder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(90, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: return START_NOT_STICKY
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "فيديو"
                val url = intent.getStringExtra(EXTRA_URL) ?: return START_NOT_STICKY
                val logo = intent.getStringExtra(EXTRA_LOGO) ?: ""
                val ext = intent.getStringExtra(EXTRA_EXT) ?: "mp4"

                if (activeJobs.containsKey(id)) return START_REDELIVER_INTENT

                acquireLocks()
                startAsForeground(id, title, 0, "جاري بدء التحميل...")
                launchDownload(id, title, url, logo, ext)
            }
            ACTION_CANCEL -> {
                val id = intent.getStringExtra(EXTRA_ID)
                if (id != null) {
                    cancelSingleDownload(id)
                }
            }
        }
        return START_REDELIVER_INTENT
    }

    private fun acquireLocks() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NovaIPTV::DownloadWakeLock").apply {
                setReferenceCounted(false)
                acquire(8 * 60 * 60 * 1000L)
            }
        }
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wm.createWifiLock(mode, "NovaIPTV::DownloadWifiLock").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseLocksIfIdle() {
        if (activeJobs.isEmpty()) {
            runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
            runCatching { wifiLock?.takeIf { it.isHeld }?.release() }
            wakeLock = null
            wifiLock = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun cancelSingleDownload(id: String) {
        cancelledIds.add(id)
        activeCalls.remove(id)?.let { runCatching { it.cancel() } }
        activeJobs.remove(id)?.cancel()
        activeDownloadIds.remove(id)

        serviceScope.launch {
            val dao = AppDatabase.get(applicationContext).downloadDao()
            val entry = dao.getById(id)
            if (entry != null) {
                val target = File(entry.filePath)
                if (target.exists()) target.delete()
                DownloadManager.deleteTempPartsFor(target)
                dao.deleteById(id)
            }
            releaseLocksIfIdle()
        }
    }

    private fun launchDownload(id: String, title: String, url: String, logo: String, ext: String) {
        cancelledIds.remove(id)
        activeDownloadIds.add(id)

        val tempDir = DownloadManager.getTempDir(applicationContext)
        val fileName = DownloadManager.sanitizeFileName(title, ext)
        val tempFile = File(tempDir, "$fileName.part")

        val job = serviceScope.launch {
            val dao = AppDatabase.get(applicationContext).downloadDao()
            dao.upsert(
                DownloadEntity(
                    id = id,
                    title = title,
                    url = url,
                    logo = logo,
                    filePath = tempFile.absolutePath,
                    progress = 0,
                    downloadedBytes = 0L,
                    totalBytes = 0L,
                    speedBytesPerSec = 0L,
                    state = "DOWNLOADING"
                )
            )

            try {
                downloadWithAutoResume(id, title, url, tempFile, dao)

                if (cancelledIds.contains(id) || !isActive) {
                    throw CancellationException("Cancelled")
                }

                // Move 100% completed file to Downloads/NovaIPTV (or user's chosen custom folder)
                val finalSize = tempFile.length()
                val savedLocation = DownloadManager.finalizeToDestination(applicationContext, tempFile, fileName)
                dao.upsert(
                    DownloadEntity(
                        id = id,
                        title = title,
                        url = url,
                        logo = logo,
                        filePath = savedLocation,
                        progress = 100,
                        downloadedBytes = finalSize,
                        totalBytes = finalSize,
                        speedBytesPerSec = 0L,
                        state = "COMPLETED"
                    )
                )
                updateNotification(id, title, 100, "اكتمل التحميل (${formatSize(finalSize)})", finished = true)
            } catch (_: Exception) {
                // Clean up partial file ONLY on explicit user cancel OR permanent failure after all retries
                if (tempFile.exists()) tempFile.delete()
                dao.deleteById(id)
            } finally {
                activeJobs.remove(id)
                activeCalls.remove(id)
                activeDownloadIds.remove(id)
                cancelledIds.remove(id)
                releaseLocksIfIdle()
            }
        }
        activeJobs[id] = job
    }

    /**
     * Resumable high-speed downloader:
     * If screen lock or WiFi sleep causes a transient socket drop, it automatically
     * retries and resumes from the exact byte offset using HTTP Range without losing progress!
     */
    private suspend fun downloadWithAutoResume(
        id: String,
        title: String,
        url: String,
        tempFile: File,
        dao: DownloadDao
    ) {
        var attempt = 0
        var knownTotalBytes = -1L

        while (true) {
            if (cancelledIds.contains(id)) throw CancellationException("Cancelled")

            val existingBytes = if (tempFile.exists()) tempFile.length() else 0L
            if (knownTotalBytes > 0 && existingBytes >= knownTotalBytes) {
                return
            }

            try {
                val reqBuilder = Request.Builder()
                    .url(url)
                    .header("User-Agent", HttpClient.USER_AGENT)
                    .header("Connection", "keep-alive")

                if (existingBytes > 0L) {
                    reqBuilder.header("Range", "bytes=$existingBytes-")
                }

                val call = downloadClient.newCall(reqBuilder.build())
                activeCalls[id] = call

                call.execute().use { resp ->
                    if (!resp.isSuccessful) {
                        if (resp.code == 416 && knownTotalBytes > 0 && existingBytes >= knownTotalBytes) {
                            return
                        }
                        throw IOException("HTTP ${resp.code}")
                    }

                    val body = resp.body ?: throw IOException("Empty body")
                    val isPartialResponse = resp.code == 206 && existingBytes > 0L
                    val appendMode = isPartialResponse
                    val startOffset = if (isPartialResponse) existingBytes else 0L

                    val contentLength = body.contentLength()
                    if (contentLength > 0) {
                        knownTotalBytes = startOffset + contentLength
                    }

                    body.byteStream().use { input ->
                        FileOutputStream(tempFile, appendMode).use { output ->
                            val buffer = ByteArray(BUFFER_SIZE)
                            var copied = startOffset
                            var lastReportBytes = copied
                            var lastReportTime = System.currentTimeMillis()
                            var read: Int

                            while (input.read(buffer).also { read = it } != -1) {
                                if (cancelledIds.contains(id)) throw CancellationException("Cancelled")
                                output.write(buffer, 0, read)
                                copied += read

                                // Reset retry counter once data is actively flowing
                                if (attempt > 0 && copied - startOffset > BUFFER_SIZE) {
                                    attempt = 0
                                }

                                val now = System.currentTimeMillis()
                                if (now - lastReportTime >= 500) {
                                    val dt = (now - lastReportTime).coerceAtLeast(1L)
                                    val speed = ((copied - lastReportBytes) * 1000L) / dt
                                    lastReportBytes = copied
                                    lastReportTime = now
                                    val pct = if (knownTotalBytes > 0) {
                                        ((copied * 100L) / knownTotalBytes).toInt().coerceIn(0, 99)
                                    } else 0
                                    dao.updateProgress(id, pct, copied, knownTotalBytes.coerceAtLeast(0L), speed, "DOWNLOADING")
                                    val subtitle = if (knownTotalBytes > 0) {
                                        "${formatSize(copied)} / ${formatSize(knownTotalBytes)} • ${formatSpeed(speed)}"
                                    } else {
                                        "${formatSize(copied)} • ${formatSpeed(speed)}"
                                    }
                                    updateNotification(id, title, pct, subtitle)
                                }
                            }
                            output.flush()
                        }
                    }
                }
                // Stream ended cleanly
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (cancelledIds.contains(id)) throw CancellationException("Cancelled")
                attempt++
                if (attempt > MAX_RETRIES) {
                    throw e
                }
                val currentBytes = if (tempFile.exists()) tempFile.length() else 0L
                val pct = if (knownTotalBytes > 0) ((currentBytes * 100L) / knownTotalBytes).toInt().coerceIn(0, 99) else 0
                updateNotification(id, title, pct, "جاري استئناف التحميل ($attempt/$MAX_RETRIES)...")
                delay((attempt * 2000L).coerceAtMost(10_000L))
            }
        }
    }

    private fun startAsForeground(id: String, title: String, progress: Int, text: String) {
        val notification = buildNotification(id, title, progress, text, finished = false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun updateNotification(id: String, title: String, progress: Int, text: String, finished: Boolean = false) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(id, title, progress, text, finished))
    }

    private fun buildNotification(id: String, title: String, progress: Int, text: String, finished: Boolean): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(!finished)

        if (!finished) {
            builder.setProgress(100, progress, progress == 0)
            val cancelIntent = Intent(this, DownloadService::class.java).apply {
                action = ACTION_CANCEL
                putExtra(EXTRA_ID, id)
            }
            val cancelPi = PendingIntent.getService(
                this, id.hashCode(), cancelIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "إلغاء", cancelPi)
        } else {
            builder.setSmallIcon(android.R.drawable.stat_sys_download_done)
            builder.setProgress(0, 0, false)
        }
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "التحميلات",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات تحميل الأفلام والحلقات في الخلفية"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format("%.1f MB", mb)
        return String.format("%.2f GB", mb / 1024.0)
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0) return "..."
        return "${formatSize(bytesPerSec)}/s"
    }

    override fun onDestroy() {
        serviceScope.cancel()
        releaseLocksIfIdle()
        super.onDestroy()
    }
}
