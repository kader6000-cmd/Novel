package com.novaiptv.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.novaiptv.app.MainActivity
import com.novaiptv.app.data.AppDatabase
import com.novaiptv.app.data.DownloadDao
import com.novaiptv.app.data.DownloadEntity
import com.novaiptv.app.data.HttpClient
import com.novaiptv.app.data.Prefs
import kotlinx.coroutines.*
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

private class ServerRejectsMultiConnException(msg: String) : IOException(msg)

class DownloadService : Service() {

    companion object {
        const val ACTION_START = "com.novaiptv.app.action.START_DOWNLOAD"
        const val ACTION_CANCEL = "com.novaiptv.app.action.CANCEL_DOWNLOAD"
        const val ACTION_PAUSE = "com.novaiptv.app.action.PAUSE_DOWNLOAD"
        const val EXTRA_ID = "id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_URL = "url"
        const val EXTRA_LOGO = "logo"
        const val EXTRA_EXT = "ext"

        private const val CHANNEL_ID = "novaiptv_downloads"
        private const val NOTIF_ID = 4041
        private const val BUFFER_SIZE = 256 * 1024
        private const val MAX_RETRIES = 12
        private const val MIN_SIZE_FOR_SPLIT = 4L * 1024L * 1024L // 4MB

        val activeDownloadIds: MutableSet<String> = ConcurrentHashMap.newKeySet()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val activeCalls = ConcurrentHashMap<String, CopyOnWriteArrayList<Call>>()
    private val cancelledIds = ConcurrentHashMap.newKeySet<String>()
    private val pausedIds = ConcurrentHashMap.newKeySet<String>()

    private val downloadClient: OkHttpClient by lazy {
        HttpClient.client.newBuilder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(90, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: return START_NOT_STICKY
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "فيديو"
                val url = intent.getStringExtra(EXTRA_URL) ?: return START_NOT_STICKY
                val logo = intent.getStringExtra(EXTRA_LOGO) ?: ""
                val ext = intent.getStringExtra(EXTRA_EXT) ?: "mp4"

                if (activeJobs.containsKey(id)) return START_REDELIVER_INTENT

                acquireLocks()
                startAsForeground(id, title, 0, "جاري بدء التحميل...")
                launchDownload(id, title, url, logo, ext)
            }
            ACTION_PAUSE -> {
                val id = intent.getStringExtra(EXTRA_ID)
                if (id != null) {
                    pauseSingleDownload(id)
                }
            }
            ACTION_CANCEL -> {
                val id = intent.getStringExtra(EXTRA_ID)
                if (id != null) {
                    cancelSingleDownload(id)
                }
            }
        }
        return START_REDELIVER_INTENT
    }

    private fun acquireLocks() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NovaIPTV::DownloadWakeLock").apply {
                setReferenceCounted(false)
                acquire(8 * 60 * 60 * 1000L)
            }
        }
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wm.createWifiLock(mode, "NovaIPTV::DownloadWifiLock").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseLocksIfIdle() {
        if (activeJobs.isEmpty()) {
            runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
            runCatching { wifiLock?.takeIf { it.isHeld }?.release() }
            wakeLock = null
            wifiLock = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun isOnWifi(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    private fun pauseSingleDownload(id: String) {
        pausedIds.add(id)
        activeCalls.remove(id)?.forEach { runCatching { it.cancel() } }
        activeJobs.remove(id)?.cancel()
        activeDownloadIds.remove(id)
        serviceScope.launch {
            val dao = AppDatabase.get(applicationContext).downloadDao()
            val entry = dao.getById(id)
            if (entry != null) {
                dao.updateProgress(id, entry.progress, entry.downloadedBytes, entry.totalBytes, 0L, "PAUSED")
            }
            releaseLocksIfIdle()
        }
    }

    private fun cancelSingleDownload(id: String) {
        cancelledIds.add(id)
        activeCalls.remove(id)?.forEach { runCatching { it.cancel() } }
        activeJobs.remove(id)?.cancel()
        activeDownloadIds.remove(id)

        serviceScope.launch {
            val dao = AppDatabase.get(applicationContext).downloadDao()
            val entry = dao.getById(id)
            if (entry != null) {
                if (!entry.filePath.startsWith("content://")) {
                    val target = File(entry.filePath)
                    if (target.exists()) target.delete()
                    DownloadManager.deleteTempPartsFor(target)
                }
                dao.deleteById(id)
            }
            releaseLocksIfIdle()
        }
    }

    private fun launchDownload(id: String, title: String, url: String, logo: String, ext: String) {
        cancelledIds.remove(id)
        pausedIds.remove(id)
        if (Prefs.wifiOnlyDownloads.value && !isOnWifi()) {
            serviceScope.launch {
                val dao = AppDatabase.get(applicationContext).downloadDao()
                val existing = dao.getById(id)
                if (existing != null) {
                    dao.updateProgress(id, existing.progress, existing.downloadedBytes, existing.totalBytes, 0L, "PAUSED")
                } else {
                    val tempDir = DownloadManager.getTempDir(applicationContext)
                    val fileName = DownloadManager.sanitizeFileName(title, ext)
                    dao.upsert(
                        DownloadEntity(
                            id = id, title = title, url = url, logo = logo,
                            filePath = File(tempDir, fileName).absolutePath,
                            progress = 0, downloadedBytes = 0L, totalBytes = 0L,
                            speedBytesPerSec = 0L, state = "PAUSED"
                        )
                    )
                }
                updateNotification(id, title, 0, "متوقف مؤقتاً — بانتظار اتصال Wi-Fi", finished = true)
                releaseLocksIfIdle()
            }
            return
        }
        activeDownloadIds.add(id)
        activeCalls[id] = CopyOnWriteArrayList()

        val tempDir = DownloadManager.getTempDir(applicationContext)
        val fileName = DownloadManager.sanitizeFileName(title, ext)
        val baseTempFile = File(tempDir, fileName)
        val singleTempFile = File(tempDir, "$fileName.part")

        val job = serviceScope.launch {
            val dao = AppDatabase.get(applicationContext).downloadDao()
            dao.upsert(
                DownloadEntity(
                    id = id,
                    title = title,
                    url = url,
                    logo = logo,
                    filePath = baseTempFile.absolutePath,
                    progress = 0,
                    downloadedBytes = 0L,
                    totalBytes = 0L,
                    speedBytesPerSec = 0L,
                    state = "DOWNLOADING"
                )
            )

            try {
                val desiredThreads = Prefs.downloadThreads.value.coerceIn(1, 8)
                val (totalBytes, supportsRanges) = probeRangeSupport(id, url)

                if (cancelledIds.contains(id) || !isActive) throw CancellationException("Cancelled")

                var savedLocation: String? = null
                var finalSize = 0L

                if (desiredThreads > 1 && supportsRanges && totalBytes >= MIN_SIZE_FOR_SPLIT) {
                    val partFiles = (0 until desiredThreads).map { idx ->
                        File(tempDir, "$fileName.part.$idx")
                    }
                    try {
                        downloadSegmentedIdm(id, title, url, partFiles, totalBytes, dao)
                        if (cancelledIds.contains(id) || !isActive) throw CancellationException("Cancelled")

                        // Merge all parts directly into final destination (Downloads/NovaIPTV or custom folder)
                        updateNotification(id, title, 99, "جاري تجميع الأجزاء (${desiredThreads})...")
                        finalSize = partFiles.sumOf { it.length() }
                        savedLocation = DownloadManager.finalizePartsToDestination(applicationContext, partFiles, fileName)
                    } catch (_: ServerRejectsMultiConnException) {
                        // Server limits concurrent connections per account -> clean up & fall back seamlessly to 1 connection
                        partFiles.forEach { runCatching { if (it.exists()) it.delete() } }
                        updateNotification(id, title, 0, "السيرفر يدعم اتصالاً واحداً — جاري التحميل...")
                    }
                }

                if (savedLocation == null) {
                    downloadWithAutoResume(id, title, url, singleTempFile, dao)
                    if (cancelledIds.contains(id) || !isActive) throw CancellationException("Cancelled")
                    finalSize = singleTempFile.length()
                    savedLocation = DownloadManager.finalizeToDestination(applicationContext, singleTempFile, fileName)
                }

                dao.upsert(
                    DownloadEntity(
                        id = id,
                        title = title,
                        url = url,
                        logo = logo,
                        filePath = savedLocation,
                        progress = 100,
                        downloadedBytes = finalSize,
                        totalBytes = finalSize,
                        speedBytesPerSec = 0L,
                        state = "COMPLETED"
                    )
                )
                updateNotification(id, title, 100, "اكتمل التحميل (${formatSize(finalSize)})", finished = true)
            } catch (_: Exception) {
                if (!pausedIds.contains(id)) {
                    if (singleTempFile.exists()) singleTempFile.delete()
                    DownloadManager.deleteTempPartsFor(baseTempFile)
                    dao.deleteById(id)
                }
            } finally {
                activeJobs.remove(id)
                activeCalls.remove(id)
                activeDownloadIds.remove(id)
                cancelledIds.remove(id)
                releaseLocksIfIdle()
            }
        }
        activeJobs[id] = job
    }

    /**
     * Probes server with a 1-byte Range GET (more reliable than HEAD on IPTV servers).
     */
    private fun probeRangeSupport(id: String, url: String): Pair<Long, Boolean> {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", HttpClient.USER_AGENT)
                .header("Range", "bytes=0-0")
                .get()
                .build()
            val call = downloadClient.newCall(req)
            activeCalls[id]?.add(call)
            call.execute().use { resp ->
                if (resp.code == 206) {
                    val contentRange = resp.header("Content-Range") ?: ""
                    val total = contentRange.substringAfter("/", "").trim().toLongOrNull() ?: -1L
                    Pair(total, total > 0L)
                } else {
                    val len = resp.header("Content-Length")?.toLongOrNull() ?: -1L
                    Pair(len, false)
                }
            }
        } catch (_: Exception) {
            Pair(-1L, false)
        }
    }

    /**
     * IDM-Style Segmented Downloader:
     * Splits the file into N independent parts, downloads them in parallel with per-part auto-resume,
     * and detects if the IPTV server rejects multiple simultaneous connections.
     */
    private suspend fun downloadSegmentedIdm(
        id: String,
        title: String,
        url: String,
        partFiles: List<File>,
        totalBytes: Long,
        dao: DownloadDao
    ) = coroutineScope {
        val threads = partFiles.size
        val chunkSize = totalBytes / threads
        val downloadedAtomic = AtomicLong(0L)
        val failedAtomic = AtomicBoolean(false)

        val progressJob = launch {
            var lastBytes = 0L
            var lastTime = System.currentTimeMillis()
            while (isActive && !failedAtomic.get() && !cancelledIds.contains(id)) {
                delay(500)
                val now = System.currentTimeMillis()
                val current = downloadedAtomic.get()
                val dt = (now - lastTime).coerceAtLeast(1L)
                val speed = ((current - lastBytes) * 1000L) / dt
                lastBytes = current
                lastTime = now
                val pct = ((current * 100L) / totalBytes).toInt().coerceIn(0, 99)
                dao.updateProgress(id, pct, current, totalBytes, speed, "DOWNLOADING")
                updateNotification(
                    id,
                    title,
                    pct,
                    "${formatSize(current)} / ${formatSize(totalBytes)} • ${formatSpeed(speed)} (${threads}x)"
                )
            }
        }

        try {
            val tasks = partFiles.mapIndexed { index, partFile ->
                async(Dispatchers.IO) {
                    val rangeStart = index * chunkSize
                    val rangeEnd = if (index == threads - 1) totalBytes - 1 else (rangeStart + chunkSize - 1)
                    val expectedPartSize = rangeEnd - rangeStart + 1
                    var attempt = 0

                    while (true) {
                        if (cancelledIds.contains(id) || failedAtomic.get()) {
                            throw CancellationException("Aborted")
                        }
                        val existing = if (partFile.exists()) partFile.length() else 0L
                        if (existing >= expectedPartSize) return@async

                        val currentStart = rangeStart + existing
                        try {
                            val req = Request.Builder()
                                .url(url)
                                .header("User-Agent", HttpClient.USER_AGENT)
                                .header("Connection", "keep-alive")
                                .header("Range", "bytes=$currentStart-$rangeEnd")
                                .build()
                            val call = downloadClient.newCall(req)
                            activeCalls[id]?.add(call)

                            call.execute().use { resp ->
                                if (resp.code in listOf(401, 403, 429, 503)) {
                                    throw ServerRejectsMultiConnException("Server limited multi-conn: HTTP ${resp.code}")
                                }
                                if (resp.code != 206) {
                                    throw ServerRejectsMultiConnException("Expected 206, got ${resp.code}")
                                }
                                val body = resp.body ?: throw IOException("Empty part body")
                                body.byteStream().use { input ->
                                    FileOutputStream(partFile, existing > 0L).use { output ->
                                        val buffer = ByteArray(BUFFER_SIZE)
                                        var read: Int
                                        var partSessionCopied = 0L
                                        while (input.read(buffer).also { read = it } != -1) {
                                            if (cancelledIds.contains(id) || failedAtomic.get()) {
                                                throw CancellationException("Aborted")
                                            }
                                            output.write(buffer, 0, read)
                                            downloadedAtomic.addAndGet(read.toLong())
                                            partSessionCopied += read
                                            if (attempt > 0 && partSessionCopied > BUFFER_SIZE) {
                                                attempt = 0
                                            }
                                        }
                                        output.flush()
                                    }
                                }
                            }
                            if (partFile.length() >= expectedPartSize) return@async
                        } catch (e: ServerRejectsMultiConnException) {
                            failedAtomic.set(true)
                            throw e
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            if (cancelledIds.contains(id) || failedAtomic.get()) throw CancellationException("Aborted")
                            attempt++
                            if (attempt > MAX_RETRIES) {
                                failedAtomic.set(true)
                                throw e
                            }
                            delay((attempt * 1500L).coerceAtMost(8_000L))
                        }
                    }
                }
            }
            tasks.awaitAll()
        } catch (e: Exception) {
            failedAtomic.set(true)
            activeCalls[id]?.forEach { runCatching { it.cancel() } }
            throw e
        } finally {
            progressJob.cancel()
        }
    }

    private suspend fun downloadWithAutoResume(
        id: String,
        title: String,
        url: String,
        tempFile: File,
        dao: DownloadDao
    ) {
        var attempt = 0
        var knownTotalBytes = -1L

        while (true) {
            if (cancelledIds.contains(id)) throw CancellationException("Cancelled")

            val existingBytes = if (tempFile.exists()) tempFile.length() else 0L
            if (knownTotalBytes > 0 && existingBytes >= knownTotalBytes) {
                return
            }

            try {
                val reqBuilder = Request.Builder()
                    .url(url)
                    .header("User-Agent", HttpClient.USER_AGENT)
                    .header("Connection", "keep-alive")

                if (existingBytes > 0L) {
                    reqBuilder.header("Range", "bytes=$existingBytes-")
                }

                val call = downloadClient.newCall(reqBuilder.build())
                activeCalls[id]?.add(call)

                call.execute().use { resp ->
                    if (!resp.isSuccessful) {
                        if (resp.code == 416 && knownTotalBytes > 0 && existingBytes >= knownTotalBytes) {
                            return
                        }
                        throw IOException("HTTP ${resp.code}")
                    }

                    val body = resp.body ?: throw IOException("Empty body")
                    val isPartialResponse = resp.code == 206 && existingBytes > 0L
                    val appendMode = isPartialResponse
                    val startOffset = if (isPartialResponse) existingBytes else 0L

                    val contentLength = body.contentLength()
                    if (contentLength > 0) {
                        knownTotalBytes = startOffset + contentLength
                    }

                    body.byteStream().use { input ->
                        FileOutputStream(tempFile, appendMode).use { output ->
                            val buffer = ByteArray(BUFFER_SIZE)
                            var copied = startOffset
                            var lastReportBytes = copied
                            var lastReportTime = System.currentTimeMillis()
                            var read: Int

                            while (input.read(buffer).also { read = it } != -1) {
                                if (cancelledIds.contains(id)) throw CancellationException("Cancelled")
                                output.write(buffer, 0, read)
                                copied += read

                                if (attempt > 0 && copied - startOffset > BUFFER_SIZE) {
                                    attempt = 0
                                }

                                val now = System.currentTimeMillis()
                                if (now - lastReportTime >= 500) {
                                    val dt = (now - lastReportTime).coerceAtLeast(1L)
                                    val speed = ((copied - lastReportBytes) * 1000L) / dt
                                    lastReportBytes = copied
                                    lastReportTime = now
                                    val pct = if (knownTotalBytes > 0) {
                                        ((copied * 100L) / knownTotalBytes).toInt().coerceIn(0, 99)
                                    } else 0
                                    dao.updateProgress(id, pct, copied, knownTotalBytes.coerceAtLeast(0L), speed, "DOWNLOADING")
                                    val subtitle = if (knownTotalBytes > 0) {
                                        "${formatSize(copied)} / ${formatSize(knownTotalBytes)} • ${formatSpeed(speed)}"
                                    } else {
                                        "${formatSize(copied)} • ${formatSpeed(speed)}"
                                    }
                                    updateNotification(id, title, pct, subtitle)
                                }
                            }
                            output.flush()
                        }
                    }
                }
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (cancelledIds.contains(id)) throw CancellationException("Cancelled")
                attempt++
                if (attempt > MAX_RETRIES) {
                    throw e
                }
                val currentBytes = if (tempFile.exists()) tempFile.length() else 0L
                val pct = if (knownTotalBytes > 0) ((currentBytes * 100L) / knownTotalBytes).toInt().coerceIn(0, 99) else 0
                updateNotification(id, title, pct, "جاري استئناف التحميل ($attempt/$MAX_RETRIES)...")
                delay((attempt * 2000L).coerceAtMost(10_000L))
            }
        }
    }

    private fun startAsForeground(id: String, title: String, progress: Int, text: String) {
        val notification = buildNotification(id, title, progress, text, finished = false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun updateNotification(id: String, title: String, progress: Int, text: String, finished: Boolean = false) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(id, title, progress, text, finished))
    }

    private fun buildNotification(id: String, title: String, progress: Int, text: String, finished: Boolean): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(!finished)

        if (!finished) {
            builder.setProgress(100, progress, progress == 0)
            val cancelIntent = Intent(this, DownloadService::class.java).apply {
                action = ACTION_CANCEL
                putExtra(EXTRA_ID, id)
            }
            val cancelPi = PendingIntent.getService(
                this, id.hashCode(), cancelIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "إلغاء", cancelPi)
        } else {
            builder.setSmallIcon(android.R.drawable.stat_sys_download_done)
            builder.setProgress(0, 0, false)
        }
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "التحميلات",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات تحميل الأفلام والحلقات في الخلفية"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format("%.1f MB", mb)
        return String.format("%.2f GB", mb / 1024.0)
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0) return "..."
        return "${formatSize(bytesPerSec)}/s"
    }

    override fun onDestroy() {
        serviceScope.cancel()
        releaseLocksIfIdle()
        super.onDestroy()
    }
}
