package com.novaiptv.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.novaiptv.app.MainActivity
import com.novaiptv.app.data.AppDatabase
import com.novaiptv.app.data.DownloadDao
import com.novaiptv.app.data.DownloadEntity
import com.novaiptv.app.data.HttpClient
import kotlinx.coroutines.*
import okhttp3.Call
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class DownloadService : Service() {

    companion object {
        const val ACTION_START = "com.novaiptv.app.action.START_DOWNLOAD"
        const val ACTION_CANCEL = "com.novaiptv.app.action.CANCEL_DOWNLOAD"
        const val EXTRA_ID = "id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_URL = "url"
        const val EXTRA_LOGO = "logo"
        const val EXTRA_EXT = "ext"

        private const val CHANNEL_ID = "novaiptv_downloads"
        private const val NOTIF_ID = 4041
        private const val PARALLEL_THREADS = 4
        private const val BUFFER_SIZE = 128 * 1024
        private const val MIN_SIZE_FOR_MULTI_THREAD = 2L * 1024L * 1024L

        val activeDownloadIds: MutableSet<String> = ConcurrentHashMap.newKeySet()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val activeCalls = ConcurrentHashMap<String, MutableList<Call>>()
    private val cancelledIds = ConcurrentHashMap.newKeySet<String>()

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val id = intent.getStringExtra(EXTRA_ID) ?: return START_NOT_STICKY
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "فيديو"
                val url = intent.getStringExtra(EXTRA_URL) ?: return START_NOT_STICKY
                val logo = intent.getStringExtra(EXTRA_LOGO) ?: ""
                val ext = intent.getStringExtra(EXTRA_EXT) ?: "mp4"

                if (activeJobs.containsKey(id)) return START_STICKY

                acquireLocks()
                startAsForeground(id, title, 0, "جاري بدء التحميل...")
                launchDownload(id, title, url, logo, ext)
            }
            ACTION_CANCEL -> {
                val id = intent.getStringExtra(EXTRA_ID)
                if (id != null) {
                    cancelSingleDownload(id)
                }
            }
        }
        return START_STICKY
    }

    private fun acquireLocks() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NovaIPTV::DownloadWakeLock").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
        }
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "NovaIPTV::DownloadWifiLock").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseLocksIfIdle() {
        if (activeJobs.isEmpty()) {
            runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
            runCatching { wifiLock?.takeIf { it.isHeld }?.release() }
            wakeLock = null
            wifiLock = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun cancelSingleDownload(id: String) {
        cancelledIds.add(id)
        activeCalls[id]?.forEach { runCatching { it.cancel() } }
        activeJobs[id]?.cancel()
        activeJobs.remove(id)
        activeCalls.remove(id)
        activeDownloadIds.remove(id)

        serviceScope.launch {
            val dao = AppDatabase.get(applicationContext).downloadDao()
            val entry = dao.getById(id)
            if (entry != null) {
                val target = File(entry.filePath)
                if (target.exists()) target.delete()
                DownloadManager.deleteTempPartsFor(target)
                dao.deleteById(id)
            }
            releaseLocksIfIdle()
        }
    }

    private fun launchDownload(id: String, title: String, url: String, logo: String, ext: String) {
        cancelledIds.remove(id)
        activeDownloadIds.add(id)
        activeCalls[id] = mutableListOf()

        val dir = DownloadManager.getDownloadDir(applicationContext)
        val fileName = DownloadManager.sanitizeFileName(title, ext)
        val finalFile = File(dir, fileName)
        val tempFile = File(dir, "$fileName.part")

        val job = serviceScope.launch {
            val dao = AppDatabase.get(applicationContext).downloadDao()
            dao.upsert(
                DownloadEntity(
                    id = id,
                    title = title,
                    url = url,
                    logo = logo,
                    filePath = finalFile.absolutePath,
                    progress = 0,
                    downloadedBytes = 0L,
                    totalBytes = 0L,
                    speedBytesPerSec = 0L,
                    state = "DOWNLOADING"
                )
            )

            try {
                val (totalBytes, supportsRanges) = probeUrl(id, url)
                if (cancelledIds.contains(id) || !isActive) throw CancellationException("Cancelled")

                if (supportsRanges && totalBytes >= MIN_SIZE_FOR_MULTI_THREAD) {
                    downloadMultiThreaded(id, title, url, tempFile, totalBytes, dao)
                } else {
                    downloadSingleStream(id, title, url, tempFile, totalBytes, dao)
                }

                if (cancelledIds.contains(id) || !isActive) throw CancellationException("Cancelled")

                if (finalFile.exists()) finalFile.delete()
                if (!tempFile.renameTo(finalFile)) {
                    throw IOException("Failed to finalize downloaded file")
                }

                val finalSize = finalFile.length()
                dao.updateProgress(id, 100, finalSize, finalSize, 0L, "COMPLETED")
                updateNotification(id, title, 100, "اكتمل التحميل (${formatSize(finalSize)})", finished = true)
            } catch (_: Exception) {
                if (tempFile.exists()) tempFile.delete()
                if (finalFile.exists() && finalFile.length() == 0L) finalFile.delete()
                DownloadManager.deleteTempPartsFor(finalFile)
                dao.deleteById(id)
            } finally {
                activeJobs.remove(id)
                activeCalls.remove(id)
                activeDownloadIds.remove(id)
                cancelledIds.remove(id)
                releaseLocksIfIdle()
            }
        }
        activeJobs[id] = job
    }

    private fun probeUrl(id: String, url: String): Pair<Long, Boolean> {
        return try {
            val req = Request.Builder()
                .url(url)
                .head()
                .header("User-Agent", HttpClient.USER_AGENT)
                .build()
            val call = HttpClient.client.newCall(req)
            activeCalls[id]?.add(call)
            call.execute().use { resp ->
                if (!resp.isSuccessful) return Pair(-1L, false)
                val length = resp.header("Content-Length")?.toLongOrNull() ?: -1L
                val acceptRanges = resp.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
                Pair(length, acceptRanges)
            }
        } catch (_: Exception) {
            Pair(-1L, false)
        }
    }

    private suspend fun downloadMultiThreaded(
        id: String,
        title: String,
        url: String,
        tempFile: File,
        totalBytes: Long,
        dao: DownloadDao
    ) = coroutineScope {
        RandomAccessFile(tempFile, "rw").use { it.setLength(totalBytes) }

        val downloadedAtomic = AtomicLong(0L)
        val failedAtomic = AtomicBoolean(false)
        val chunkSize = totalBytes / PARALLEL_THREADS

        val progressJob = launch {
            var lastBytes = 0L
            var lastTime = System.currentTimeMillis()
            while (isActive && !failedAtomic.get() && !cancelledIds.contains(id)) {
                delay(500)
                val now = System.currentTimeMillis()
                val current = downloadedAtomic.get()
                val dt = (now - lastTime).coerceAtLeast(1L)
                val speed = ((current - lastBytes) * 1000L) / dt
                lastBytes = current
                lastTime = now
                val pct = ((current * 100L) / totalBytes).toInt().coerceIn(0, 99)
                dao.updateProgress(id, pct, current, totalBytes, speed, "DOWNLOADING")
                updateNotification(
                    id,
                    title,
                    pct,
                    "${formatSize(current)} / ${formatSize(totalBytes)} • ${formatSpeed(speed)}"
                )
            }
        }

        try {
            val tasks = (0 until PARALLEL_THREADS).map { index ->
                async(Dispatchers.IO) {
                    val start = index * chunkSize
                    val end = if (index == PARALLEL_THREADS - 1) totalBytes - 1 else (start + chunkSize - 1)
                    val req = Request.Builder()
                        .url(url)
                        .header("User-Agent", HttpClient.USER_AGENT)
                        .header("Range", "bytes=$start-$end")
                        .build()
                    val call = HttpClient.client.newCall(req)
                    activeCalls[id]?.add(call)

                    call.execute().use { resp ->
                        if (!resp.isSuccessful) throw IOException("Chunk HTTP ${resp.code}")
                        val body = resp.body ?: throw IOException("Empty chunk body")
                        body.byteStream().use { input ->
                            RandomAccessFile(tempFile, "rw").use { raf ->
                                raf.seek(start)
                                val buffer = ByteArray(BUFFER_SIZE)
                                var read: Int
                                while (input.read(buffer).also { read = it } != -1) {
                                    if (cancelledIds.contains(id) || failedAtomic.get()) {
                                        throw CancellationException("Aborted")
                                    }
                                    raf.write(buffer, 0, read)
                                    downloadedAtomic.addAndGet(read.toLong())
                                }
                            }
                        }
                    }
                }
            }
            tasks.awaitAll()
        } catch (e: Exception) {
            failedAtomic.set(true)
            throw e
        } finally {
            progressJob.cancel()
        }
    }

    private suspend fun downloadSingleStream(
        id: String,
        title: String,
        url: String,
        tempFile: File,
        knownTotal: Long,
        dao: DownloadDao
    ) {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", HttpClient.USER_AGENT)
            .build()
        val call = HttpClient.client.newCall(req)
        activeCalls[id]?.add(call)

        call.execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val body = resp.body ?: throw IOException("Empty body")
            val totalBytes = body.contentLength().takeIf { it > 0 } ?: knownTotal

            body.byteStream().use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var copied = 0L
                    var lastReportBytes = 0L
                    var lastReportTime = System.currentTimeMillis()
                    var read: Int

                    while (input.read(buffer).also { read = it } != -1) {
                        if (cancelledIds.contains(id)) throw CancellationException("Cancelled")
                        output.write(buffer, 0, read)
                        copied += read

                        val now = System.currentTimeMillis()
                        if (now - lastReportTime >= 500) {
                            val dt = (now - lastReportTime).coerceAtLeast(1L)
                            val speed = ((copied - lastReportBytes) * 1000L) / dt
                            lastReportBytes = copied
                            lastReportTime = now
                            val pct = if (totalBytes > 0) ((copied * 100L) / totalBytes).toInt().coerceIn(0, 99) else 0
                            dao.updateProgress(id, pct, copied, totalBytes.coerceAtLeast(0L), speed, "DOWNLOADING")
                            val subtitle = if (totalBytes > 0) {
                                "${formatSize(copied)} / ${formatSize(totalBytes)} • ${formatSpeed(speed)}"
                            } else {
                                "${formatSize(copied)} • ${formatSpeed(speed)}"
                            }
                            updateNotification(id, title, pct, subtitle)
                        }
                    }
                    output.flush()
                }
            }
        }
    }

    private fun startAsForeground(id: String, title: String, progress: Int, text: String) {
        val notification = buildNotification(id, title, progress, text, finished = false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun updateNotification(id: String, title: String, progress: Int, text: String, finished: Boolean = false) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(id, title, progress, text, finished))
    }

    private fun buildNotification(id: String, title: String, progress: Int, text: String, finished: Boolean): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(!finished)

        if (!finished) {
            builder.setProgress(100, progress, progress == 0)
            val cancelIntent = Intent(this, DownloadService::class.java).apply {
                action = ACTION_CANCEL
                putExtra(EXTRA_ID, id)
            }
            val cancelPi = PendingIntent.getService(
                this, id.hashCode(), cancelIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "إلغاء", cancelPi)
        } else {
            builder.setSmallIcon(android.R.drawable.stat_sys_download_done)
            builder.setProgress(0, 0, false)
        }
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "التحميلات",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات تحميل الأفلام والحلقات في الخلفية"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format("%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format("%.1f MB", mb)
        return String.format("%.2f GB", mb / 1024.0)
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        if (bytesPerSec <= 0) return "..."
        return "${formatSize(bytesPerSec)}/s"
    }

    override fun onDestroy() {
        serviceScope.cancel()
        releaseLocksIfIdle()
        super.onDestroy()
    }
}
