package com.novaiptv.app.download

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.novaiptv.app.app
import com.novaiptv.app.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

object Downloads {
    private const val QUEUE = "dl-queue"

    /** إضافة حلقة/فيلم/قائمة كاملة إلى طابور التحميل (يُنفَّذ واحداً تلو الآخر) */
    suspend fun enqueue(ctx: Context, items: List<Content>) {
        val dao = ctx.app.db.downloads()
        var added = false
        for (c in items) {
            if (c.kind == Kind.LIVE) continue
            val ex = dao.get(c.key)
            if (ex != null && ex.status == "DONE" && File(ex.filePath).exists()) continue
            if (ex != null && (ex.status == "QUEUED" || ex.status == "RUNNING")) continue
            dao.upsert(DownloadEntity(c.key, c.serverId, c.toJson(), c.display, ex?.filePath ?: "", "QUEUED", ex?.downloaded ?: 0, ex?.total ?: 0, System.currentTimeMillis()))
            added = true
        }
        if (added) start(ctx)
    }

    fun start(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(QUEUE, ExistingWorkPolicy.APPEND_OR_REPLACE, req)
    }

    suspend fun retry(ctx: Context, d: DownloadEntity) {
        ctx.app.db.downloads().upsert(d.copy(status = "QUEUED", error = "", updatedAt = System.currentTimeMillis()))
        start(ctx)
    }

    suspend fun remove(ctx: Context, d: DownloadEntity) {
        ctx.app.db.downloads().remove(d.contentKey)
        withContext(Dispatchers.IO) { if (d.filePath.isNotBlank()) File(d.filePath).delete() }
    }
}

class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val dao = applicationContext.app.db.downloads()
        while (true) {
            val d = dao.nextPending() ?: break
            runCatching { setForeground(foregroundInfo(d.title)) }
            try {
                process(d)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (dao.get(d.contentKey) != null)
                    dao.upsert(d.copy(status = "FAILED", error = e.message ?: "فشل التحميل", updatedAt = System.currentTimeMillis()))
            }
        }
        return Result.success()
    }

    private suspend fun process(d: DownloadEntity) {
        val app = applicationContext.app
        val dao = app.db.downloads()
        val c = contentFromJson(d.json)
        val server = app.db.servers().get(c.serverId) ?: throw IllegalStateException("السيرفر غير موجود")
        val url = app.repo.remoteUrl(c)
        if (url.contains(".m3u8", true)) throw IllegalStateException("بث HLS لا يمكن تحميله — متاح للأفلام والحلقات بصيغة ملف فقط")

        val ext = c.ext.ifBlank { url.substringBefore('?').substringAfterLast('.', "mp4").take(4).ifBlank { "mp4" } }
        val dir = File(applicationContext.getExternalFilesDir(null) ?: applicationContext.filesDir, "downloads").apply { mkdirs() }
        val file = File(dir, c.key.replace(Regex("[^A-Za-z0-9._-]"), "_") + "." + ext)
        var existing = if (file.exists()) file.length() else 0L
        dao.upsert(d.copy(filePath = file.absolutePath, status = "RUNNING", updatedAt = System.currentTimeMillis()))

        val req = Request.Builder().url(url)
            .header("User-Agent", server.userAgent.ifBlank { DEFAULT_UA })
            .apply { if (existing > 0) header("Range", "bytes=$existing-") }
            .build()

        withContext(Dispatchers.IO) {
            app.http.client.newCall(req).execute().use { r ->
                if (r.code == 416) {      // الملف مكتمل مسبقاً
                    return@use
                }
                if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
                val append = r.code == 206
                if (!append) existing = 0
                val body = r.body ?: throw IllegalStateException("رد فارغ")
                val total = body.contentLength().let { if (it > 0) it + existing else 0L }
                var done = existing
                var lastTick = 0L
                FileOutputStream(file, append).use { out ->
                    body.byteStream().use { ins ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            ensureActive()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastTick > 800) {
                                lastTick = now
                                if (dao.get(d.contentKey) == null) {   // حُذف من القائمة = إلغاء
                                    out.close(); file.delete()
                                    return@withContext
                                }
                                dao.progress(d.contentKey, done, total, "RUNNING", now)
                            }
                        }
                    }
                }
            }
        }
        if (dao.get(d.contentKey) == null) return
        val size = file.length()
        dao.progress(d.contentKey, size, size, "DONE", System.currentTimeMillis())
    }

    private fun foregroundInfo(title: String): ForegroundInfo {
        val ch = "downloads"
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "التحميلات", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(applicationContext, ch)
            .setContentTitle("جارٍ التحميل")
            .setContentText(title)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(1001, n)
    }
}
