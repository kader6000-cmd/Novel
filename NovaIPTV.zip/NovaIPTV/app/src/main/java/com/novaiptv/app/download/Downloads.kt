package com.novaiptv.app.download

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.novaiptv.app.app
import com.novaiptv.app.data.Content
import com.novaiptv.app.data.DownloadEntity
import com.novaiptv.app.data.Kind
import com.novaiptv.app.data.toJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** واجهة التحكم في التحميلات: كل العمل الفعلي يتم داخل DownloadService */
object Downloads {

    fun dir(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "downloads").apply { mkdirs() }

    fun fileFor(ctx: Context, key: String, ext: String): File =
        File(dir(ctx), key.replace(Regex("[^A-Za-z0-9._-]"), "_") + "." + ext)

    fun start(ctx: Context) {
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        } catch (_: Exception) { /* التطبيق في الخلفية — سيُستأنف عند فتحه */ }
    }

    suspend fun enqueue(ctx: Context, items: List<Content>) {
        val dao = ctx.app.db.downloads()
        var added = false
        for (c in items) {
            if (c.kind == Kind.LIVE) continue
            val ex = dao.get(c.key)
            if (ex != null) {
                when (ex.status) {
                    "QUEUED", "RUNNING" -> continue
                    "DONE" -> if (File(ex.filePath).exists()) continue
                    else -> {
                        dao.setStatus(c.key, "QUEUED", "", System.currentTimeMillis())
                        added = true
                        continue
                    }
                }
            }
            dao.upsert(
                DownloadEntity(c.key, c.serverId, c.toJson(), c.display, "", "QUEUED", 0, 0, System.currentTimeMillis())
            )
            added = true
        }
        if (added) start(ctx)
    }

    suspend fun pause(ctx: Context, d: DownloadEntity) {
        if (d.status == "QUEUED" || d.status == "RUNNING")
            ctx.app.db.downloads().setStatus(d.contentKey, "PAUSED", "", System.currentTimeMillis())
    }

    suspend fun resume(ctx: Context, d: DownloadEntity) {
        if (d.status == "DONE") return
        ctx.app.db.downloads().setStatus(d.contentKey, "QUEUED", "", System.currentTimeMillis())
        start(ctx)
    }

    /** إلغاء/حذف: يحذف السجل والملف الجزئي أو الكامل فوراً لتحرير المساحة */
    suspend fun remove(ctx: Context, d: DownloadEntity) {
        ctx.app.db.downloads().remove(d.contentKey)
        withContext(Dispatchers.IO) {
            if (d.filePath.isNotBlank()) {
                File(d.filePath).delete()
                File(d.filePath + ".meta").delete()
            }
        }
    }

    suspend fun pauseAll(ctx: Context) {
        val dao = ctx.app.db.downloads()
        dao.list().filter { it.status == "QUEUED" || it.status == "RUNNING" }
            .forEach { dao.setStatus(it.contentKey, "PAUSED", "", System.currentTimeMillis()) }
    }

    suspend fun resumeAll(ctx: Context) {
        val dao = ctx.app.db.downloads()
        val list = dao.list().filter { it.status == "PAUSED" || it.status == "FAILED" }
        list.forEach { dao.setStatus(it.contentKey, "QUEUED", "", System.currentTimeMillis()) }
        if (list.isNotEmpty()) start(ctx)
    }

    suspend fun clearAll(ctx: Context) {
        ctx.app.db.downloads().list().forEach { remove(ctx, it) }
    }

    /** تنظيف عند فتح التطبيق: حذف أي ملفات يتيمة، وإكمال ما كان معلّقاً */
    suspend fun cleanup(ctx: Context) {
        val dao = ctx.app.db.downloads()
        val all = dao.list()
        withContext(Dispatchers.IO) {
            val known = all.map { it.filePath }.filter { it.isNotBlank() }.toSet()
            val now = System.currentTimeMillis()
            dir(ctx).listFiles()?.forEach { f ->
                val base = if (f.name.endsWith(".meta")) f.path.removeSuffix(".meta") else f.path
                if (base !in known && now - f.lastModified() > 120_000) f.delete()
            }
        }
        all.forEach { d ->
            if (d.status == "DONE" && (d.filePath.isBlank() || !File(d.filePath).exists())) dao.remove(d.contentKey)
        }
        if (all.any { it.status == "QUEUED" || it.status == "RUNNING" }) start(ctx)
    }
}
