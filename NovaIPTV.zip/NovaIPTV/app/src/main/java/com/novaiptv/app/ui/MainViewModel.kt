package com.novaiptv.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.novaiptv.app.data.*
import com.novaiptv.app.download.DownloadManager
import com.novaiptv.app.download.DownloadService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SectionState(
    val categories: List<Category> = emptyList(),
    val selectedCategoryId: String = "ALL",
    val items: List<MediaItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val loaded: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = IptvRepository(application)

    val servers: StateFlow<List<ServerEntity>> = repo.observeServers()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val downloads: StateFlow<List<DownloadEntity>> = repo.observeDownloads()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val history: StateFlow<List<HistoryEntity>> = repo.observeHistory()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _activeServer = MutableStateFlow<ServerEntity?>(null)
    val activeServer: StateFlow<ServerEntity?> = _activeServer.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val favorites: StateFlow<List<FavoriteEntity>> = _activeServer
        .flatMapLatest { server ->
            if (server == null) flowOf(emptyList()) else repo.observeFavorites(server.id)
        }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _liveState = MutableStateFlow(SectionState())
    val liveState: StateFlow<SectionState> = _liveState.asStateFlow()

    private val _movieState = MutableStateFlow(SectionState())
    val movieState: StateFlow<SectionState> = _movieState.asStateFlow()

    private val _seriesState = MutableStateFlow(SectionState())
    val seriesState: StateFlow<SectionState> = _seriesState.asStateFlow()

    private val _seriesDetail = MutableStateFlow<SeriesDetail?>(null)
    val seriesDetail: StateFlow<SeriesDetail?> = _seriesDetail.asStateFlow()

    private val _seriesDetailLoading = MutableStateFlow(false)
    val seriesDetailLoading: StateFlow<Boolean> = _seriesDetailLoading.asStateFlow()

    private val _storageBytes = MutableStateFlow(0L)

    private val _accountInfo = MutableStateFlow<ServerAccountInfo?>(null)
    val accountInfo: StateFlow<ServerAccountInfo?> = _accountInfo.asStateFlow()
    val storageBytes: StateFlow<Long> = _storageBytes.asStateFlow()

    private var provider: IptvProvider? = null

    init {
        viewModelScope.launch {
            val active = repo.getActiveServer()
            setCurrentServer(active)
            refreshStorageUsage()
        }
    }

    private fun setCurrentServer(server: ServerEntity?) {
        _activeServer.value = server
        provider = server?.let { ProviderFactory.create(it) }
        _liveState.value = SectionState()
        _movieState.value = SectionState()
        _seriesState.value = SectionState()
        _accountInfo.value = null
        if (server != null) {
            loadSection(ContentKind.LIVE, force = true)
            viewModelScope.launch {
                _accountInfo.value = provider?.loadAccountInfo()
            }
        }
    }

    fun addServer(name: String, type: ServerType, host: String, user: String, pass: String, mac: String) {
        viewModelScope.launch {
            val entity = ServerEntity(
                name = name.ifBlank { "سيرفر IPTV" },
                type = type.name,
                host = host.trim(),
                username = user.trim(),
                password = pass.trim(),
                mac = mac.trim(),
                isActive = true
            )
            val id = repo.addServer(entity)
            setCurrentServer(entity.copy(id = id))
        }
    }

    fun activateServer(server: ServerEntity) {
        viewModelScope.launch {
            repo.activateServer(server.id)
            setCurrentServer(server.copy(isActive = true))
        }
    }

    fun deleteServer(server: ServerEntity) {
        viewModelScope.launch {
            repo.deleteServer(server.id)
            val next = repo.getActiveServer()
            setCurrentServer(next)
        }
    }

    private fun stateFlowFor(kind: ContentKind): MutableStateFlow<SectionState> = when (kind) {
        ContentKind.LIVE -> _liveState
        ContentKind.MOVIE -> _movieState
        ContentKind.SERIES -> _seriesState
    }

    fun loadSection(kind: ContentKind, categoryId: String = "ALL", force: Boolean = false) {
        val p = provider ?: return
        val flow = stateFlowFor(kind)
        if (!force && flow.value.loaded && flow.value.selectedCategoryId == categoryId) return

        viewModelScope.launch {
            flow.update { it.copy(isLoading = true, error = null, selectedCategoryId = categoryId) }
            try {
                val cats = if (flow.value.categories.isEmpty() || force) {
                    p.loadCategories(kind)
                } else {
                    flow.value.categories
                }
                val items = p.loadItems(kind, categoryId)
                flow.update {
                    it.copy(
                        categories = cats,
                        items = items,
                        isLoading = false,
                        loaded = true,
                        error = null
                    )
                }
            } catch (e: Exception) {
                flow.update {
                    it.copy(
                        isLoading = false,
                        error = "تعذر تحميل المحتوى: ${e.localizedMessage ?: "خطأ في الاتصال"}"
                    )
                }
            }
        }
    }

    fun openSeriesDetail(series: MediaItem) {
        val p = provider ?: return
        viewModelScope.launch {
            _seriesDetailLoading.value = true
            _seriesDetail.value = null
            try {
                _seriesDetail.value = p.loadSeriesDetail(series)
            } catch (_: Exception) {
                _seriesDetail.value = SeriesDetail(series, emptyMap())
            } finally {
                _seriesDetailLoading.value = false
            }
        }
    }

    fun closeSeriesDetail() {
        _seriesDetail.value = null
        _seriesDetailLoading.value = false
    }

    fun toggleFavorite(item: MediaItem, isFav: Boolean) {
        val serverId = _activeServer.value?.id ?: return
        viewModelScope.launch {
            repo.toggleFavorite(serverId, item, isFav)
        }
    }

    fun startDownload(id: String, title: String, url: String, logo: String, ext: String) {
        DownloadManager.startDownload(getApplication(), id, title, url, logo, ext)
    }

    fun pauseDownload(id: String) {
        DownloadManager.pauseDownload(getApplication(), id)
    }

    fun resumeDownload(entity: DownloadEntity) {
        val ext = entity.filePath.substringAfterLast(".", "mp4").take(5).ifBlank { "mp4" }
        DownloadManager.startDownload(getApplication(), entity.id, entity.title, entity.url, entity.logo, ext)
    }

    fun cancelDownload(id: String) {
        DownloadManager.cancelDownload(getApplication(), id)
        viewModelScope.launch {
            kotlinx.coroutines.delay(400)
            refreshStorageUsage()
        }
    }

    fun deleteDownload(entity: DownloadEntity) {
        DownloadManager.deleteCompletedDownload(getApplication(), entity.id, entity.filePath)
        viewModelScope.launch {
            kotlinx.coroutines.delay(400)
            refreshStorageUsage()
        }
    }

    fun cleanTempStorage(onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val freed = DownloadManager.cleanupOrphanedFiles(
                getApplication(),
                DownloadService.activeDownloadIds
            )
            refreshStorageUsage()
            onDone(freed)
        }
    }

    fun refreshStorageUsage() {
        _storageBytes.value = DownloadManager.calculateUsedStorageBytes(getApplication())
    }
}
