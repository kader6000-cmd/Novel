package com.novaiptv.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object Prefs {
    private const val FILE_NAME = "novaiptv_prefs"
    private const val KEY_LANG = "app_language"
    private const val KEY_DISCLAIMER = "disclaimer_accepted"
    private const val KEY_PIN = "parental_pin"
    private const val KEY_LOCKED_CATS = "locked_categories"

    private val _language = MutableStateFlow("ar")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _disclaimerAccepted = MutableStateFlow(false)
    val disclaimerAccepted: StateFlow<Boolean> = _disclaimerAccepted.asStateFlow()

    private val _parentalPin = MutableStateFlow("")
    val parentalPin: StateFlow<String> = _parentalPin.asStateFlow()

    private val _lockedCategories = MutableStateFlow<Set<String>>(emptySet())
    val lockedCategories: StateFlow<Set<String>> = _lockedCategories.asStateFlow()

    fun init(context: Context) {
        val sp = context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
        _language.value = sp.getString(KEY_LANG, "ar") ?: "ar"
        _disclaimerAccepted.value = sp.getBoolean(KEY_DISCLAIMER, false)
        _parentalPin.value = sp.getString(KEY_PIN, "") ?: ""
        _lockedCategories.value = sp.getStringSet(KEY_LOCKED_CATS, emptySet())?.toSet() ?: emptySet()
    }

    fun setLanguage(context: Context, code: String) {
        _language.value = code
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_LANG, code).apply()
    }

    fun acceptDisclaimer(context: Context) {
        _disclaimerAccepted.value = true
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DISCLAIMER, true).apply()
    }

    fun setParentalPin(context: Context, pin: String) {
        _parentalPin.value = pin
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_PIN, pin).apply()
    }

    fun toggleLockedCategory(context: Context, categoryName: String) {
        val current = _lockedCategories.value.toMutableSet()
        if (categoryName in current) current.remove(categoryName) else current.add(categoryName)
        _lockedCategories.value = current
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_LOCKED_CATS, current).apply()
    }

    fun isCategoryLocked(categoryName: String): Boolean {
        if (_parentalPin.value.isBlank()) return false
        val lower = categoryName.lowercase()
        if (_lockedCategories.value.any { it.equals(categoryName, ignoreCase = true) }) return true
        // Auto-protect common adult category keywords when PIN is enabled
        return lower.contains("18+") || lower.contains("adult") || lower.contains("xxx") || lower.contains("للكبار")
    }
}
